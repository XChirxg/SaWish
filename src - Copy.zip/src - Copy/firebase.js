// firebase.js - Firebase Configuration
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Your web app's Firebase configuration
// Replace with your actual Firebase project config
  const firebaseConfig = {
    apiKey: "AIzaSyC3A470sdiLoqiHg_SMVv4Ai_lblxiHk_Q",
    authDomain: "sawish5.firebaseapp.com",
    projectId: "sawish5",
    storageBucket: "sawish5.firebasestorage.app",
    messagingSenderId: "300387291843",
    appId: "1:300387291843:web:4a5ffd342d0b420a9b4876"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);

// Initialize Firestore
export const db = getFirestore(app);



export default app;