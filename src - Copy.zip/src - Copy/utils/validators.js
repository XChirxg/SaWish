import { VALIDATION } from "./constants";

/**
 * Validate an email address
 * @param {String} email - Email to validate
 * @returns {Object} - Validation result with isValid and errorMessage properties
 */
export const validateEmail = (email) => {
  if (!email || email.trim() === "") {
    return {
      isValid: false,
      errorMessage: "Email cannot be empty",
    };
  }
  
  if (!VALIDATION.EMAIL_PATTERN.test(email)) {
    return {
      isValid: false,
      errorMessage: "Please enter a valid email address",
    };
  }
  
  return {
    isValid: true,
    errorMessage: "",
  };
};

/**
 * Validate a password
 * @param {String} password - Password to validate
 * @returns {Object} - Validation result with isValid and errorMessage properties
 */
export const validatePassword = (password) => {
  if (!password || password.trim() === "") {
    return {
      isValid: false,
      errorMessage: "Password cannot be empty",
    };
  }
  
  if (password.length < VALIDATION.MIN_PASSWORD_LENGTH) {
    return {
      isValid: false,
      errorMessage: `Password must be at least ${VALIDATION.MIN_PASSWORD_LENGTH} characters long`,
    };
  }
  
  // Check for at least one number
  if (!/\d/.test(password)) {
    return {
      isValid: false,
      errorMessage: "Password must contain at least one number",
    };
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(password)) {
    return {
      isValid: false,
      errorMessage: "Password must contain at least one uppercase letter",
    };
  }
  
  return {
    isValid: true,
    errorMessage: "",
  };
};

/**
 * Validate a username
 * @param {String} username - Username to validate
 * @returns {Object} - Validation result with isValid and errorMessage properties
 */
export const validateUsername = (username) => {
  if (!username || username.trim() === "") {
    return {
      isValid: false,
      errorMessage: "Username cannot be empty",
    };
  }
  
  if (!VALIDATION.USERNAME_PATTERN.test(username)) {
    return {
      isValid: false,
      errorMessage: "Username must be 3-20 characters and can only include letters, numbers, and underscores",
    };
  }
  
  return {
    isValid: true,
    errorMessage: "",
  };
};

/**
 * Validate a phone number
 * @param {String} phoneNumber - Phone number to validate
 * @returns {Object} - Validation result with isValid and errorMessage properties
 */
export const validatePhoneNumber = (phoneNumber) => {
  if (!phoneNumber || phoneNumber.trim() === "") {
    return {
      isValid: true, // Phone number is optional
      errorMessage: "",
    };
  }
  
  if (!VALIDATION.PHONE_PATTERN.test(phoneNumber)) {
    return {
      isValid: false,
      errorMessage: "Please enter a valid phone number",
    };
  }
  
  return {
    isValid: true,
    errorMessage: "",
  };
};

/**
 * Validate a date of birth
 * @param {String|Date} dob - Date of birth to validate
 * @returns {Object} - Validation result with isValid and errorMessage properties
 */
export const validateDateOfBirth = (dob) => {
  if (!dob) {
    return {
      isValid: false,
      errorMessage: "Date of birth cannot be empty",
    };
  }
  
  const dobDate = new Date(dob);
  
  if (isNaN(dobDate.getTime())) {
    return {
      isValid: false,
      errorMessage: "Please enter a valid date",
    };
  }
  
  const today = new Date();
  const age = today.getFullYear() - dobDate.getFullYear();
  const monthDiff = today.getMonth() - dobDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dobDate.getDate())) {
    age--;
  }
  
  if (age < 13) {
    return {
      isValid: false,
      errorMessage: "You must be at least 13 years old to use this application",
    };
  }
  
  if (age > 100) {
    return {
      isValid: false,
      errorMessage: "Please enter a valid date of birth",
    };
  }
  
  return {
    isValid: true,
    errorMessage: "",
  };
};

/**
 * Validate a bio text
 * @param {String} bio - Bio text to validate
 * @param {Number} maxLength - Maximum allowed length
 * @returns {Object} - Validation result with isValid and errorMessage properties
 */
export const validateBio = (bio, maxLength = 200) => {
  if (!bio) {
    return {
      isValid: true, // Bio is optional
      errorMessage: "",
    };
  }
  
  if (bio.length > maxLength) {
    return {
      isValid: false,
      errorMessage: `Bio cannot exceed ${maxLength} characters`,
    };
  }
  
  return {
    isValid: true,
    errorMessage: "",
  };
};

/**
 * Validate an Instagram username
 * @param {String} instagramId - Instagram ID to validate
 * @returns {Object} - Validation result with isValid and errorMessage properties
 */
export const validateInstagramId = (instagramId) => {
  if (!instagramId || instagramId.trim() === "") {
    return {
      isValid: true, // Instagram ID is optional
      errorMessage: "",
    };
  }
  
  // Instagram username rules: letters, numbers, periods, and underscores
  // Cannot start with a period, and cannot have consecutive periods
  const instagramPattern = /^(?!.*\.\.)(?!.*\.$)[^\W][\w.]{0,29}$/;
  
  if (!instagramPattern.test(instagramId)) {
    return {
      isValid: false,
      errorMessage: "Please enter a valid Instagram username",
    };
  }
  
  return {
    isValid: true,
    errorMessage: "",
  };
};

/**
 * Validate a form with multiple fields
 * @param {Object} form - Form object with field values
 * @param {Object} validations - Object mapping field names to validation functions
 * @returns {Object} - Validation results with isValid and errors properties
 */
export const validateForm = (form, validations) => {
  const errors = {};
  let isValid = true;
  
  Object.keys(validations).forEach((fieldName) => {
    const value = form[fieldName];
    const validation = validations[fieldName];
    const result = validation(value);
    
    if (!result.isValid) {
      errors[fieldName] = result.errorMessage;
      isValid = false;
    }
  });
  
  return {
    isValid,
    errors,
  };
};

/**
 * Validate a number is within a specified range
 * @param {Number} value - Value to validate
 * @param {Number} min - Minimum allowed value
 * @param {Number} max - Maximum allowed value
 * @returns {Object} - Validation result with isValid and errorMessage properties
 */
export const validateNumberRange = (value, min, max) => {
  const numValue = Number(value);
  
  if (isNaN(numValue)) {
    return {
      isValid: false,
      errorMessage: "Please enter a valid number",
    };
  }
  
  if (numValue < min) {
    return {
      isValid: false,
      errorMessage: `Value must be at least ${min}`,
    };
  }
  
  if (numValue > max) {
    return {
      isValid: false,
      errorMessage: `Value cannot exceed ${max}`,
    };
  }
  
  return {
    isValid: true,
    errorMessage: "",
  };
};