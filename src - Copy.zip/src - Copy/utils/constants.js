// App constants for SaWish application

// Routes
export const ROUTES = {
  LOGIN: "/login",
  SIGNUP: "/signup",
  DASHBOARD: "/dashboard",
  SETTINGS: "/settings",
  PARTNER_INFO: "/partner-info",
  PARTNER_REQUEST: "/partner-request",
  CURRENCY: "/currency",
  DESIGN: "/design",
  GAMES: "/games",
  GIFTS: "/gifts",
  LINES: "/lines",
};

// Firebase collections
export const COLLECTIONS = {
  USERS: "users",
  CONVERSATIONS: "conversations",
  GIFTS: "gifts",
  PARTNER_REQUESTS: "partnerRequests",
};

// Character customization options
export const CHARACTER = {
  SKIN_COLORS: ["#FFDBAC", "#F1C27D", "#E0AC69", "#C68642", "#8D5524", "#5C3317"],
  HAIR_STYLES: {
    MALE: ["short", "medium", "long", "curly", "afro", "buzz"],
    FEMALE: ["short", "medium", "long", "curly", "braided", "ponytail"],
  },
  HAIR_COLORS: ["#000000", "#A52A2A", "#D4AF37", "#C19A6B", "#808080", "#FF0000"],
  CLOTHING_TYPES: {
    HEAD: "head", 
    GLASSES: "glasses",
    SHIRT: "shirt",
    COAT: "coat", 
    BOTTOM: "bottom",
    SHOES: "shoes",
    NECK: "neck",
    WATCH: "watch",
    ARM: "arm"
  }
};

// Games configuration
export const GAMES = {
  LUCK: {
    DICE: {
      MIN_BET: 50,
      MAX_BET: 5000,
      REWARD_MULTIPLIER: 2,
    },
    RPS: {
      MIN_BET: 50,
      MAX_BET: 2000,
      REWARD_MULTIPLIER: 1.5,
    },
  },
  SKILL: {
    SUDOKU: {
      EASY: {
        REWARD: 100,
        TIME_LIMIT: 600, // 10 minutes in seconds
      },
      MEDIUM: {
        REWARD: 150,
        TIME_LIMIT: 600,
      },
      HARD: {
        REWARD: 200,
        TIME_LIMIT: 600,
      },
    },
  },
  KNOWLEDGE: {
    QUIZ: {
      QUESTIONS_PER_SET: 10,
      CORRECT_REWARD: 15,
      WRONG_PENALTY: 3,
      BONUS: {
        FIFTY_PERCENT: 30,
        SEVENTY_PERCENT: 50,
        NINETY_PERCENT: 70,
        PERFECT: 100,
      },
    },
    MATH: {
      REWARD_PER_PROBLEM: 30,
    },
  },
};

// Gift categories
export const GIFTS = {
  CASUAL: {
    WATCHES: "watches",
    CLOTHING: "clothing",
    GLASSES: "glasses",
    BOOKS: "books",
    FLOWERS: "flowers",
    ACCESSORIES: "accessories",
  },
  ROMANTIC: {
    FLOWERS: "flowers",
    PREMIUM_CLOTHING: "premiumClothing",
    ANIMALS: "animals",
    NECK_ACCESSORIES: "neckAccessories",
    VEHICLES: "vehicles",
    TRIPS: "trips",
  },
};

// Line types and costs
export const LINES = {
  CASUAL: {
    COST_TO_SEND: 10,
    COST_TO_UNLOCK: 3,
  },
  ROMANTIC: {
    COST_TO_SEND: 20,
    COST_TO_UNLOCK: 5,
  },
};

// Streak rewards and milestones
export const STREAKS = {
  MILESTONES: {
    PERSONALITY_UNLOCK: 10,
    RELATIONSHIP_DESCRIPTION: 20,
    CONTACT_INFO: 30,
    ONE_YEAR: 365,
  },
  REWARDS: {
    ONE_YEAR_DISCOUNT: 25, // 25% discount
  },
  STREAK_WINDOW: 48, // 48 hours to maintain streak
};

// Currency constants
export const CURRENCY = {
  COIN_PACKAGES: [
    { amount: 1000, price: 100 },
    { amount: 10000, price: 1000 },
    { amount: 100000, price: 10000 },
  ],
  HEARTS_PER_SHARE: 10,
  HEARTS_PER_REFERRAL: 100,
  SHARE_COOLDOWN: 120, // 2 minutes in seconds
  DISCOUNTS: [
    { minHearts: 5000, maxItemPrice: 1000, discountPercent: 5 },
    { minHearts: 7000, minItemPrice: 1000, maxItemPrice: 5000, discountPercent: 10 },
    { minHearts: 10000, minItemPrice: 10000, discountPercent: 5 },
  ],
};

// Validation constants
export const VALIDATION = {
  MIN_PASSWORD_LENGTH: 8,
  USERNAME_PATTERN: /^[a-zA-Z0-9_]{3,20}$/,
  EMAIL_PATTERN: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
  PHONE_PATTERN: /^\+?[0-9]{10,15}$/,
};

// Sound effect types
export const SOUNDS = {
  PURCHASE: "purchase",
  GIFT_SEND: "gift_send",
  GIFT_RECEIVE: "gift_receive",
  LINE_SEND: "line_send",
  LINE_RECEIVE: "line_receive",
  GAME_WIN: "game_win",
  GAME_LOSE: "game_lose",
  ITEM_UNLOCK: "item_unlock",
  STREAK: "streak",
  BUTTON_CLICK: "button_click",
};

// Background categories
export const BACKGROUNDS = {
  DEFAULT: "park",
  LOCATIONS: ["park", "beach", "mountain", "city", "cafe", "restaurant"],
  PREMIUM: ["paris", "london", "new-york", "shimla", "bali", "tokyo"],
};

// Animation timings
export const ANIMATIONS = {
  SHORT: 300, // ms
  MEDIUM: 500, // ms
  LONG: 800, // ms
};

// App notification types
export const NOTIFICATIONS = {
  SUCCESS: "success",
  ERROR: "error",
  INFO: "info",
  WARNING: "warning",
};



