import { formatDistance } from 'date-fns';

/**
 * Format a timestamp to a relative time string (e.g., "2 days ago")
 * @param {Date|number} date - Date object or timestamp
 * @returns {String} - Formatted relative time
 */
export const formatRelativeTime = (date) => {
  return formatDistance(new Date(date), new Date(), { addSuffix: true });
};

/**
 * Format currency (coins) with comma separators
 * @param {Number} amount - Amount to format
 * @returns {String} - Formatted amount (e.g., "10,000")
 */
export const formatCurrency = (amount) => {
  return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

/**
 * Generate a random ID with specified length
 * @param {Number} length - Length of the ID
 * @returns {String} - Random ID
 */
export const generateRandomId = (length = 10) => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
};

/**
 * Calculate the current streak status and next streak deadline
 * @param {Date|number} lastStreakUpdate - Last streak update timestamp
 * @param {Number} streakWindow - Time window for streak in hours
 * @returns {Object} - Streak status information
 */
export const calculateStreakStatus = (lastStreakUpdate, streakWindow = 48) => {
  const now = new Date();
  const lastUpdate = new Date(lastStreakUpdate);
  const hoursDifference = (now - lastUpdate) / (1000 * 60 * 60);
  
  const deadline = new Date(lastUpdate);
  deadline.setHours(deadline.getHours() + streakWindow);
  
  return {
    active: hoursDifference < streakWindow,
    hoursLeft: Math.max(0, streakWindow - hoursDifference),
    deadline,
    formattedDeadline: formatRelativeTime(deadline),
  };
};

/**
 * Calculate the zodiac sign based on date of birth
 * @param {Date|String} dob - Date of birth
 * @returns {String} - Zodiac sign
 */
export const getZodiacSign = (dob) => {
  const date = new Date(dob);
  const day = date.getDate();
  const month = date.getMonth() + 1;
  
  if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return "Aries";
  if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return "Taurus";
  if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return "Gemini";
  if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return "Cancer";
  if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return "Leo";
  if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return "Virgo";
  if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return "Libra";
  if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return "Scorpio";
  if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return "Sagittarius";
  if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return "Capricorn";
  if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return "Aquarius";
  if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return "Pisces";
  
  return "Unknown";
};

/**
 * Calculate ELO rating change based on game outcome
 * @param {Number} currentRating - Current ELO rating
 * @param {Number} opponentRating - Opponent's ELO rating
 * @param {Number} outcome - Game outcome (1 for win, 0.5 for draw, 0 for loss)
 * @param {Number} kFactor - K-factor for the calculation (default: 32)
 * @returns {Number} - New ELO rating
 */
export const calculateEloChange = (currentRating, opponentRating, outcome, kFactor = 32) => {
  const expectedOutcome = 1 / (1 + Math.pow(10, (opponentRating - currentRating) / 400));
  const newRating = Math.round(currentRating + kFactor * (outcome - expectedOutcome));
  return newRating;
};

/**
 * Generate a shareable invite link for the application
 * @param {String} userId - User ID for referral tracking
 * @returns {String} - Shareable link
 */
export const generateInviteLink = (userId) => {
  // This would be replaced with your actual domain in production
  return `https://sawish.web.app/?invite=${userId}`;
};

/**
 * Extract URL parameters from the current window location
 * @returns {Object} - Object with URL parameters
 */
export const getUrlParams = () => {
  const params = {};
  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  
  for (const [key, value] of urlParams.entries()) {
    params[key] = value;
  }
  
  return params;
};

/**
 * Truncate text to a specified length with ellipsis
 * @param {String} text - Text to truncate
 * @param {Number} maxLength - Maximum length
 * @returns {String} - Truncated text
 */
export const truncateText = (text, maxLength = 100) => {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

/**
 * Calculate the age based on date of birth
 * @param {Date|String} dob - Date of birth
 * @returns {Number} - Age in years
 */
export const calculateAge = (dob) => {
  const birthDate = new Date(dob);
  const today = new Date();
  
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDifference = today.getMonth() - birthDate.getMonth();
  
  if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
};

/**
 * Group items in an array by a specific property
 * @param {Array} array - Array of objects
 * @param {String} property - Property to group by
 * @returns {Object} - Grouped objects
 */
export const groupBy = (array, property) => {
  return array.reduce((acc, obj) => {
    const key = obj[property];
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(obj);
    return acc;
  }, {});
};

/**
 * Debounce function to limit the rate at which a function is executed
 * @param {Function} func - Function to debounce
 * @param {Number} wait - Wait time in milliseconds
 * @returns {Function} - Debounced function
 */
export const debounce = (func, wait = 300) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};