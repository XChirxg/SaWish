

// App.js - Main Application Component
import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './firebase';
import './styles/global.css';

// Context Providers
import { AuthProvider } from './contexts/AuthContext';
import { UserProvider } from './contexts/UserContext';
import { PartnerProvider } from './contexts/PartnerContext';

// Pages
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import SettingsPage from './pages/SettingsPage';
import PartnerInfoPage from './pages/PartnerInfoPage';
import CurrencyPage from './pages/CurrencyPage';
import DesignPage from './pages/DesignPage';
import GamePage from './pages/GamePage';
import GiftPage from './pages/GiftPage';
import LinePage from './pages/LinePage';



// Components
import Notification from './components/common/Notification';

function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState({ show: false, message: '', type: 'info' });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  // Show notification function that can be passed down through contexts
  const showNotification = (message, type = 'info') => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification({ show: false, message: '', type: 'info' });
    }, 3000);
  };

  // Custom route guard component
  const PrivateRoute = ({ children }) => {
    return currentUser ? children : <Navigate to="/login" />;
  };

  // Redirect logged in users away from login page
  const PublicRoute = ({ children }) => {
    return !currentUser ? children : <Navigate to="/dashboard" />;
  };

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="loading-spinner"></div>
        <p>Loading SaWish...</p>
      </div>
    );
  }

  return (
    <Router>
      <AuthProvider value={{ currentUser, showNotification }}>
        <UserProvider>
          <PartnerProvider>
            {notification.show && (
              <Notification
                message={notification.message}
                type={notification.type}
                onClose={() => setNotification({ ...notification, show: false })}
              />
            )}
            <Routes>
              <Route 
                path="/login" 
                element={
                  <PublicRoute>
                    <LoginPage />
                  </PublicRoute>
                } 
              />
              <Route 
                path="/dashboard" 
                element={
                  <PrivateRoute>
                    <DashboardPage />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/settings" 
                element={
                  <PrivateRoute>
                    <SettingsPage />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/partner" 
                element={
                  <PrivateRoute>
                    <PartnerInfoPage />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/currency" 
                element={
                  <PrivateRoute>
                    <CurrencyPage />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/design" 
                element={
                  <PrivateRoute>
                    <DesignPage />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/games" 
                element={
                  <PrivateRoute>
                    <GamePage />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/gifts" 
                element={
                  <PrivateRoute>
                    <GiftPage />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/lines" 
                element={
                  <PrivateRoute>
                    <LinePage />
                  </PrivateRoute>
                } 
              />
              {/* Default route - redirect to dashboard if logged in, otherwise to login */}
              <Route 
                path="*" 
                element={currentUser ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} 
              />
            </Routes>
          </PartnerProvider>
        </UserProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;

