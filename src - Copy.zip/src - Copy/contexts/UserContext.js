


import React, { useState, useContext, createContext, useEffect } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from './AuthContext';
import { useUser } from './UserContext';

const PartnerContext = createContext();

export const usePartner = () => useContext(PartnerContext);

export const PartnerProvider = ({ children }) => {
  const { currentUser } = useAuth();
  const { user } = useUser();
  const [partner, setPartner] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPartnerData = async () => {
      if (!user || !user.partner || !user.partner.partnerId) {
        setPartner(null);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const partnerId = user.partner.partnerId;
        const partnerDocRef = doc(db, "users", partnerId);
        const partnerDoc = await getDoc(partnerDocRef);

        if (partnerDoc.exists()) {
          setPartner({
            id: partnerId,
            ...partnerDoc.data()
          });
        } else {
          setPartner(null);
          setError("Partner data not found");
        }
      } catch (err) {
        console.error("Error fetching partner data:", err);
        setError("Failed to load partner data");
      } finally {
        setLoading(false);
      }
    };

    fetchPartnerData();
  }, [user]);

  // Function to refresh partner data
  const refreshPartner = async () => {
    if (!user || !user.partner || !user.partner.partnerId) return;
    
    try {
      const partnerId = user.partner.partnerId;
      const partnerDocRef = doc(db, "users", partnerId);
      const partnerDoc = await getDoc(partnerDocRef);
      
      if (partnerDoc.exists()) {
        setPartner({
          id: partnerId,
          ...partnerDoc.data()
        });
      }
    } catch (err) {
      console.error("Error refreshing partner data:", err);
    }
  };

  // Function to update specific fields of partner data in context (without DB write)
  const updatePartnerState = (updatedFields) => {
    setPartner(prevPartner => {
      if (!prevPartner) return null;
      return { ...prevPartner, ...updatedFields };
    });
  };

  const value = {
    partner,
    loading,
    error,
    refreshPartner,
    updatePartnerState
  };

  return (
    <PartnerContext.Provider value={value}>
      {children}
    </PartnerContext.Provider>
  );
};

export default PartnerContext;
