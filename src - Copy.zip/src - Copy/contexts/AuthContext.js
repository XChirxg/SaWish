

import React, { useState, useContext, createContext, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../firebase';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail 
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  // Register new user
  const signup = async (email, password, username) => {
    try {
      // Check if username is available
      const usernameCheck = await checkUsernameAvailability(username);
      if (!usernameCheck.available) {
        throw new Error("Username is already taken");
      }

      // Create auth user
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Create user document in Firestore
      await setDoc(doc(db, "users", user.uid), {
        email: email,
        username: username,
        profile: {
          username: username,
          bio: "",
          gender: "",
          dob: null,
          zodiacSign: "",
          instagramId: "",
          phoneNumber: "",
          createdAt: serverTimestamp()
        },
        character: {
          skinColor: "",
          hairStyle: "",
          hairColor: "",
          accessories: []
        },
        currency: {
          coins: 100,  // Starting coins
          hearts: 0
        },
        achievements: {
          luck: 0,
          skill: 0,
          knowledge: 0
        },
        partner: null,
        dashboard: {
          background: "default",
          items: []
        },
        unlockedLines: {
          casual: [],
          romantic: []
        },
        unlockedGifts: {
          casual: [],
          romantic: []
        }
      });

      return { user };
    } catch (error) {
      console.error("Error in signup:", error);
      setError(error.message);
      throw error;
    }
  };

  // Check if username is available
  const checkUsernameAvailability = async (username) => {
    try {
      // Query for username in the users collection
      // This is a simplified approach - in a real app you might use a dedicated usernames collection
      const usernameQuery = await getDoc(doc(db, "usernames", username));
      
      return {
        available: !usernameQuery.exists(),
        message: usernameQuery.exists() ? "Username is already taken" : "Username is available"
      };
    } catch (error) {
      console.error("Error checking username:", error);
      throw error;
    }
  };

  // Login existing user
  const login = async (email, password) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      return userCredential.user;
    } catch (error) {
      console.error("Error in login:", error);
      setError(error.message);
      throw error;
    }
  };

  // Logout user
  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Error in logout:", error);
      setError(error.message);
      throw error;
    }
  };

  // Reset password
  const resetPassword = async (email) => {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error) {
      console.error("Error in resetPassword:", error);
      setError(error.message);
      throw error;
    }
  };

  const value = {
    currentUser,
    login,
    signup,
    logout,
    resetPassword,
    loading,
    error,
    checkUsernameAvailability
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
