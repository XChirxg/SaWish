

import React, { useContext, useState } from 'react';
import { UserContext } from '../../contexts/UserContext';
import BackButton from '../common/BackButton';
import CurrencyDisplay from '../common/CurrencyDisplay';
import '../../../src/styles/components/games/GamePage.css';

const GamePage = () => {
  const { user } = useContext(UserContext);
  const [selectedCategory, setSelectedCategory] = useState('luck');

  const games = {
    luck: [
      { id: 'diceRoll', name: 'Dice Roll', description: 'Choose a number and roll the dice. Match your number to win!', minBet: 50, image: 'dice.png' },
      { id: 'rockPaperScissors', name: 'Rock Paper Scissors', description: 'Play three rounds against the computer. Win at least 2 to get rewards!', minBet: 50, image: 'rps.png' },
    ],
    skill: [
      { id: 'sudoku', name: 'Sudoku', description: 'Complete the puzzle before time runs out. Different difficulty levels available.', reward: { easy: 100, medium: 150, hard: 200 }, image: 'sudoku.png' },
      { id: 'crossword', name: 'Crossword', description: 'Solve the crossword puzzle. Earn coins based on completion speed.', reward: { easy: 100, medium: 150, hard: 200 }, image: 'crossword.png' },
    ],
    knowledge: [
      { id: 'historyQuiz', name: 'World History Quiz', description: '10 questions about world history. 15 coins per correct answer.', reward: 15, image: 'history.png' },
      { id: 'geographyQuiz', name: 'Geography Quiz', description: '10 questions about world geography. 15 coins per correct answer.', reward: 15, image: 'geography.png' },
      { id: 'scienceQuiz', name: 'Science Quiz', description: '10 questions about science. 15 coins per correct answer.', reward: 15, image: 'science.png' },
      { id: 'mathProblems', name: 'Math Problems', description: 'Solve math challenges. 30 coins per correct solution.', reward: 30, image: 'math.png' },
    ]
  };

  const handleGameSelect = (gameId) => {
    // In a real implementation, this would navigate to the specific game component
    console.log(`Selected game: ${gameId}`);
    alert(`Navigating to ${gameId} game`);
  };

  return (
    <div className="game-page-container">
      <BackButton />
      <h1>Games</h1>
      
      <div className="currency-display-container">
        <CurrencyDisplay coins={user?.currency?.coins || 0} hearts={user?.currency?.hearts || 0} />
      </div>
      
      <div className="game-categories">
        <button 
          className={`category-btn ${selectedCategory === 'luck' ? 'active' : ''}`}
          onClick={() => setSelectedCategory('luck')}
        >
          Luck-based
        </button>
        <button 
          className={`category-btn ${selectedCategory === 'skill' ? 'active' : ''}`}
          onClick={() => setSelectedCategory('skill')}
        >
          Skill-based
        </button>
        <button 
          className={`category-btn ${selectedCategory === 'knowledge' ? 'active' : ''}`}
          onClick={() => setSelectedCategory('knowledge')}
        >
          Knowledge-based
        </button>
      </div>
      
      <div className="game-info">
        {selectedCategory === 'luck' && (
          <div className="category-info">
            <p>Bet coins and test your luck! Win big or lose your bet.</p>
            <p>Minimum bet: 50 coins</p>
          </div>
        )}
        
        {selectedCategory === 'skill' && (
          <div className="category-info">
            <p>Test your skills with puzzles and challenges.</p>
            <p>Entry fee: 25% of potential reward</p>
          </div>
        )}
        
        {selectedCategory === 'knowledge' && (
          <div className="category-info">
            <p>Show your knowledge in various subjects.</p>
            <p>No entry fee, earn coins per correct answer!</p>
          </div>
        )}
      </div>
      
      <div className="games-list">
        {games[selectedCategory].map(game => (
          <div key={game.id} className="game-card" onClick={() => handleGameSelect(game.id)}>
            <div className="game-image" style={{ backgroundImage: `url(/assets/images/games/${game.image})` }}></div>
            <div className="game-details">
              <h3 className="game-name">{game.name}</h3>
              <p className="game-description">{game.description}</p>
              
              {selectedCategory === 'luck' && (
                <div className="game-betting">
                  <p>Min Bet: {game.minBet} coins</p>
                </div>
              )}
              
              {selectedCategory === 'skill' && (
                <div className="game-reward">
                  <p>Rewards: {game.reward.easy} - {game.reward.hard} coins</p>
                </div>
              )}
              
              {selectedCategory === 'knowledge' && (
                <div className="game-reward">
                  <p>Reward: {game.reward} coins per correct answer</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      
      <div className="achievement-display">
        <h2>Your Game Ratings</h2>
        <div className="ratings">
          <div className="rating">
            <h3>Luck</h3>
            <div className="rating-value">{user?.achievements?.luck || 0}</div>
          </div>
          <div className="rating">
            <h3>Skill</h3>
            <div className="rating-value">{user?.achievements?.skill || 0}</div>
          </div>
          <div className="rating">
            <h3>Knowledge</h3>
            <div className="rating-value">{user?.achievements?.knowledge || 0}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GamePage;
