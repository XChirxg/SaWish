// SettingsPage.js - Settings Page
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase';
import BackButton from '../components/common/BackButton';

const SettingsPage = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({
    username: '',
    bio: '',
    instagramId: '',
    phoneNumber: '',
    soundEffectVolume: 50,
    musicVolume: 50
  });
  
  // In a real app, fetch from Firebase
  useEffect(() => {
    setUserData({
      username: 'User123',
      bio: 'Hello world!',
      instagramId: '',
      phoneNumber: '',
      soundEffectVolume: 50,
      musicVolume: 50
    });
  }, []);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData({
      ...userData,
      [name]: value
    });
  };
  
  const handleSliderChange = (e) => {
    const { name, value } = e.target;
    setUserData({
      ...userData,
      [name]: parseInt(value)
    });
  };
  
  const handleSave = async () => {
    // Save user data to Firebase
    console.log('Saving user data:', userData);
    // Navigate back after save
    navigate(-1);
  };
  
  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };
  
  const handleInstallApp = () => {
    // PWA installation logic
    console.log('Installing app');
  };
  
  const openFeedback = () => {
    window.open('https://instagram.com/chinurag', '_blank');
  };
  
  const openDeveloperSite = () => {
    window.open('https://chinurag.com', '_blank');
  };

  return (
    <div className="settings-page">
      <div className="settings-header">
        <BackButton onClick={() => navigate(-1)} />
        <h1>Settings</h1>
      </div>
      
      <div className="settings-content">
        <section className="profile-settings">
          <h2>Profile Settings</h2>
          
          <div className="form-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              name="username"
              value={userData.username}
              onChange={handleChange}
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="bio">Bio</label>
            <textarea
              id="bio"
              name="bio"
              value={userData.bio}
              onChange={handleChange}
              rows="3"
            ></textarea>
          </div>
          
          <div className="form-group">
            <label htmlFor="instagramId">Instagram ID (Shared with partner after 30 days streak)</label>
            <input
              type="text"
              id="instagramId"
              name="instagramId"
              value={userData.instagramId}
              onChange={handleChange}
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="phoneNumber">Phone Number (Shared with partner after 30 days streak)</label>
            <input
              type="tel"
              id="phoneNumber"
              name="phoneNumber"
              value={userData.phoneNumber}
              onChange={handleChange}
            />
          </div>
        </section>
        
        <section className="audio-settings">
          <h2>Audio Settings</h2>
          
          <div className="form-group">
            <label htmlFor="soundEffectVolume">Sound Effects: {userData.soundEffectVolume}%</label>
            <input
              type="range"
              id="soundEffectVolume"
              name="soundEffectVolume"
              min="0"
              max="100"
              value={userData.soundEffectVolume}
              onChange={handleSliderChange}
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="musicVolume">Music: {userData.musicVolume}%</label>
            <input
              type="range"
              id="musicVolume"
              name="musicVolume"
              min="0"
              max="100"
              value={userData.musicVolume}
              onChange={handleSliderChange}
            />
          </div>
        </section>
        
        <section className="app-settings">
          <h2>App Settings</h2>
          
          <button className="install-button" onClick={handleInstallApp}>
            Install App to Phone
          </button>
          
          <div className="about-section">
            <h3>About SaWish</h3>
            <p>SaWish - See a Wish coming true. A relationship-building game designed to help couples connect through meaningful interactions.</p>
            
            <div className="developer-info" onClick={openDeveloperSite}>
              Developed by Chinurag
            </div>
            
            <button className="feedback-button" onClick={openFeedback}>
              Send Feedback
            </button>
          </div>
          
          <button className="logout-button" onClick={handleLogout}>
            Logout
          </button>
        </section>
      </div>
      
      <button className="save-button" onClick={handleSave}>
        Save Changes
      </button>
    </div>
  );
};

export default SettingsPage;