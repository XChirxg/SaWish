
import React, { useContext, useState, useEffect } from 'react';
import { UserContext } from '../contexts/UserContext';
import BackButton from '../components/common/BackButton';
import useSound from '../hooks/useSound';
import Notification from '../components/common/Notification';

const DesignPage = () => {
  const { user, updateUserDesign } = useContext(UserContext);
  const { playSound } = useSound();
  
  const [activeCategory, setActiveCategory] = useState('character');
  const [notification, setNotification] = useState({ show: false, message: '', type: '' });
  
  // Character customization options
  const [characterOptions, setCharacterOptions] = useState({
    skinColor: [],
    hairColor: [],
    headWearables: [],
    eyeGlasses: [],
    shirts: [],
    coats: [],
    bottoms: [],
    shoes: [],
    neckAccessories: [],
    watches: [],
    armAccessories: []
  });
  
  // Items customization options
  const [itemOptions, setItemOptions] = useState({
    cheapGifts: [],
    middleGifts: [],
    vehicles: []
  });
  
  // Background options
  const [backgroundOptions, setBackgroundOptions] = useState([]);
  
  // Selected options
  const [selectedOptions, setSelectedOptions] = useState({
    character: {
      skinColor: user?.character?.skinColor || '',
      hairColor: user?.character?.hairColor || '',
      headWearable: user?.character?.headWearable || '',
      eyeGlasses: user?.character?.eyeGlasses || '',
      shirt: user?.character?.shirt || '',
      coat: user?.character?.coat || '',
      bottom: user?.character?.bottom || '',
      shoes: user?.character?.shoes || '',
      neckAccessory: user?.character?.neckAccessory || '',
      watch: user?.character?.watch || '',
      armAccessory: user?.character?.armAccessory || ''
    },
    item: user?.dashboard?.items || '',
    background: user?.dashboard?.background || ''
  });
  
  // Fetch available customization options
  useEffect(() => {
    // In a real implementation, these would come from a database
    // This is a placeholder for the structure
    
    // Character options
    setCharacterOptions({
      skinColor: ['fair', 'medium', 'olive', 'brown', 'dark'],
      hairColor: ['black', 'brown', 'blonde', 'red', 'gray', 'white'],
      headWearables: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'headWearable') || [],
      eyeGlasses: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'eyeGlasses') || [],
      shirts: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'shirt') || [],
      coats: user?.unlockedGifts?.romantic?.filter(gift => gift.category === 'coat') || [],
      bottoms: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'bottom') || [],
      shoes: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'shoes') || [],
      neckAccessories: user?.unlockedGifts?.romantic?.filter(gift => gift.category === 'neckAccessory') || [],
      watches: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'watch') || [],
      armAccessories: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'armAccessory') || []
    });
    
    // Item options
    setItemOptions({
      cheapGifts: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'cheapGift') || [],
      middleGifts: user?.unlockedGifts?.casual?.filter(gift => gift.category === 'middleGift') || [], 
      vehicles: user?.unlockedGifts?.romantic?.filter(gift => gift.category === 'vehicle') || []
    });
    
    // Background options
    setBackgroundOptions(
      user?.unlockedGifts?.romantic?.filter(gift => gift.category === 'background') || []
    );
  }, [user]);
  
  const handleCategoryChange = (category) => {
    setActiveCategory(category);
    playSound('menuChange');
  };
  
  const handleCharacterOptionSelect = (optionType, value) => {
    setSelectedOptions({
      ...selectedOptions,
      character: {
        ...selectedOptions.character,
        [optionType]: value
      }
    });
    playSound('selectOption');
  };
  
  const handleItemSelect = (item) => {
    setSelectedOptions({
      ...selectedOptions,
      item
    });
    playSound('selectOption');
  };
  
  const handleBackgroundSelect = (background) => {
    setSelectedOptions({
      ...selectedOptions,
      background
    });
    playSound('selectOption');
  };
  
  const handleSave = async () => {
    try {
      await updateUserDesign({
        character: selectedOptions.character,
        dashboard: {
          items: selectedOptions.item,
          background: selectedOptions.background
        }
      });
      
      playSound('saveSuccess');
      
      setNotification({
        show: true,
        message: 'Design saved successfully!',
        type: 'success'
      });
      
      // Auto hide notification after 3 seconds
      setTimeout(() => {
        setNotification({ show: false, message: '', type: '' });
      }, 3000);
    } catch (error) {
      console.error('Error saving design:', error);
      
      setNotification({
        show: true,
        message: 'Failed to save design. Please try again.',
        type: 'error'
      });
    }
  };
  
  // Render character customization options
  const renderCharacterOptions = () => {
    return (
      <div className="character-options">
        <div className="option-section">
          <h3>Basic</h3>
          
          <div className="option-group">
            <h4>Skin Color</h4>
            <div className="option-items">
              {characterOptions.skinColor.map((color, index) => (
                <div 
                  key={index}
                  className={`option-item ${selectedOptions.character.skinColor === color ? 'selected' : ''}`}
                  onClick={() => handleCharacterOptionSelect('skinColor', color)}
                >
                  <div className="color-preview" style={{ backgroundColor: color }}></div>
                  <span>{color}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="option-group">
            <h4>Hair Color</h4>
            <div className="option-items">
              {characterOptions.hairColor.map((color, index) => (
                <div 
                  key={index}
                  className={`option-item ${selectedOptions.character.hairColor === color ? 'selected' : ''}`}
                  onClick={() => handleCharacterOptionSelect('hairColor', color)}
                >
                  <div className="color-preview" style={{ backgroundColor: color }}></div>
                  <span>{color}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="option-section">
          <h3>Accessories</h3>
          
          {/* Head Wearables */}
          <div className="option-group">
            <h4>Head Wearables</h4>
            <div className="option-items">
              {characterOptions.headWearables.map((item, index) => (
                <div 
                  key={index}
                  className={`option-item ${selectedOptions.character.headWearable === item.id ? 'selected' : ''}`}
                  onClick={() => handleCharacterOptionSelect('headWearable', item.id)}
                >
                  <div className="item-image">
                    <img src={`/assets/images/characters/accessories/${item.image}`} alt={item.name} />
                  </div>
                  <span>{item.name}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Eye Glasses */}
          <div className="option-group">
            <h4>Eye Glasses</h4>
            <div className="option-items">
              {characterOptions.eyeGlasses.map((item, index) => (
                <div 
                  key={index}
                  className={`option-item ${selectedOptions.character.eyeGlasses === item.id ? 'selected' : ''}`}
                  onClick={() => handleCharacterOptionSelect('eyeGlasses', item.id)}
                >
                  <div className="item-image">
                    <img src={`/assets/images/characters/accessories/${item.image}`} alt={item.name} />
                  </div>
                  <span>{item.name}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Similar sections for shirts, coats, bottoms, shoes, neck accessories, watches, arm accessories */}
          {/* Add more sections as needed */}
        </div>
      </div>
    );
  };
  
  // Render item customization options
  const renderItemOptions = () => {
    return (
      <div className="item-options">
        <div className="option-section">
          <h3>Cheap Gifts</h3>
          <div className="option-items">
            {itemOptions.cheapGifts.map((item, index) => (
              <div 
                key={index}
                className={`option-item ${selectedOptions.item === item.id ? 'selected' : ''}`}
                onClick={() => handleItemSelect(item.id)}
              >
                <div className="item-image">
                  <img src={`/assets/images/items/${item.image}`} alt={item.name} />
                </div>
                <span>{item.name}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="option-section">
          <h3>Middle Gifts</h3>
          <div className="option-items">
            {itemOptions.middleGifts.map((item, index) => (
              <div 
                key={index}
                className={`option-item ${selectedOptions.item === item.id ? 'selected' : ''}`}
                onClick={() => handleItemSelect(item.id)}
              >
                <div className="item-image">
                  <img src={`/assets/images/items/${item.image}`} alt={item.name} />
                </div>
                <span>{item.name}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="option-section">
          <h3>Vehicles</h3>
          <div className="option-items">
            {itemOptions.vehicles.map((item, index) => (
              <div 
                key={index}
                className={`option-item ${selectedOptions.item === item.id ? 'selected' : ''}`}
                onClick={() => handleItemSelect(item.id)}
              >
                <div className="item-image">
                  <img src={`/assets/images/items/${item.image}`} alt={item.name} />
                </div>
                <span>{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };
  
  // Render background customization options
  const renderBackgroundOptions = () => {
    return (
      <div className="background-options">
        <div className="option-section">
          <h3>Backgrounds</h3>
          <div className="option-items">
            {backgroundOptions.map((item, index) => (
              <div 
                key={index}
                className={`option-item ${selectedOptions.background === item.id ? 'selected' : ''}`}
                onClick={() => handleBackgroundSelect(item.id)}
              >
                <div className="item-image">
                  <img src={`/assets/images/backgrounds/${item.image}`} alt={item.name} />
                </div>
                <span>{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="design-page">
      <BackButton />
      
      {notification.show && (
        <Notification 
          message={notification.message} 
          type={notification.type} 
          onClose={() => setNotification({ show: false, message: '', type: '' })}
        />
      )}
      
      <h1>Dashboard Design</h1>
      
      <div className="design-preview">
        {/* This would be a preview of the dashboard with current selections */}
        <div className="preview-background" style={{ backgroundImage: `url(/assets/images/backgrounds/${selectedOptions.background}.jpg)` }}>
          <div className="preview-item">
            {/* Item preview */}
          </div>
          <div className="preview-character">
            {/* Character preview */}
          </div>
        </div>
      </div>
      
      <div className="design-categories">
        <button 
          className={`category-button ${activeCategory === 'character' ? 'active' : ''}`}
          onClick={() => handleCategoryChange('character')}
        >
          Character
        </button>
        <button 
          className={`category-button ${activeCategory === 'item' ? 'active' : ''}`}
          onClick={() => handleCategoryChange('item')}
        >
          Items
        </button>
        <button 
          className={`category-button ${activeCategory === 'background' ? 'active' : ''}`}
          onClick={() => handleCategoryChange('background')}
        >
          Background
        </button>
      </div>
      
      <div className="design-options">
        {activeCategory === 'character' && renderCharacterOptions()}
        {activeCategory === 'item' && renderItemOptions()}
        {activeCategory === 'background' && renderBackgroundOptions()}
      </div>
      
      <button className="save-button" onClick={handleSave}>
        Save Design
      </button>
    </div>
  );
};

export default DesignPage;
