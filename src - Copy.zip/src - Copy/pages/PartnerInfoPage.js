
import React, { useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../contexts/UserContext';
import { PartnerContext } from '../contexts/PartnerContext';
import BackButton from '../components/common/BackButton';
import { getUserPartnerData, endPartnership, reconnectPartner } from '../services/database';
import { calculateStreakLevel, getZodiacSign } from '../utils/helpers';
import '../styles/components/PartnerInfoPage.css';

const PartnerInfoPage = () => {
  const navigate = useNavigate();
  const { user } = useContext(UserContext);
  const { partner, setPartner } = useContext(PartnerContext);
  const [loading, setLoading] = useState(true);
  const [endingPartnership, setEndingPartnership] = useState(false);
  const [countDown, setCountDown] = useState(200);
  const [endButtonEnabled, setEndButtonEnabled] = useState(false);
  const [reconnectTimer, setReconnectTimer] = useState(null);

  useEffect(() => {
    const fetchPartnerData = async () => {
      if (!user || !partner?.partnerId) {
        navigate('/dashboard');
        return;
      }

      try {
        // Fetch partner data here
        setLoading(false);
      } catch (error) {
        console.error("Error fetching partner data:", error);
        setLoading(false);
      }
    };

    fetchPartnerData();
  }, [user, partner, navigate]);

  useEffect(() => {
    let timer;
    if (endingPartnership && countDown > 0) {
      timer = setInterval(() => {
        setCountDown((prev) => prev - 1);
      }, 1000);
    }

    if (countDown === 0) {
      setEndButtonEnabled(true);
      clearInterval(timer);
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  }, [endingPartnership, countDown]);

  const handleEndPartnership = () => {
    setEndingPartnership(true);
  };

  const confirmEndPartnership = async () => {
    try {
      await endPartnership(user.uid, partner.partnerId);
      setEndingPartnership(false);
      setReconnectTimer(7); // 7 days to reconnect
      // Update UI to show reconnect option
    } catch (error) {
      console.error("Error ending partnership:", error);
    }
  };

  const handleReconnect = async () => {
    try {
      await reconnectPartner(user.uid, partner.partnerId);
      setReconnectTimer(null);
      // Refresh partner data
    } catch (error) {
      console.error("Error reconnecting with partner:", error);
    }
  };

  if (loading) {
    return <div className="loading">Loading partner information...</div>;
  }

  return (
    <div className="partner-info-page">
      <BackButton />
      <div className="partner-profile">
        <div className="partner-avatar">
          {/* Partner character display */}
          <div className="character-container">
            {/* Character will be displayed here */}
          </div>
        </div>
        
        <div className="partner-details">
          <h1>{partner?.username || 'Partner'}</h1>
          <p className="bio">{partner?.bio || 'No bio available'}</p>
          
          <div className="info-row">
            <span className="label">Zodiac Sign:</span>
            <span className="value">{partner?.zodiacSign || 'Unknown'}</span>
          </div>
          
          <div className="info-row">
            <span className="label">Hearts Gifted:</span>
            <span className="value">{partner?.heartsGifted || 0}</span>
          </div>
          
          <div className="info-row">
            <span className="label">Streak Level:</span>
            <span className="value">{calculateStreakLevel(partner?.streakCount || 0)}</span>
          </div>
          
          <div className="achievements">
            <h3>Achievements</h3>
            <div className="elo-ratings">
              <div className="elo-item">
                <span className="label">Luck:</span>
                <span className="value">{partner?.achievements?.luck || 1000}</span>
              </div>
              <div className="elo-item">
                <span className="label">Skill:</span>
                <span className="value">{partner?.achievements?.skill || 1000}</span>
              </div>
              <div className="elo-item">
                <span className="label">Knowledge:</span>
                <span className="value">{partner?.achievements?.knowledge || 1000}</span>
              </div>
            </div>
          </div>
          
          {/* Streak unlocks section */}
          <div className="streak-unlocks">
            <h3>Streak Unlocks</h3>
            {partner?.streakCount >= 10 && (
              <div className="unlock-item">
                <h4>Personality Description</h4>
                <p>{partner?.personalityDescription || 'Generate personality description based on zodiac sign and achievements'}</p>
              </div>
            )}
            
            {partner?.streakCount >= 20 && (
              <div className="unlock-item">
                <h4>Relationship Description</h4>
                <p>{partner?.relationshipDescription || 'Generate relationship description'}</p>
              </div>
            )}
            
            {partner?.streakCount >= 30 && (
              <div className="unlock-item">
                <h4>Personal Contact</h4>
                {partner?.instagramId && <p>Instagram: {partner.instagramId}</p>}
                {partner?.phoneNumber && <p>Phone: {partner.phoneNumber}</p>}
              </div>
            )}
            
            {partner?.streakCount >= 365 && (
              <div className="unlock-item">
                <h4>Anniversary Special</h4>
                <p>25% discount on any item under ₹500 from the store</p>
                <button className="get-discount-btn">Get Discount Code</button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="partnership-controls">
        {reconnectTimer ? (
          <div className="reconnect-section">
            <button className="reconnect-btn" onClick={handleReconnect}>
              Reconnect Again
            </button>
            <p className="timer-text">Time left: {reconnectTimer} days</p>
          </div>
        ) : (
          <>
            {endingPartnership ? (
              <div className="end-confirmation">
                <p className="warning">Warning: Ending the partnership will delete all progress!</p>
                <p className="timer">Please wait: {countDown} seconds</p>
                <button 
                  className={`confirm-end-btn ${endButtonEnabled ? 'enabled' : 'disabled'}`}
                  disabled={!endButtonEnabled}
                  onClick={confirmEndPartnership}
                >
                  Proceed
                </button>
                <button className="cancel-btn" onClick={() => setEndingPartnership(false)}>
                  Cancel
                </button>
              </div>
            ) : (
              <button className="end-partnership-btn" onClick={handleEndPartnership}>
                End Partnership
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default PartnerInfoPage;
Claude
