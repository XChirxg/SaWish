
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import BackButton from '../common/BackButton';
import { useUser } from '../../contexts/UserContext';
import { usePartner } from '../../contexts/PartnerContext';
import CurrencyDisplay from '../common/CurrencyDisplay';
import useSound from '../../hooks/useSound';

const GiftPage = () => {
  const navigate = useNavigate();
  const { user, updateUserCurrency } = useUser();
  const { partner, sendGift } = usePartner();
  const { playSound } = useSound();
  
  const [giftType, setGiftType] = useState('casual');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedGift, setSelectedGift] = useState(null);
  const [gifting, setGifting] = useState(false);
  const [giftStatus, setGiftStatus] = useState('');
  
  // Sample gift categories and items for the skeleton
  const giftCategories = {
    casual: [
      { id: 'watches', name: 'Watches & Accessories', icon: '⌚' },
      { id: 'casual_clothes', name: 'Casual Clothes', icon: '👕' },
      { id: 'glasses', name: 'Glasses', icon: '👓' },
      { id: 'books', name: 'Books', icon: '📚' },
      { id: 'food', name: 'Food & Drinks', icon: '🍕' },
      { id: 'games', name: 'Games', icon: '🎮' }
    ],
    romantic: [
      { id: 'flowers', name: 'Flowers', icon: '💐' },
      { id: 'fancy_clothes', name: 'Fancy Clothes', icon: '👔' },
      { id: 'animals', name: 'Animals', icon: '🐶' },
      { id: 'jewelry', name: 'Jewelry', icon: '💍' },
      { id: 'vehicles', name: 'Vehicles', icon: '🚗' },
      { id: 'trips', name: 'Trips', icon: '✈️' }
    ]
  };
  
  // Sample gifts in each category (would be loaded from database in a real app)
  const giftItems = {
    watches: [
      { id: 'watch1', name: 'Digital Watch', price: 100, image: 'watch1.png' },
      { id: 'watch2', name: 'Leather Band Watch', price: 150, image: 'watch2.png' },
      { id: 'bracelet1', name: 'Friendship Bracelet', price: 80, image: 'bracelet1.png' }
    ],
    casual_clothes: [
      { id: 'tshirt1', name: 'Casual T-Shirt', price: 70, image: 'tshirt1.png' },
      { id: 'jeans1', name: 'Denim Jeans', price: 120, image: 'jeans1.png' },
      { id: 'hat1', name: 'Baseball Cap', price: 50, image: 'hat1.png' }
    ],
    glasses: [
      { id: 'sunglasses1', name: 'Sunglasses', price: 90, image: 'sunglasses1.png' },
      { id: 'glasses1', name: 'Reading Glasses', price: 110, image: 'glasses1.png' }
    ],
    books: [
      { id: 'book1', name: 'Mystery Novel', price: 60, image: 'book1.png' },
      { id: 'book2', name: 'Fantasy Book', price: 65, image: 'book2.png' }
    ],
    food: [
      { id: 'cake', name: 'Birthday Cake', price: 40, image: 'cake.png' },
      { id: 'chocolate', name: 'Chocolate Box', price: 35, image: 'chocolate.png' }
    ],
    games: [
      { id: 'game1', name: 'Board Game', price: 85, image: 'game1.png' },
      { id: 'game2', name: 'Video Game', price: 95, image: 'game2.png' }
    ],
    
    flowers: [
      { id: 'rose_bouquet', name: 'Rose Bouquet', price: 150, image: 'rose_bouquet.png' },
      { id: 'tulips', name: 'Tulip Arrangement', price: 130, image: 'tulips.png' },
      { id: 'orchid', name: 'Exotic Orchid', price: 180, image: 'orchid.png' }
    ],
    fancy_clothes: [
      { id: 'dress1', name: 'Elegant Dress', price: 250, image: 'dress1.png' },
      { id: 'suit1', name: 'Formal Suit', price: 300, image: 'suit1.png' }
    ],
    animals: [
      { id: 'puppy', name: 'Puppy', price: 200, image: 'puppy.png' },
      { id: 'kitten', name: 'Kitten', price: 180, image: 'kitten.png' }
    ],
    jewelry: [
      { id: 'necklace1', name: 'Silver Necklace', price: 220, image: 'necklace1.png' },
      { id: 'earrings1', name: 'Gold Earrings', price: 190, image: 'earrings1.png' }
    ],
    vehicles: [
      { id: 'car1', name: 'Sports Car', price: 500, image: 'car1.png' },
      { id: 'motorcycle1', name: 'Motorcycle', price: 400, image: 'motorcycle1.png' }
    ],
    trips: [
      { id: 'beach', name: 'Beach Vacation', price: 450, image: 'beach.png' },
      { id: 'mountain', name: 'Mountain Retreat', price: 400, image: 'mountain.png' }
    ]
  };
  
  const handleGiftTypeChange = (type) => {
    setGiftType(type);
    setSelectedCategory(null);
    setSelectedGift(null);
    playSound('select');
  };
  
  const handleCategorySelect = (categoryId) => {
    setSelectedCategory(categoryId);
    setSelectedGift(null);
    playSound('select');
  };
  
  const handleGiftSelect = (gift) => {
    setSelectedGift(gift);
    playSound('select');
  };
  
  const handlePurchaseGift = async () => {
    if (!selectedGift || !partner) return;
    
    // Check if user has enough coins
    if (user.currency.coins < selectedGift.price) {
      setGiftStatus('Not enough coins to purchase this gift!');
      playSound('error');
      return;
    }
    
    setGifting(true);
    
    try {
      // Deduct coins from user
      updateUserCurrency(-selectedGift.price);
      
      // Send gift to partner
      await sendGift({
        giftId: selectedGift.id,
        giftType: giftType,
        value: selectedGift.price,
        categoryId: selectedCategory
      });
      
      playSound('giftSent');
      setGiftStatus('Gift sent successfully!');
      
      // Reset selection after a delay
      setTimeout(() => {
        setSelectedGift(null);
        setGiftStatus('');
      }, 3000);
    } catch (error) {
      setGiftStatus('Failed to send gift. Please try again.');
      playSound('error');
    } finally {
      setGifting(false);
    }
  };
  
  return (
    <div className="gift-page">
      <div className="top-bar">
        <BackButton onClick={() => navigate('/dashboard')} />
        <h2>Gift Shop</h2>
        <CurrencyDisplay coins={user.currency.coins} hearts={user.currency.hearts} />
      </div>
      
      <div className="gift-type-selector">
        <button 
          className={`gift-type-button ${giftType === 'casual' ? 'active' : ''}`}
          onClick={() => handleGiftTypeChange('casual')}
        >
          Casual Gifts
        </button>
        <button 
          className={`gift-type-button ${giftType === 'romantic' ? 'active' : ''}`}
          onClick={() => handleGiftTypeChange('romantic')}
        >
          Romantic Gifts
        </button>
      </div>
      
      {!selectedCategory ? (
        <div className="gift-categories">
          <h3>{giftType === 'casual' ? 'Casual Gift Categories' : 'Romantic Gift Categories'}</h3>
          <div className="category-grid">
            {giftCategories[giftType].map(category => (
              <div 
                key={category.id}
                className="category-card"
                onClick={() => handleCategorySelect(category.id)}
              >
                <div className="category-icon">{category.icon}</div>
                <div className="category-name">{category.name}</div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="gift-items">
          <h3>{giftCategories[giftType].find(c => c.id === selectedCategory)?.name}</h3>
          <button className="back-to-categories" onClick={() => setSelectedCategory(null)}>
            ← Back to Categories
          </button>
          
          <div className="gift-grid">
            {giftItems[selectedCategory]?.map(gift => (
              <div 
                key={gift.id}
                className={`gift-card ${selectedGift?.id === gift.id ? 'selected' : ''}`}
                onClick={() => handleGiftSelect(gift)}
              >
                <div className="gift-image">
                  <div className="placeholder-image">{gift.name.charAt(0)}</div>
                </div>
                <div className="gift-details">
                  <div className="gift-name">{gift.name}</div>
                  <div className="gift-price">{gift.price} coins</div>
                </div>
              </div>
            ))}
          </div>
          
          {selectedGift && (
            <div className="gift-confirmation">
              <h4>Selected Gift: {selectedGift.name}</h4>
              <p>Price: {selectedGift.price} coins</p>
              <button 
                className="purchase-button"
                onClick={handlePurchaseGift}
                disabled={gifting || user.currency.coins < selectedGift.price}
              >
                {gifting ? 'Sending...' : 'Send Gift'}
              </button>
              {giftStatus && <p className="gift-status">{giftStatus}</p>}
            </div>
          )}
        </div>
      )}
      
      {!partner && (
        <div className="no-partner-message">
          <p>You need to add a partner before you can send gifts!</p>
          <button onClick={() => navigate('/partner/request')} className="add-partner-button">
            Add Partner
          </button>
        </div>
      )}
    </div>
  );
};

export default GiftPage;
