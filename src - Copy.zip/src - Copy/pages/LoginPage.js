
// LoginPage.js - Login and Signup functionality
import React, { useState } from 'react';
import Login from '../components/auth/Login';
import Signup from '../components/auth/Signup';
import CharacterCreation from '../components/auth/CharacterCreation';

const LoginPage = () => {
  const [authStep, setAuthStep] = useState('login'); // 'login', 'signup', 'character'
  const [userData, setUserData] = useState({
    email: '',
    password: '',
    username: '',
    dob: '',
    gender: '',
    characterData: null
  });

  const handleLogin = (data) => {
    // Handle login logic
    console.log("Login data:", data);
  };

  const handleSignup = (data) => {
    // Handle signup logic and move to character creation
    setUserData({ ...userData, ...data });
    setAuthStep('character');
  };

  const handleCharacterCreation = (characterData) => {
    // Save character data and complete registration
    setUserData({ ...userData, characterData });
    // Perform final registration with Firebase
    console.log("Complete registration data:", { ...userData, characterData });
  };

  const handlePartnerInvite = (username) => {
    // Handle partner invitation
    console.log("Partner invite:", username);
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <h1 className="app-title">SaWish</h1>
        <p className="app-tagline">See a Wish coming true</p>
        
        {authStep === 'login' && (
          <>
            <Login onLogin={handleLogin} />
            <div className="auth-switcher">
              <p>Don't have an account? <button onClick={() => setAuthStep('signup')}>Sign Up</button></p>
            </div>
          </>
        )}
        
        {authStep === 'signup' && (
          <>
            <Signup onSignup={handleSignup} />
            <div className="auth-switcher">
              <p>Already have an account? <button onClick={() => setAuthStep('login')}>Log In</button></p>
            </div>
          </>
        )}
        
        {authStep === 'character' && (
          <CharacterCreation 
            gender={userData.gender}
            onComplete={handleCharacterCreation}
            onAddPartner={handlePartnerInvite}
          />
        )}
      </div>
    </div>
  );
};

export default LoginPage;
