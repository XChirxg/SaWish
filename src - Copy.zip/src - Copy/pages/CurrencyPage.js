

import React, { useContext, useState } from 'react';
import { UserContext } from '../contexts/UserContext';
import BackButton from '../components/common/BackButton';
import CurrencyDisplay from '../components/common/CurrencyDisplay';
import Notification from '../components/common/Notification';
import useSound from '../hooks/useSound';

const CurrencyPage = () => {
  const { user, updateUserCurrency } = useContext(UserContext);
  const { playSound } = useSound();
  
  const [notification, setNotification] = useState({ show: false, message: '', type: '' });
  const [shareTimer, setShareTimer] = useState(0);
  
  // Coin purchase options
  const coinOptions = [
    { amount: 1000, price: 100, label: '₹100' },
    { amount: 10000, price: 1000, label: '₹1,000' },
    { amount: 100000, price: 10000, label: '₹10,000' }
  ];
  
  // Heart discount options
  const discountOptions = [
    { item: 'Under ₹1,000 items', discount: '5%', hearts: 5000 },
    { item: '₹1,000 to ₹5,000 items', discount: '10%', hearts: 7000 },
    { item: 'Over ₹10,000 items', discount: '5%', hearts: 10000 }
  ];
  
  const handleCoinPurchase = (option) => {
    // In a real app, this would integrate with a payment gateway
    playSound('coinPurchase');
    
    // Mock implementation - just show a success notification
    setNotification({
      show: true,
      message: `Successfully purchased ${option.amount} coins!`,
      type: 'success'
    });
    
    // Auto hide notification after 3 seconds
    setTimeout(() => {
      setNotification({ show: false, message: '', type: '' });
    }, 3000);
  };
  
  const handleShareAndEarn = () => {
    if (shareTimer > 0) {
      setNotification({
        show: true,
        message: `Please wait ${shareTimer} seconds before sharing again`,
        type: 'error'
      });
      return;
    }
    
    // Generate a share link
    const shareLink = `https://sawish.com/invite/${user.id}`;
    
    // Copy to clipboard
    navigator.clipboard.writeText(shareLink);
    
    // Award hearts
    updateUserCurrency({
      hearts: user.currency.hearts + 10
    });
    
    playSound('heartEarned');
    
    // Show notification
    setNotification({
      show: true,
      message: 'Link copied! You earned 10 hearts for sharing',
      type: 'success'
    });
    
    // Set timer for 2 minutes (120 seconds)
    setShareTimer(120);
    const interval = setInterval(() => {
      setShareTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    // Auto hide notification after 3 seconds
    setTimeout(() => {
      setNotification({ show: false, message: '', type: '' });
    }, 3000);
  };
  
  const generateDiscountCode = (option) => {
    if (user.currency.hearts < option.hearts) {
      playSound('error');
      setNotification({
        show: true,
        message: `Not enough hearts! You need ${option.hearts} hearts`,
        type: 'error'
      });
      return;
    }
    
    // Generate a discount code
    const discountCode = `SAWISH-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    
    // Deduct hearts
    updateUserCurrency({
      hearts: user.currency.hearts - option.hearts
    });
    
    playSound('discountGenerated');
    
    // Show notification with the code
    setNotification({
      show: true,
      message: `Your discount code: ${discountCode}`,
      type: 'success'
    });
    
    // Auto hide notification after 10 seconds (longer so user can copy code)
    setTimeout(() => {
      setNotification({ show: false, message: '', type: '' });
    }, 10000);
  };

  return (
    <div className="currency-page">
      <BackButton />
      
      {notification.show && (
        <Notification 
          message={notification.message} 
          type={notification.type} 
          onClose={() => setNotification({ show: false, message: '', type: '' })}
        />
      )}
      
      <h1>Currency Management</h1>
      
      <div className="currency-cards">
        {/* Coins Card */}
        <div className="currency-card coins-card">
          <div className="card-header">
            <span className="coin-icon">🪙</span>
            <h2>Coins</h2>
          </div>
          
          <div className="card-content">
            <CurrencyDisplay type="coins" amount={user?.currency?.coins || 0} />
            
            <div className="purchase-options">
              <h3>Purchase Coins</h3>
              
              <div className="options-list">
                {coinOptions.map((option, index) => (
                  <button 
                    key={index}
                    className="purchase-button"
                    onClick={() => handleCoinPurchase(option)}
                  >
                    {option.amount} coins for {option.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Hearts Card */}
        <div className="currency-card hearts-card">
          <div className="card-header">
            <span className="heart-icon">❤️</span>
            <h2>Hearts</h2>
          </div>
          
          <div className="card-content">
            <CurrencyDisplay type="hearts" amount={user?.currency?.hearts || 0} />
            
            <div className="hearts-options">
              <button 
                className="share-button"
                onClick={handleShareAndEarn}
                disabled={shareTimer > 0}
              >
                {shareTimer > 0 ? `Share again in ${shareTimer}s` : 'Share & Earn 10 Hearts'}
              </button>
              
              <div className="discount-section">
                <h3>Generate Discount Codes</h3>
                
                <div className="discount-options">
                  {discountOptions.map((option, index) => (
                    <div key={index} className="discount-option">
                      <div className="discount-info">
                        <span className="discount-item">{option.item}</span>
                        <span className="discount-percent">{option.discount} discount</span>
                      </div>
                      <button 
                        className="generate-button"
                        onClick={() => generateDiscountCode(option)}
                      >
                        Generate for {option.hearts} ❤️
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Streak Card */}
        <div className="currency-card streak-card">
          <div className="card-header">
            <span className="streak-icon">⭐</span>
            <h2>Streak</h2>
          </div>
          
          <div className="card-content">
            <div className="streak-display">
              <span className="streak-number">{user?.partner?.streakCount || 0}</span>
              <span className="streak-label">Days</span>
            </div>
            
            <div className="streak-info">
              <h3>Streak Benefits</h3>
              <ul>
                <li>10 days: Unlock partner's personality description</li>
                <li>20 days: Unlock relationship compatibility</li>
                <li>30 days: Unlock contact information</li>
                <li>365 days: Special gift discount</li>
              </ul>
            </div>
          </div>
        </div>
        
        {/* Achievement Card */}
        <div className="currency-card achievement-card">
          <div className="card-header">
            <span className="achievement-icon">🏆</span>
            <h2>Achievements</h2>
          </div>
          
          <div className="card-content">
            <div className="achievement-ratings">
              <div className="rating">
                <span className="rating-label">Luck:</span>
                <span className="rating-value">{user?.achievements?.luck || 0}</span>
              </div>
              <div className="rating">
                <span className="rating-label">Skill:</span>
                <span className="rating-value">{user?.achievements?.skill || 0}</span>
              </div>
              <div className="rating">
                <span className="rating-label">Knowledge:</span>
                <span className="rating-value">{user?.achievements?.knowledge || 0}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="about-section">
        <h2>About SaWish</h2>
        <p>SaWish - See a Wish coming true. Build meaningful connections through shared experiences, gifts, and communication.</p>
        <p>SaWish helps you nurture your relationship through daily interaction, fostering deeper connections, and creating memorable moments together.</p>
        <p>Developed by Chinurag</p>
      </div>
    </div>
  );
};

export default CurrencyPage;
