import React, { useContext, useState, useEffect } from 'react';
import { UserContext } from '../contexts/UserContext';
import { PartnerContext } from '../contexts/PartnerContext';
import BackButton from '../components/common/BackButton';
import useSound from '../hooks/useSound';
import Notification from '../components/common/Notification';

const LinePage = () => {
  const { user, updateUserCurrency } = useContext(UserContext);
  const { partner } = useContext(PartnerContext);
  const { playSound } = useSound();
  
  const [activeCategory, setActiveCategory] = useState('casual');
  const [notification, setNotification] = useState({ show: false, message: '', type: '' });
  const [conversations, setConversations] = useState([]);
  const [lines, setLines] = useState({
    casual: [],
    romantic: []
  });
  const [unlockedLines, setUnlockedLines] = useState({
    casual: [],
    romantic: []
  });
  const [selectedLine, setSelectedLine] = useState(null);
  const [emoji, setEmoji] = useState('');

  // Emojis available for reactions
  const availableEmojis = ['❤️', '😊', '😂', '👍', '😍', '🥰', '😮', '😢', '🤔', '👏'];

  // Fetch conversations and lines
  useEffect(() => {
    // In a real app, these would come from a database
    // Simulating conversations and available lines
    
    // Simulate getting conversations
    const fetchedConversations = [
      {
        id: '1',
        senderId: partner?.partnerId,
        lineType: 'casual',
        lineId: 'c1',
        sentAt: new Date(Date.now() - 86400000), // 1 day ago
        reaction: '❤️'
      },
      {
        id: '2',
        senderId: user?.id,
        lineType: 'romantic',
        lineId: 'r1',
        sentAt: new Date(Date.now() - 43200000), // 12 hours ago
        reaction: '😊'
      },
      // Add more past conversations if needed
    ];
    
    setConversations(fetchedConversations);
    
    // Simulate getting available lines
    const fetchedLines = {
      casual: [
        { id: 'c1', text: 'Did you know that honey never spoils? Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still perfectly good to eat!' },
        { id: 'c2', text: 'I was thinking about you today and wondered what made you smile recently?' },
        { id: 'c3', text: 'If you could travel anywhere in the world right now, where would you go?' },
        { id: 'c4', text: 'Whats your favorite memory from our time together?' },
        { id: 'c5', text: 'I saw something today that reminded me of you.' },
        // Add more casual lines
      ],
      romantic: [
        { id: 'r1', text: 'Every time I think of you, I get butterflies in my stomach.' },
        { id: 'r2', text: 'I never believed in soulmates until I met you.' },
        { id: 'r3', text: 'You make me want to be a better person every day.' },
        { id: 'r4', text: 'I love the way your eyes light up when you talk about something youre passionate about.' },
        { id: 'r5', text: 'My favorite place in the world is anywhere by your side.' },
        // Add more romantic lines
      ]
    };
    
    setLines(fetchedLines);
    
    // Set unlocked lines based on user data
    if (user?.unlockedLines) {
      setUnlockedLines(user.unlockedLines);
    }
  }, [user?.id, partner?.partnerId]);

  const handleCategoryChange = (category) => {
    setActiveCategory(category);
    setSelectedLine(null);
    playSound('menuChange');
  };
  
  const handleLineSelect = (line) => {
    setSelectedLine(line);
    playSound('selectLine');
  };
  
  const handleUnlockLine = async (lineId, lineType) => {
    const unlockCost = lineType === 'casual' ? 3 : 5;
    
    if (user.currency.hearts < unlockCost) {
      playSound('error');
      setNotification({
        show: true,
        message: `Not enough hearts! You need ${unlockCost} hearts to unlock this line.`,
        type: 'error'
      });
      return;
    }
    
    try {
      // Update user currency
      await updateUserCurrency({
        hearts: user.currency.hearts - unlockCost
      });
      
      // Update unlocked lines
      const updatedUnlockedLines = { ...unlockedLines };
      updatedUnlockedLines[lineType] = [...updatedUnlockedLines[lineType], lineId];
      setUnlockedLines(updatedUnlockedLines);
      
      playSound('unlock');
      
      setNotification({
        show: true,
        message: 'Line unlocked successfully!',
        type: 'success'
      });
      
      // Auto hide notification after 3 seconds
      setTimeout(() => {
        setNotification({ show: false, message: '', type: '' });
      }, 3000);
    } catch (error) {
      console.error('Error unlocking line:', error);
      
      setNotification({
        show: true,
        message: 'Failed to unlock line. Please try again.',
        type: 'error'
      });
    }
  };
  
  const handleSendLine = async () => {
    if (!selectedLine) return;
    
    const sendCost = activeCategory === 'casual' ? 10 : 20;
    
    if (user.currency.hearts < sendCost) {
      playSound('error');
      setNotification({
        show: true,
        message: `Not enough hearts! You need ${sendCost} hearts to send this line.`,
        type: 'error'
      });
      return;
    }
    
    try {
      // Update user currency
      await updateUserCurrency({
        hearts: user.currency.hearts - sendCost
      });
      
      // Add the new conversation
      const newConversation = {
        id: Date.now().toString(),
        senderId: user.id,
        lineType: activeCategory,
        lineId: selectedLine.id,
        sentAt: new Date(),
        reaction: ''
      };
      
      setConversations([...conversations, newConversation]);
      
      playSound(activeCategory === 'casual' ? 'sendCasualLine' : 'sendRomanticLine');
      
      setNotification({
        show: true,
        message: 'Line sent successfully!',
        type: 'success'
      });
      
      // Reset selection
      setSelectedLine(null);
      
      // Auto hide notification after 3 seconds
      setTimeout(() => {
        setNotification({ show: false, message: '', type: '' });
      }, 3000);
    } catch (error) {
      console.error('Error sending line:', error);
      
      setNotification({
        show: true,
        message: 'Failed to send line. Please try again.',
        type: 'error'
      });
    }
  };
  
  const handleReact = async (conversationId, emoji) => {
    // Find the conversation to update
    const updatedConversations = conversations.map(conv => {
      if (conv.id === conversationId) {
        return { ...conv, reaction: emoji };
      }
      return conv;
    });
    
    setConversations(updatedConversations);
    setEmoji('');
    
    playSound('emojiReact');
  };

  // Get line text by ID
  const getLineText = (lineId, lineType) => {
    const lineList = lineType === 'casual' ? lines.casual : lines.romantic;
    const line = lineList.find(l => l.id === lineId);
    return line ? line.text : '';
  };
  
  // Check if a line is unlocked
  const isLineUnlocked = (lineId, lineType) => {
    return unlockedLines[lineType].includes(lineId);
  };

  return (
    <div className="line-page">
      <BackButton />
      
      {notification.show && (
        <Notification 
          message={notification.message} 
          type={notification.type} 
          onClose={() => setNotification({ show: false, message: '', type: '' })}
        />
      )}
      
      <h1>Lines</h1>
      
      <div className="conversation-area">
        {conversations.map((conv) => {
          const isSentByUser = conv.senderId === user.id;
          const lineText = getLineText(conv.lineId, conv.lineType);
          
          return (
            <div 
              key={conv.id} 
              className={`conversation-bubble ${isSentByUser ? 'sent' : 'received'}`}
            >
              <div className="conversation-content">
                <p>{lineText}</p>
                <span className="conversation-time">
                  {new Date(conv.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              
              {conv.reaction && (
                <div className="conversation-reaction">
                  {conv.reaction}
                </div>
              )}
              
              {/* Only show react button for received messages without reactions */}
              {!isSentByUser && !conv.reaction && (
                <div className="react-section">
                  <button 
                    className="react-button"
                    onClick={() => setEmoji(emoji === '' ? conv.id : '')}
                  >
                    React
                  </button>
                  
                  {emoji === conv.id && (
                    <div className="emoji-picker">
                      {availableEmojis.map((em, index) => (
                        <button 
                          key={index}
                          className="emoji-button"
                          onClick={() => handleReact(conv.id, em)}
                        >
                          {em}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      <div className="line-selection">
        <div className="category-tabs">
          <button 
            className={`category-tab ${activeCategory === 'casual' ? 'active' : ''}`}
            onClick={() => handleCategoryChange('casual')}
          >
            Casual Lines
          </button>
          <button 
            className={`category-tab ${activeCategory === 'romantic' ? 'active' : ''}`}
            onClick={() => handleCategoryChange('romantic')}
          >
            Romantic Lines
          </button>
        </div>
        
        <div className="line-list">
          {activeCategory === 'casual' ? (
            <>
              <h3>Casual Lines</h3>
              <div className="lines">
                {lines.casual.map((line) => {
                  const isUnlocked = isLineUnlocked(line.id, 'casual');
                  
                  return (
                    <div 
                      key={line.id}
                      className={`line-item ${isUnlocked ? 'unlocked' : 'locked'} ${selectedLine?.id === line.id ? 'selected' : ''}`}
                      onClick={() => isUnlocked && handleLineSelect(line)}
                    >
                      {isUnlocked ? (
                        <>
                          <p>{line.text}</p>
                        </>
                      ) : (
                        <>
                          <p className="blurred-line">This line is locked. Unlock to view and send.</p>
                          <button 
                            className="unlock-button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUnlockLine(line.id, 'casual');
                            }}
                          >
                            Unlock for 3 Hearts
                          </button>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </>
          ) : (
            <>
              <h3>Romantic Lines</h3>
              <div className="lines">
                {lines.romantic.map((line) => {
                  const isUnlocked = isLineUnlocked(line.id, 'romantic');
                  
                  return (
                    <div 
                      key={line.id}
                      className={`line-item ${isUnlocked ? 'unlocked' : 'locked'} ${selectedLine?.id === line.id ? 'selected' : ''}`}
                      onClick={() => isUnlocked && handleLineSelect(line)}
                    >
                      {isUnlocked ? (
                        <>
                          <p>{line.text}</p>
                        </>
                      ) : (
                        <>
                          <p className="blurred-line">This line is locked. Unlock to view and send.</p>
                          <button 
                            className="unlock-button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUnlockLine(line.id, 'romantic');
                            }}
                          >
                            Unlock for 5 Hearts
                          </button>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </div>
      
      <div className="send-section">
        <div className="send-preview">
          {selectedLine ? (
            <p>{selectedLine.text}</p>
          ) : (
            <p className="placeholder">Select a line to send...</p>
          )}
        </div>
        
        <button 
          className="send-button"
          disabled={!selectedLine}
          onClick={handleSendLine}
        >
          Send for {activeCategory === 'casual' ? '10' : '20'} Hearts
        </button>
      </div>
    </div>
  );
};

export default LinePage;