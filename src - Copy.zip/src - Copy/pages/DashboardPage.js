// DashboardPage.js - Main Dashboard Page
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import TopBar from '../components/dashboard/TopBar';
import Background from '../components/dashboard/Background';
import Items from '../components/dashboard/Items';
import Characters from '../components/dashboard/Characters';

const DashboardPage = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [partnerData, setPartnerData] = useState(null);
  const [hasPartner, setHasPartner] = useState(false);
  
  // Placeholder data for development
  useEffect(() => {
    // This would be replaced with a Firebase fetch
    setUserData({
      username: 'User123',
      coins: 500,
      hearts: 200,
      streak: 5,
      character: {
        skinColor: '#f5d0a9',
        hairStyle: 'style1',
        hairColor: 'brown',
        outfit: 'casual1'
      },
      background: 'park',
      items: ['flower1']
    });
    
    // Simulate if user has partner
    setHasPartner(true);
    
    if (hasPartner) {
      setPartnerData({
        username: 'Partner456',
        character: {
          skinColor: '#e6b8b8',
          hairStyle: 'style2',
          hairColor: 'blonde',
          outfit: 'casual2'
        }
      });
    }
  }, [hasPartner]);

  // Navigation handlers
  const navigateToSettings = () => navigate('/settings');
  const navigateToPartner = () => navigate('/partner');
  const navigateToDesign = () => navigate('/design');
  const navigateToCurrency = () => navigate('/currency');
  const navigateToGames = () => navigate('/games');
  const navigateToGifts = () => navigate('/gifts');
  const navigateToLines = () => navigate('/lines');

  if (!userData) {
    return <div className="loading">Loading dashboard...</div>;
  }

  return (
    <div className="dashboard-page">
      {/* Top Bar Section */}
      <TopBar 
        username={userData.username}
        coins={userData.coins}
        hearts={userData.hearts}
        streak={userData.streak}
        onSettingsClick={navigateToSettings}
        onCurrencyClick={navigateToCurrency}
        onDesignClick={navigateToDesign}
      />
      
      {/* Main Content Area */}
      <div className="dashboard-content">
        <Background background={userData.background} />
        
        <Items items={userData.items} />
        
        <Characters 
          userCharacter={userData.character}
          partnerCharacter={partnerData?.character}
          hasPartner={hasPartner}
          onUserClick={navigateToSettings}
          onPartnerClick={navigateToPartner}
          onAddPartner={() => navigate('/partner')}
        />
      </div>
      
      {/* Bottom Navigation */}
      <div className="bottom-nav">
        <button onClick={navigateToGames} className="nav-button">
          Game
        </button>
        <button onClick={navigateToGifts} className="nav-button">
          Gift
        </button>
        <button onClick={navigateToLines} className="nav-button">
          Line
        </button>
      </div>
    </div>
  );
};

export default DashboardPage;