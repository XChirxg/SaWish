

import { useState, useEffect, useContext } from 'react';
import { UserContext } from '../contexts/UserContext';
import { PartnerContext } from '../contexts/PartnerContext';
import { doc, getDoc, updateDoc, increment } from 'firebase/firestore';
import { db } from '../firebase';

// Custom hook for managing sound effects in the app
const useSound = () => {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [volume, setVolume] = useState(0.5); // 0.0 to 1.0
  const { user } = useContext(UserContext);
  const { partner } = useContext(PartnerContext);
  
  // Load audio settings from local storage or user settings
  useEffect(() => {
    // Try to get settings from local storage first
    const storedSoundEnabled = localStorage.getItem('soundEnabled');
    const storedVolume = localStorage.getItem('soundVolume');
    
    if (storedSoundEnabled !== null) {
      setSoundEnabled(storedSoundEnabled === 'true');
    }
    
    if (storedVolume !== null) {
      setVolume(parseFloat(storedVolume));
    }
    
    // If user is authenticated, fetch settings from database
    const fetchSettings = async () => {
      if (user?.uid) {
        try {
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists() && userDoc.data().settings) {
            const settings = userDoc.data().settings;
            
            // Update state with user settings if they exist
            if (settings.soundEnabled !== undefined) {
              setSoundEnabled(settings.soundEnabled);
              localStorage.setItem('soundEnabled', settings.soundEnabled);
            }
            
            if (settings.soundVolume !== undefined) {
              setVolume(settings.soundVolume);
              localStorage.setItem('soundVolume', settings.soundVolume);
            }
          }
        } catch (error) {
          console.error("Error fetching sound settings:", error);
        }
      }
    };
    
    fetchSettings();
  }, [user]);
  
  // Save sound settings
  const saveSettings = async (enabled, vol) => {
    // Update local storage
    localStorage.setItem('soundEnabled', enabled);
    localStorage.setItem('soundVolume', vol);
    
    // Update state
    setSoundEnabled(enabled);
    setVolume(vol);
    
    // Update database if user is authenticated
    if (user?.uid) {
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          'settings.soundEnabled': enabled,
          'settings.soundVolume': vol
        });
      } catch (error) {
        console.error("Error saving sound settings:", error);
      }
    }
  };
  
  // Function to play a sound
  const playSound = (soundName) => {
    if (!soundEnabled) return;
    
    // Create audio element
    const audio = new Audio(`/assets/sounds/${soundName}.mp3`);
    audio.volume = volume;
    
    // Play the sound
    audio.play()
      .catch(error => {
        console.error(`Error playing sound ${soundName}:`, error);
      });
  };
  
  // Toggle sound on/off
  const toggleSound = () => {
    saveSettings(!soundEnabled, volume);
  };
  
  // Set volume level
  const setVolumeLevel = (level) => {
    // Ensure level is between 0 and 1
    const normalizedLevel = Math.max(0, Math.min(1, level));
    saveSettings(soundEnabled, normalizedLevel);
  };
  
  return {
    soundEnabled,
    volume,
    playSound,
    toggleSound,
    setVolumeLevel
  };
};

export default useSound;
