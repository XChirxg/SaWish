import { useState, useEffect, useContext } from 'react';
import { UserContext } from '../contexts/UserContext';
import { PartnerContext } from '../contexts/PartnerContext';
import { getGifts, purchaseGift, sendGift } from '../services/database';
import useSound from './useSound';

const useGifts = () => {
  const { user, updateUserCurrency } = useContext(UserContext);
  const { partner } = useContext(PartnerContext);
  const { playSound } = useSound();
  
  const [casualGifts, setCasualGifts] = useState([]);
  const [romanticGifts, setRomanticGifts] = useState([]);
  const [unlockedGifts, setUnlockedGifts] = useState({
    casual: [],
    romantic: []
  });
  const [loading, setLoading] = useState(true);
  
  // Fetch available gifts and user's unlocked gifts
  useEffect(() => {
    const fetchGifts = async () => {
      try {
        setLoading(true);
        
        // Fetch gifts from database
        const giftsData = await getGifts();
        
        // Separate gifts by type
        const casual = giftsData.filter(gift => gift.giftType === 'casual');
        const romantic = giftsData.filter(gift => gift.giftType === 'romantic');
        
        setCasualGifts(casual);
        setRomanticGifts(romantic);
        
        // Set unlocked gifts if user data is available
        if (user?.unlockedGifts) {
          setUnlockedGifts(user.unlockedGifts);
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching gifts:', error);
        setLoading(false);
      }
    };
    
    fetchGifts();
  }, [user?.id]);
  
  // Purchase and send gift to partner
  const purchaseAndSendGift = async (giftId, giftType) => {
    try {
      if (!partner) {
        throw new Error('No partner found to send gift to');
      }
      
      // Find gift data
      const giftList = giftType === 'casual' ? casualGifts : romanticGifts;
      const gift = giftList.find(g => g.id === giftId);
      
      if (!gift) {
        throw new Error('Gift not found');
      }
      
      // Check if user has enough coins
      if (user.currency.coins < gift.price) {
        playSound('errorSound');
        throw new Error('Not enough coins to purchase this gift');
      }
      
      // Purchase gift (deduct coins)
      await updateUserCurrency({
        coins: user.currency.coins - gift.price
      });
      
      // Send gift to partner
      await sendGift({
        senderId: user.id,
        receiverId: partner.partnerId,
        giftType,
        giftId,
        value: gift.value,
        sentAt: new Date()
      });
      
      // Play success sound
      playSound('giftSent');
      
      // Update streak if needed
      // This would typically be handled in a useStreaks hook or in the database service
      
      return {
        success: true,
        message: `You sent ${gift.name} to your partner!`
      };
    } catch (error) {
      console.error('Error sending gift:', error);
      return {
        success: false,
        message: error.message
      };
    }
  };
  
  // Unlock gift (make it available to send)
  const unlockGift = async (giftId, giftType) => {
    try {
      // Find gift data
      const giftList = giftType === 'casual' ? casualGifts : romanticGifts;
      const gift = giftList.find(g => g.id === giftId);
      
      if (!gift) {
        throw new Error('Gift not found');
      }
      
      // Check if user has enough hearts to unlock
      const unlockCost = giftType === 'casual' ? 3 : 5;
      
      if (user.currency.hearts < unlockCost) {
        playSound('errorSound');
        throw new Error('Not enough hearts to unlock this gift');
      }
      
      // Deduct hearts
      await updateUserCurrency({
        hearts: user.currency.hearts - unlockCost
      });
      
      // Add to unlocked gifts
      const updatedUnlocked = { ...unlockedGifts };
      updatedUnlocked[giftType] = [...updatedUnlocked[giftType], giftId];
      
      // Update in database
      await purchaseGift(user.id, giftType, giftId);
      
      // Update state
      setUnlockedGifts(updatedUnlocked);
      
      // Play success sound
      playSound('giftUnlocked');
      
      return {
        success: true,
        message: `You unlocked ${gift.name}!`
      };
    } catch (error) {
      console.error('Error unlocking gift:', error);
      return {
        success: false,
        message: error.message
      };
    }
  };
  
  return {
    casualGifts,
    romanticGifts,
    unlockedGifts,
    loading,
    purchaseAndSendGift,
    unlockGift
  };
};

export default useGifts;