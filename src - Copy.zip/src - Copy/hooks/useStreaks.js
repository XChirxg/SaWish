import React, { useState, useEffect } from 'react';
import { useUser } from '../hooks/useStreaks';
import { usePartner } from '../contexts/PartnerContext';
import BackButton from '../components/common/BackButton';
import CurrencyDisplay from '../components/common/CurrencyDisplay';
import Notification from '../components/common/Notification';

const useStreaks = () => {
  const { user } = useUser();
  const { partner } = usePartner();
  
  const [streakData, setStreakData] = useState({
    currentStreak: 0,
    lastUpdated: null,
    level: 0,
    nextMilestone: 0,
    rewards: []
  });
  
  useEffect(() => {
    if (user && user.partner) {
      const streak = user.partner.streakCount || 0;
      const lastUpdated = user.partner.streakLastUpdated ? 
        new Date(user.partner.streakLastUpdated.toDate()) : null;
      const level = user.partner.streakLevel || 0;
      
      // Calculate next milestone
      let nextMilestone = 0;
      const milestones = [10, 20, 30, 365];
      
      for (const milestone of milestones) {
        if (streak < milestone) {
          nextMilestone = milestone;
          break;
        }
      }
      
      // Determine rewards
      const rewards = [];
      if (streak >= 10) rewards.push("Partner's personality description");
      if (streak >= 20) rewards.push("Relationship description");
      if (streak >= 30) rewards.push("Contact information access");
      if (streak >= 365) rewards.push("Special 25% discount on gifts");
      
      setStreakData({
        currentStreak: streak,
        lastUpdated,
        level,
        nextMilestone,
        rewards
      });
    }
  }, [user, partner]);
  
  // Check if streak is at risk (more than 40 hours since last update)
  const isStreakAtRisk = () => {
    if (!streakData.lastUpdated) return false;
    
    const now = new Date();
    const timeDiff = now - streakData.lastUpdated;
    const hoursDiff = timeDiff / (1000 * 60 * 60);
    
    return hoursDiff > 40;
  };
  
  return {
    ...streakData,
    isStreakAtRisk: isStreakAtRisk()
  };
};

export { useStreaks };