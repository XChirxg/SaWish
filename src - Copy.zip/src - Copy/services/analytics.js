


import { getAnalytics, logEvent } from 'firebase/analytics';

// Initialize analytics
let analytics = null;

/**
 * Initialize the analytics service
 * @param {Object} app - Firebase app instance
 */
export const initAnalytics = (app) => {
  if (typeof window !== 'undefined') {
    analytics = getAnalytics(app);
  }
};

/**
 * Log a user sign up event
 * @param {string} method - The sign up method used
 */
export const logSignUp = (method) => {
  if (!analytics) return;
  
  logEvent(analytics, 'sign_up', {
    method: method
  });
};

/**
 * Log a user login event
 * @param {string} method - The login method used
 */
export const logLogin = (method) => {
  if (!analytics) return;
  
  logEvent(analytics, 'login', {
    method: method
  });
};

/**
 * Log a character customization event
 * @param {string} userId - User ID
 * @param {Object} changes - Character customization changes
 */
export const logCharacterCustomization = (userId, changes) => {
  if (!analytics) return;
  
  logEvent(analytics, 'character_customization', {
    user_id: userId,
    changes: JSON.stringify(changes)
  });
};

/**
 * Log a partner request event
 * @param {string} senderId - Sender user ID
 * @param {string} method - The method used to send the request (username, link, etc.)
 */
export const logPartnerRequest = (senderId, method) => {
  if (!analytics) return;
  
  logEvent(analytics, 'partner_request', {
    sender_id: senderId,
    method: method
  });
};

/**
 * Log a partner connection event
 * @param {string} user1Id - First user ID
 * @param {string} user2Id - Second user ID
 */
export const logPartnerConnection = (user1Id, user2Id) => {
  if (!analytics) return;
  
  logEvent(analytics, 'partner_connection', {
    user1_id: user1Id,
    user2_id: user2Id
  });
};

/**
 * Log a game played event
 * @param {string} userId - User ID
 * @param {string} gameType - Type of game (luck, skill, knowledge)
 * @param {string} gameName - Name of the game
 * @param {boolean} won - Whether the user won
 * @param {number} coinsWon - Number of coins won/lost
 */
export const logGamePlayed = (userId, gameType, gameName, won, coinsWon) => {
  if (!analytics) return;
  
  logEvent(analytics, 'game_played', {
    user_id: userId,
    game_type: gameType,
    game_name: gameName,
    result: won ? 'won' : 'lost',
    coins: coinsWon
  });
};

/**
 * Log a gift sent event
 * @param {string} senderId - Sender user ID
 * @param {string} receiverId - Receiver user ID
 * @param {string} giftType - Type of gift (casual, romantic)
 * @param {string} giftId - ID of the gift
 * @param {number} value - Value of the gift
 */
export const logGiftSent = (senderId, receiverId, giftType, giftId, value) => {
  if (!analytics) return;
  
  logEvent(analytics, 'gift_sent', {
    sender_id: senderId,
    receiver_id: receiverId,
    gift_type: giftType,
    gift_id: giftId,
    value: value
  });
};

/**
 * Log a line sent event
 * @param {string} senderId - Sender user ID
 * @param {string} receiverId - Receiver user ID
 * @param {string} lineType - Type of line (casual, romantic)
 * @param {string} lineId - ID of the line
 */
export const logLineSent = (senderId, receiverId, lineType, lineId) => {
  if (!analytics) return;
  
  logEvent(analytics, 'line_sent', {
    sender_id: senderId,
    receiver_id: receiverId,
    line_type: lineType,
    line_id: lineId
  });
};

/**
 * Log a streak update event
 * @param {string} userId - User ID
 * @param {string} partnerId - Partner user ID
 * @param {number} streakCount - Current streak count
 * @param {string} action - Streak action (increase, reset)
 */
export const logStreakUpdate = (userId, partnerId, streakCount, action) => {
  if (!analytics) return;
  
  logEvent(analytics, 'streak_update', {
    user_id: userId,
    partner_id: partnerId,
    streak_count: streakCount,
    action: action
  });
};

/**
 * Log a currency update event
 * @param {string} userId - User ID
 * @param {string} currencyType - Type of currency (coins, hearts)
 * @param {number} amount - Amount of currency
 * @param {string} source - Source of currency update (game, gift, purchase)
 */
export const logCurrencyUpdate = (userId, currencyType, amount, source) => {
  if (!analytics) return;
  
  logEvent(analytics, 'currency_update', {
    user_id: userId,
    currency_type: currencyType,
    amount: amount,
    source: source
  });
};

/**
 * Log a page view event
 * @param {string} pageName - Name of the page viewed
 * @param {string} userId - User ID
 */
export const logPageView = (pageName, userId) => {
  if (!analytics) return;
  
  logEvent(analytics, 'page_view', {
    page_name: pageName,
    user_id: userId
  });
};

/**
 * Log an error event
 * @param {string} errorCode - Error code
 * @param {string} errorMessage - Error message
 * @param {string} userId - User ID (optional)
 */
export const logError = (errorCode, errorMessage, userId = null) => {
  if (!analytics) return;
  
  const eventParams = {
    error_code: errorCode,
    error_message: errorMessage
  };
  
  if (userId) {
    eventParams.user_id = userId;
  }
  
  logEvent(analytics, 'app_error', eventParams);
};

export default {
  initAnalytics,
  logSignUp,
  logLogin,
  logCharacterCustomization,
  logPartnerRequest,
  logPartnerConnection,
  logGamePlayed,
  logGiftSent,
  logLineSent,
  logStreakUpdate,
  logCurrencyUpdate,
  logPageView,
  logError
};
Claude
