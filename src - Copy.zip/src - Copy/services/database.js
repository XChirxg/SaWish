import { 
  doc, 
  collection, 
  addDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit,
  serverTimestamp,
  Timestamp,
  increment,
  arrayUnion,
  arrayRemove
} from 'firebase/firestore';
import { db } from '../firebase';
import { ERROR_CODES } from '../utils/constants';
import { logPartnerConnection, logStreakUpdate, logGiftSent, logLineSent } from './analytics';

/**
 * Get user data by user ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} - User data
 */
export const getUserData = async (userId) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (!userDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    return {
      uid: userId,
      ...userDoc.data()
    };
  } catch (error) {
    console.error("Error getting user data:", error);
    throw error;
  }
};

/**
 * Get user by username
 * @param {string} username - Username to search for
 * @returns {Promise<Object|null>} - User data or null if not found
 */
export const getUserByUsername = async (username) => {
  try {
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('profile.username', '==', username));
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      return null;
    }
    
    const userDoc = querySnapshot.docs[0];
    return {
      uid: userDoc.id,
      ...userDoc.data()
    };
  } catch (error) {
    console.error("Error getting user by username:", error);
    throw error;
  }
};

/**
 * Update user character
 * @param {string} userId - User ID
 * @param {Object} characterData - Character data to update
 * @returns {Promise<void>}
 */
export const updateUserCharacter = async (userId, characterData) => {
  try {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, { character: characterData });
  } catch (error) {
    console.error("Error updating user character:", error);
    throw error;
  }
};

/**
 * Update user dashboard
 * @param {string} userId - User ID
 * @param {Object} dashboardData - Dashboard data to update
 * @returns {Promise<void>}
 */
export const updateUserDashboard = async (userId, dashboardData) => {
  try {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, { dashboard: dashboardData });
  } catch (error) {
    console.error("Error updating user dashboard:", error);
    throw error;
  }
};

/**
 * Update user currency
 * @param {string} userId - User ID
 * @param {string} currencyType - Type of currency (coins, hearts)
 * @param {number} amount - Amount to add (positive) or subtract (negative)
 * @returns {Promise<Object>} - Updated currency data
 */
export const updateUserCurrency = async (userId, currencyType, amount) => {
  try {
    const userRef = doc(db, 'users', userId);
    
    // Use increment to atomically update the currency
    await updateDoc(userRef, {
      [`currency.${currencyType}`]: increment(amount)
    });
    
    // Get updated data
    const updatedUser = await getDoc(userRef);
    return updatedUser.data().currency;
  } catch (error) {
    console.error("Error updating user currency:", error);
    throw error;
  }
};

/**
 * Send partner request
 * @param {string} senderId - Sender user ID
 * @param {string} receiverId - Receiver user ID
 * @returns {Promise<string>} - Request ID
 */
export const sendPartnerRequest = async (senderId, receiverId) => {
  try {
    // Check if users exist
    const senderDoc = await getDoc(doc(db, 'users', senderId));
    const receiverDoc = await getDoc(doc(db, 'users', receiverId));
    
    if (!senderDoc.exists() || !receiverDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    // Check if sender already has a partner
    const senderData = senderDoc.data();
    if (senderData.partner && senderData.partner.partnerId) {
      throw new Error(ERROR_CODES.ALREADY_HAS_PARTNER);
    }
    
    // Check if receiver already has a partner
    const receiverData = receiverDoc.data();
    if (receiverData.partner && receiverData.partner.partnerId) {
      throw new Error(ERROR_CODES.RECEIVER_HAS_PARTNER);
    }
    
    // Create request with expiration date (7 days from now)
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + 7);
    
    const requestRef = await addDoc(collection(db, 'partnerRequests'), {
      senderId,
      receiverId,
      status: 'pending',
      createdAt: serverTimestamp(),
      expiresAt: Timestamp.fromDate(expirationDate)
    });
    
    return requestRef.id;
  } catch (error) {
    console.error("Error sending partner request:", error);
    throw error;
  }
};

/**
 * Accept partner request
 * @param {string} requestId - Request ID
 * @returns {Promise<void>}
 */
export const acceptPartnerRequest = async (requestId) => {
  try {
    const requestRef = doc(db, 'partnerRequests', requestId);
    const requestDoc = await getDoc(requestRef);
    
    if (!requestDoc.exists()) {
      throw new Error(ERROR_CODES.REQUEST_NOT_FOUND);
    }
    
    const requestData = requestDoc.data();
    
    if (requestData.status !== 'pending') {
      throw new Error(ERROR_CODES.REQUEST_ALREADY_PROCESSED);
    }
    
    // Update request status
    await updateDoc(requestRef, {
      status: 'accepted'
    });
    
    // Update both users' partner information
    const user1Ref = doc(db, 'users', requestData.senderId);
    const user2Ref = doc(db, 'users', requestData.receiverId);
    
    const partnerData1 = {
      partnerId: requestData.receiverId,
      streakCount: 0,
      streakLastUpdated: serverTimestamp(),
      streakLevel: 1,
      heartsReceived: 0
    };
    
    const partnerData2 = {
      partnerId: requestData.senderId,
      streakCount: 0,
      streakLastUpdated: serverTimestamp(),
      streakLevel: 1,
      heartsReceived: 0
    };
    
    await updateDoc(user1Ref, { partner: partnerData1 });
    await updateDoc(user2Ref, { partner: partnerData2 });
    
    // Create conversation document
    await addDoc(collection(db, 'conversations'), {
      participants: {
        user1Id: requestData.senderId,
        user2Id: requestData.receiverId
      },
      lines: []
    });
    
    // Log partner connection event
    logPartnerConnection(requestData.senderId, requestData.receiverId);
  } catch (error) {
    console.error("Error accepting partner request:", error);
    throw error;
  }
};

/**
 * Get user partner data
 * @param {string} userId - User ID
 * @returns {Promise<Object>} - Partner data
 */
export const getUserPartnerData = async (userId) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    
    if (!userDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    const userData = userDoc.data();
    
    if (!userData.partner || !userData.partner.partnerId) {
      return null;
    }
    
    const partnerDoc = await getDoc(doc(db, 'users', userData.partner.partnerId));
    
    if (!partnerDoc.exists()) {
      throw new Error(ERROR_CODES.PARTNER_NOT_FOUND);
    }
    
    const partnerData = partnerDoc.data();
    
    return {
      uid: userData.partner.partnerId,
      username: partnerData.profile.username,
      bio: partnerData.profile.bio,
      zodiacSign: partnerData.profile.zodiacSign,
      streakCount: userData.partner.streakCount,
      streakLevel: userData.partner.streakLevel,
      heartsReceived: userData.partner.heartsReceived,
      achievements: partnerData.achievements,
      character: partnerData.character,
      // Only include these if streak is high enough
      instagramId: userData.partner.streakCount >= 30 ? partnerData.profile.instagramId : null,
      phoneNumber: userData.partner.streakCount >= 30 ? partnerData.profile.phoneNumber : null
    };
  } catch (error) {
    console.error("Error getting partner data:", error);
    throw error;
  }
};

/**
 * Update streak between partners
 * @param {string} userId - User ID
 * @param {string} partnerId - Partner ID
 * @returns {Promise<Object>} - Updated streak data
 */
export const updateStreak = async (userId, partnerId) => {
  try {
    const userRef = doc(db, 'users', userId);
    const partnerRef = doc(db, 'users', partnerId);
    
    const userDoc = await getDoc(userRef);
    const partnerDoc = await getDoc(partnerRef);
    
    if (!userDoc.exists() || !partnerDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    const userData = userDoc.data();
    const partnerData = partnerDoc.data();
    
    if (!userData.partner || userData.partner.partnerId !== partnerId) {
      throw new Error(ERROR_CODES.NOT_PARTNERS);
    }
    
    // Check if streak was already updated today
    const lastUpdated = userData.partner.streakLastUpdated?.toDate() || new Date(0);
    const now = new Date();
    const isSameDay = lastUpdated.toDateString() === now.toDateString();
    
    if (isSameDay) {
      return userData.partner;
    }
    
    // Check if streak is within 48 hours window
    const hoursDiff = (now - lastUpdated) / (1000 * 60 * 60);
    const streakIncrement = hoursDiff <= 48 ? 1 : 0;
    const newStreakCount = streakIncrement ? userData.partner.streakCount + 1 : 1;
    
    // Calculate streak level based on count
    const newStreakLevel = calculateStreakLevel(newStreakCount);
    
    // Update both users' streak data
    const updatedPartnerData = {
      'partner.streakCount': newStreakCount,
      'partner.streakLastUpdated': serverTimestamp(),
      'partner.streakLevel': newStreakLevel
    };
    
    await updateDoc(userRef, updatedPartnerData);
    await updateDoc(partnerRef, updatedPartnerData);
    
    // Log streak update
    logStreakUpdate(
      userId, 
      partnerId, 
      newStreakCount,
      streakIncrement ? 'increase' : 'reset'
    );
    
    return {
      ...userData.partner,
      streakCount: newStreakCount,
      streakLevel: newStreakLevel
    };
  } catch (error) {
    console.error("Error updating streak:", error);
    throw error;
  }
};

/**
 * Send gift to partner
 * @param {string} senderId - Sender user ID
 * @param {string} receiverId - Receiver user ID
 * @param {string} giftType - Type of gift (casual, romantic)
 * @param {string} giftId - ID of the gift
 * @param {number} value - Value of the gift
 * @returns {Promise<string>} - Gift record ID
 */
export const sendGift = async (senderId, receiverId, giftType, giftId, value) => {
  try {
    // Check if users are partners
    const senderDoc = await getDoc(doc(db, 'users', senderId));
    const receiverDoc = await getDoc(doc(db, 'users', receiverId));
    
    if (!senderDoc.exists() || !receiverDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    const senderData = senderDoc.data();
    
    if (!senderData.partner || senderData.partner.partnerId !== receiverId) {
      throw new Error(ERROR_CODES.NOT_PARTNERS);
    }
    
    // Check if sender has enough coins
    if (senderData.currency.coins < value) {
      throw new Error(ERROR_CODES.INSUFFICIENT_COINS);
    }
    
    // Deduct coins from sender
    await updateUserCurrency(senderId, 'coins', -value);
    
    // Add gift to unlocked gifts for receiver
    await updateDoc(doc(db, 'users', receiverId), {
      [`unlockedGifts.${giftType}`]: arrayUnion(giftId)
    });
    
    // Update receiver's hearts (value of gifts received)
    await updateDoc(doc(db, 'users', receiverId), {
      'partner.heartsReceived': increment(value)
    });
    
    // Update streak
    await updateStreak(senderId, receiverId);
    
    // Create gift record
    const giftRef = await addDoc(collection(db, 'gifts'), {
      senderId,
      receiverId,
      giftType,
      giftId,
      value,
      sentAt: serverTimestamp()
    });
    
    // Log gift sent event
    logGiftSent(senderId, receiverId, giftType, giftId, value);
    
    return giftRef.id;
  } catch (error) {
    console.error("Error sending gift:", error);
    throw error;
  }
};

/**
 * Send line to partner
 * @param {string} senderId - Sender user ID
 * @param {string} receiverId - Receiver user ID
 * @param {string} lineType - Type of line (casual, romantic)
 * @param {string} lineId - ID of the line
 * @returns {Promise<string>} - Line record ID
 */
export const sendLine = async (senderId, receiverId, lineType, lineId) => {
  try {
    // Check if users are partners
    const senderDoc = await getDoc(doc(db, 'users', senderId));
    
    if (!senderDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    const senderData = senderDoc.data();
    
    if (!senderData.partner || senderData.partner.partnerId !== receiverId) {
      throw new Error(ERROR_CODES.NOT_PARTNERS);
    }
    
    // Check if sender has the line unlocked
    if (!senderData.unlockedLines[lineType].includes(lineId)) {
      throw new Error(ERROR_CODES.LINE_NOT_UNLOCKED);
    }
    
    // Calculate hearts cost
    const heartsCost = lineType === 'casual' ? 10 : 20;
    
    // Check if sender has enough hearts
    if (senderData.currency.hearts < heartsCost) {
      throw new Error(ERROR_CODES.INSUFFICIENT_HEARTS);
    }
    
    // Deduct hearts from sender
    await updateUserCurrency(senderId, 'hearts', -heartsCost);
    
    // Get conversation between users
    const conversationsRef = collection(db, 'conversations');
    const q = query(
      conversationsRef,
      where('participants.user1Id', 'in', [senderId, receiverId]),
      where('participants.user2Id', 'in', [senderId, receiverId])
    );
    
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      throw new Error(ERROR_CODES.CONVERSATION_NOT_FOUND);
    }
    
    const conversationDoc = querySnapshot.docs[0];
    const conversationRef = doc(db, 'conversations', conversationDoc.id);
    
    // Add line to conversation
    const lineData = {
      senderId,
      lineType,
      lineId,
      sentAt: serverTimestamp(),
      reaction: null
    };
    
    await updateDoc(conversationRef, {
      lines: arrayUnion(lineData)
    });
    
    // Log line sent event
    logLineSent(senderId, receiverId, lineType, lineId);
    
    return lineId;
  } catch (error) {
    console.error("Error sending line:", error);
    throw error;
  }
};

/**
 * React to a line
 * @param {string} conversationId - Conversation ID
 * @param {string} lineId - Line ID
 * @param {string} emoji - Emoji reaction
 * @returns {Promise<void>}
 */
export const reactToLine = async (conversationId, lineId, emoji) => {
  try {
    const conversationRef = doc(db, 'conversations', conversationId);
    const conversationDoc = await getDoc(conversationRef);
    
    if (!conversationDoc.exists()) {
      throw new Error(ERROR_CODES.CONVERSATION_NOT_FOUND);
    }
    
    const conversationData = conversationDoc.data();
    const lines = conversationData.lines || [];
    
    // Find the line index
    const lineIndex = lines.findIndex(line => line.lineId === lineId);
    
    if (lineIndex === -1) {
      throw new Error(ERROR_CODES.LINE_NOT_FOUND);
    }
    
    // Update the reaction
    lines[lineIndex].reaction = emoji;
    
    await updateDoc(conversationRef, {
      lines: lines
    });
  } catch (error) {
    console.error("Error reacting to line:", error);
    throw error;
  }
};

/**
 * Unlock a line for a user
 * @param {string} userId - User ID
 * @param {string} lineType - Type of line (casual, romantic)
 * @param {string} lineId - ID of the line
 * @returns {Promise<void>}
 */
export const unlockLine = async (userId, lineType, lineId) => {
  try {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    const userData = userDoc.data();
    
    // Check if already unlocked
    if (userData.unlockedLines[lineType].includes(lineId)) {
      return;
    }
    
    // Calculate hearts cost
    const heartsCost = lineType === 'casual' ? 3 : 5;
    
    // Check if user has enough hearts
    if (userData.currency.hearts < heartsCost) {
      throw new Error(ERROR_CODES.INSUFFICIENT_HEARTS);
    }
    
    // Deduct hearts
    await updateUserCurrency(userId, 'hearts', -heartsCost);
    
    // Add line to unlocked lines
    await updateDoc(userRef, {
      [`unlockedLines.${lineType}`]: arrayUnion(lineId)
    });
  } catch (error) {
    console.error("Error unlocking line:", error);
    throw error;
  }
};

/**
 * Get potential partners for a user
 * @param {string} userId - User ID
 * @param {string} gender - User's gender
 * @param {Date} dob - User's date of birth
 * @param {number} limit - Maximum number of results
 * @returns {Promise<Array>} - Array of potential partners
 */
export const getPotentialPartners = async (userId, gender, dob, resultLimit = 10) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    
    if (!userDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    // Get users of opposite gender without partners
    const oppositeGender = gender === 'male' ? 'female' : 'male';
    
    const usersRef = collection(db, 'users');
    const q = query(
      usersRef,
      where('profile.gender', '==', oppositeGender),
      where('partner', '==', null),
      limit(resultLimit * 2) // Fetch more to filter by age
    );
    
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      return [];
    }
    
    // Calculate age difference and sort by similarity
    const userAge = calculateAge(dob);
    const potentialPartners = querySnapshot.docs
      .map(doc => {
        const data = doc.data();
        const partnerAge = calculateAge(data.profile.dob);
        const ageDiff = Math.abs(userAge - partnerAge);
        
        return {
          uid: doc.id,
          username: data.profile.username,
          bio: data.profile.bio,
          zodiacSign: data.profile.zodiacSign,
          ageDiff
        };
      })
      .filter(partner => partner.uid !== userId)
      .sort((a, b) => a.ageDiff - b.ageDiff)
      .slice(0, resultLimit);
    
    return potentialPartners;
  } catch (error) {
    console.error("Error getting potential partners:", error);
    throw error;
  }
};

/**
 * End partnership between users
 * @param {string} userId - User ID
 * @param {string} partnerId - Partner ID
 * @returns {Promise<void>}
 */
export const endPartnership = async (userId, partnerId) => {
  try {
    const userRef = doc(db, 'users', userId);
    const partnerRef = doc(db, 'users', partnerId);
    
    const userDoc = await getDoc(userRef);
    const partnerDoc = await getDoc(partnerRef);
    
    if (!userDoc.exists() || !partnerDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    const userData = userDoc.data();
    
    if (!userData.partner || userData.partner.partnerId !== partnerId) {
      throw new Error(ERROR_CODES.NOT_PARTNERS);
    }
    
    // Create reconnect request
    const reconnectRequestRef = await addDoc(collection(db, 'partnerRequests'), {
      senderId: userId,
      receiverId: partnerId,
      status: 'reconnect',
      createdAt: serverTimestamp(),
      expiresAt: Timestamp.fromDate(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)) // 7 days
    });
    
    // Update user's partner data
    await updateDoc(userRef, {
      partner: null
    });
    
    // Update partner's partner data
    await updateDoc(partnerRef, {
      partner: null
    });
    
    return reconnectRequestRef.id;
  } catch (error) {
    console.error("Error ending partnership:", error);
    throw error;
  }
};

/**
 * Reconnect with partner
 * @param {string} userId - User ID
 * @param {string} partnerId - Partner ID
 * @returns {Promise<void>}
 */
export const reconnectPartner = async (userId, partnerId) => {
  try {
    // Find reconnect request
    const requestsRef = collection(db, 'partnerRequests');
    const q = query(
      requestsRef,
      where('senderId', '==', userId),
      where('receiverId', '==', partnerId),
      where('status', '==', 'reconnect')
    );
    
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      throw new Error(ERROR_CODES.REQUEST_NOT_FOUND);
    }
    
    const requestDoc = querySnapshot.docs[0];
    const requestData = requestDoc.data();
    
    // Check if request is still valid
    const expirationDate = requestData.expiresAt.toDate();
    if (expirationDate < new Date()) {
      throw new Error(ERROR_CODES.REQUEST_EXPIRED);
    }
    
    // Accept the request (similar to acceptPartnerRequest)
    await updateDoc(doc(db, 'partnerRequests', requestDoc.id), {
      status: 'accepted'
    });
    
    // Update both users' partner information
    const userRef = doc(db, 'users', userId);
    const partnerRef = doc(db, 'users', partnerId);
    
    const previousUserDoc = await getDoc(userRef);
    const previousUserData = previousUserDoc.data();
    
    // Get previous streak if it exists
    let streakCount = 0;
    
    if (previousUserData.partner && previousUserData.partner.streakCount) {
      streakCount = previousUserData.partner.streakCount;
    }
    
    const partnerData = {
      partnerId,
      streakCount,
      streakLastUpdated: serverTimestamp(),
      streakLevel: calculateStreakLevel(streakCount),
      heartsReceived: 0
    };
    
    const partnerPartnerData = {
      partnerId: userId,
      streakCount,
      streakLastUpdated: serverTimestamp(),
      streakLevel: calculateStreakLevel(streakCount),
      heartsReceived: 0
    };
    
    await updateDoc(userRef, { partner: partnerData });
    await updateDoc(partnerRef, { partner: partnerPartnerData });
    
    // Log partner connection event
    logPartnerConnection(userId, partnerId);
  } catch (error) {
    console.error("Error reconnecting with partner:", error);
    throw error;
  }
};

/**
 * Calculate streak level based on streak count
 * @param {number} streakCount - Streak count
 * @returns {number} - Streak level
 */
const calculateStreakLevel = (streakCount) => {
  if (streakCount >= 365) return 5;
  if (streakCount >= 30) return 4;
  if (streakCount >= 20) return 3;
  if (streakCount >= 10) return 2;
  return 1;
};

/**
 * Calculate age from date of birth
 * @param {string} dob - Date of birth in format YYYY-MM-DD
 * @returns {number} - Age in years
 */
const calculateAge = (dob) => {
  const birthDate = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
};

export default {
  getUserData,
  getUserByUsername,
  updateUserCharacter,
  updateUserDashboard,
  updateUserCurrency,
  sendPartnerRequest,
  acceptPartnerRequest,
  getUserPartnerData,
  updateStreak,
  sendGift,
  sendLine,
  reactToLine,
  unlockLine,
  getPotentialPartners,
  endPartnership,
  reconnectPartner
};