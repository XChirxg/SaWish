
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";
import { app } from "../firebase";

const storage = getStorage(app);

/**
 * Upload an image file to Firebase Storage
 * @param {File} file - The file to upload
 * @param {String} path - The storage path to save the file (e.g., "characters/base/avatar1.png")
 * @returns {Promise<String>} - URL of the uploaded file
 */
export const uploadImage = async (file, path) => {
  try {
    const storageRef = ref(storage, path);
    await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(storageRef);
    return downloadURL;
  } catch (error) {
    console.error("Error uploading image:", error);
    throw error;
  }
};

/**
 * Delete a file from Firebase Storage
 * @param {String} path - Full path to the file in storage
 * @returns {Promise<void>}
 */
export const deleteFile = async (path) => {
  try {
    const fileRef = ref(storage, path);
    await deleteObject(fileRef);
    return true;
  } catch (error) {
    console.error("Error deleting file:", error);
    throw error;
  }
};

/**
 * Get download URL for a file in Firebase Storage
 * @param {String} path - Path to the file in storage
 * @returns {Promise<String>} - Download URL
 */
export const getFileURL = async (path) => {
  try {
    const fileRef = ref(storage, path);
    const url = await getDownloadURL(fileRef);
    return url;
  } catch (error) {
    console.error("Error getting file URL:", error);
    throw error;
  }
};

/**
 * Create a reference to a file in Firebase Storage
 * @param {String} path - Path to the file in storage
 * @returns {Object} - Firebase storage reference
 */
export const getFileRef = (path) => {
  return ref(storage, path);
};

// Note: Since we're trying to minimize Firebase Storage usage, we'll use these functions sparingly
// and instead rely on storing paths/identifiers in Firestore when possible
Claude
