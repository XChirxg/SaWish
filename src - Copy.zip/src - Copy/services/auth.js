

import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  updateProfile,
  signOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  onAuthStateChanged
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { logSignUp, logLogin } from './analytics';
import { ERROR_CODES } from '../utils/constants';

/**
 * Create a new user with email and password
 * @param {string} email - User email
 * @param {string} password - User password
 * @param {string} username - Username
 * @param {string} dob - Date of birth
 * @param {string} gender - Gender
 * @returns {Promise<Object>} - User data
 */
export const registerUser = async (email, password, username, dob, gender) => {
  try {
    const auth = getAuth();
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Update profile with username
    await updateProfile(user, {
      displayName: username
    });

    // Create user document in Firestore
    const userRef = doc(db, 'users', user.uid);
    await setDoc(userRef, {
      profile: {
        username,
        dob,
        gender,
        bio: '',
        zodiacSign: calculateZodiacSign(dob),
        instagramId: '',
        phoneNumber: '',
        createdAt: serverTimestamp()
      },
      character: {
        skinColor: '',
        hairStyle: '',
        hairColor: '',
        accessories: []
      },
      currency: {
        coins: 100, // Starting coins
        hearts: 50  // Starting hearts
      },
      achievements: {
        luck: 1000,  // Starting ELO ratings
        skill: 1000,
        knowledge: 1000
      },
      partner: null,
      dashboard: {
        background: 'default',
        items: []
      },
      unlockedLines: {
        casual: [],
        romantic: []
      },
      unlockedGifts: {
        casual: [],
        romantic: []
      }
    });

    // Log sign up event
    logSignUp('email');
    
    return {
      uid: user.uid,
      email: user.email,
      username
    };
  } catch (error) {
    console.error("Error registering user:", error);
    throw error;
  }
};

/**
 * Sign in a user with email and password
 * @param {string} email - User email
 * @param {string} password - User password
 * @returns {Promise<Object>} - User data
 */
export const loginUser = async (email, password) => {
  try {
    const auth = getAuth();
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Get user data from Firestore
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (!userDoc.exists()) {
      throw new Error(ERROR_CODES.USER_NOT_FOUND);
    }
    
    // Log login event
    logLogin('email');
    
    const userData = userDoc.data();
    return {
      uid: user.uid,
      email: user.email,
      username: userData.profile.username,
      ...userData
    };
  } catch (error) {
    console.error("Error logging in:", error);
    throw error;
  }
};

/**
 * Sign out the current user
 * @returns {Promise<void>}
 */
export const logoutUser = async () => {
  try {
    const auth = getAuth();
    await signOut(auth);
  } catch (error) {
    console.error("Error signing out:", error);
    throw error;
  }
};

/**
 * Send password reset email
 * @param {string} email - User email
 * @returns {Promise<void>}
 */
export const resetPassword = async (email) => {
  try {
    const auth = getAuth();
    await sendPasswordResetEmail(auth, email);
  } catch (error) {
    console.error("Error sending password reset email:", error);
    throw error;
  }
};

/**
 * Send email verification to current user
 * @returns {Promise<void>}
 */
export const verifyEmail = async () => {
  try {
    const auth = getAuth();
    const user = auth.currentUser;
    if (user) {
      await sendEmailVerification(user);
    } else {
      throw new Error(ERROR_CODES.USER_NOT_SIGNED_IN);
    }
  } catch (error) {
    console.error("Error sending email verification:", error);
    throw error;
  }
};

/**
 * Update user profile
 * @param {string} userId - User ID
 * @param {Object} profileData - Profile data to update
 * @returns {Promise<void>}
 */
export const updateUserProfile = async (userId, profileData) => {
  try {
    const userRef = doc(db, 'users', userId);
    await setDoc(userRef, { profile: profileData }, { merge: true });
    
    // Update displayName if username is being updated
    if (profileData.username) {
      const auth = getAuth();
      const user = auth.currentUser;
      if (user) {
        await updateProfile(user, {
          displayName: profileData.username
        });
      }
    }
  } catch (error) {
    console.error("Error updating user profile:", error);
    throw error;
  }
};

/**
 * Set up auth state listener
 * @param {Function} callback - Callback function to handle auth state changes
 * @returns {Function} - Unsubscribe function
 */
export const authStateListener = (callback) => {
  const auth = getAuth();
  return onAuthStateChanged(auth, callback);
};

/**
 * Calculate zodiac sign based on date of birth
 * @param {string} dob - Date of birth in format YYYY-MM-DD
 * @returns {string} - Zodiac sign
 */
const calculateZodiacSign = (dob) => {
  // This is a placeholder. Implement actual zodiac calculation based on date
  return "Unknown";
};

export default {
  registerUser,
  loginUser,
  logoutUser,
  resetPassword,
  verifyEmail,
  updateUserProfile,
  authStateListener
};
Claude
