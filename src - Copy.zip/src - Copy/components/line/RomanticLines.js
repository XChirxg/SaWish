

import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { useUser } from '../../contexts/UserContext';
import { usePartner } from '../../contexts/PartnerContext';
import BackButton from '../common/BackButton';
import Notification from '../common/Notification';
import { getLineContent } from '../../utils/helpers';

const RomanticLines = ({ onSendLine }) => {
  const { user } = useUser();
  const { partner } = usePartner();
  const [unlockedLines, setUnlockedLines] = useState([]);
  const [lockedLines, setLockedLines] = useState([]);
  const [selectedLine, setSelectedLine] = useState(null);
  const [notification, setNotification] = useState({ show: false, message: '', type: '' });

  useEffect(() => {
    const fetchLines = async () => {
      try {
        // Fetch user's unlocked romantic lines
        const userUnlockedLines = user?.unlockedLines?.romantic || [];
        
        // Fetch all available romantic lines
        const linesRef = collection(db, "lineTypes");
        const q = query(linesRef, where("type", "==", "romantic"));
        const querySnapshot = await getDocs(q);
        
        const allLines = [];
        querySnapshot.forEach((doc) => {
          allLines.push({ id: doc.id, ...doc.data() });
        });
        
        // Separate lines into unlocked and locked
        const unlocked = allLines.filter(line => userUnlockedLines.includes(line.id));
        const locked = allLines.filter(line => !userUnlockedLines.includes(line.id));
        
        setUnlockedLines(unlocked);
        setLockedLines(locked);
      } catch (error) {
        console.error("Error fetching lines: ", error);
        setNotification({
          show: true,
          message: "Failed to load lines",
          type: "error"
        });
      }
    };

    if (user) {
      fetchLines();
    }
  }, [user]);

  const handleLineSelect = (line) => {
    setSelectedLine(line);
  };

  const handleUnlockLine = async (line) => {
    if (user.currency.hearts < 5) {
      setNotification({
        show: true,
        message: "Not enough hearts to unlock this line",
        type: "error"
      });
      return;
    }

    try {
      // Logic to unlock the line will be implemented here
      // This includes updating the database and deducting hearts
      
      // For now, just simulate success
      setNotification({
        show: true,
        message: "Line unlocked successfully!",
        type: "success"
      });
      
      // Move line from locked to unlocked in state
      setUnlockedLines([...unlockedLines, line]);
      setLockedLines(lockedLines.filter(l => l.id !== line.id));
    } catch (error) {
      console.error("Error unlocking line: ", error);
      setNotification({
        show: true,
        message: "Failed to unlock line",
        type: "error"
      });
    }
  };

  const handleSendLine = () => {
    if (!selectedLine) {
      setNotification({
        show: true,
        message: "Please select a line first",
        type: "warning"
      });
      return;
    }

    if (!partner) {
      setNotification({
        show: true,
        message: "You need a partner to send lines",
        type: "warning"
      });
      return;
    }

    onSendLine(selectedLine);
    setSelectedLine(null);
  };

  return (
    <div className="romantic-lines-container">
      <h2>Romantic Lines</h2>
      <p className="info-text">Send romantic lines to your partner (Costs 20 hearts to send)</p>
      
      {notification.show && (
        <Notification
          message={notification.message}
          type={notification.type}
          onClose={() => setNotification({ ...notification, show: false })}
        />
      )}
      
      <div className="lines-section">
        <h3>Unlocked Lines</h3>
        <div className="lines-grid">
          {unlockedLines.length > 0 ? (
            unlockedLines.map((line) => (
              <div 
                key={line.id}
                className={`line-card ${selectedLine?.id === line.id ? 'selected' : ''}`}
                onClick={() => handleLineSelect(line)}
              >
                <p>{getLineContent(line.id)}</p>
              </div>
            ))
          ) : (
            <p className="empty-text">No unlocked romantic lines yet</p>
          )}
        </div>
      </div>
      
      <div className="lines-section">
        <h3>Locked Lines</h3>
        <p className="cost-text">Unlock for 5 hearts each</p>
        <div className="lines-grid blurred">
          {lockedLines.length > 0 ? (
            lockedLines.map((line) => (
              <div 
                key={line.id}
                className="line-card locked"
                onClick={() => handleUnlockLine(line)}
              >
                <div className="blurred-content">
                  <p>{getLineContent(line.id)}</p>
                </div>
                <div className="unlock-overlay">
                  <button className="unlock-button">Unlock (5 💕)</button>
                </div>
              </div>
            ))
          ) : (
            <p className="empty-text">No more lines to unlock</p>
          )}
        </div>
      </div>
      
      {selectedLine && (
        <div className="selected-line-container">
          <h3>Selected Line</h3>
          <div className="selected-line-card">
            <p>{getLineContent(selectedLine.id)}</p>
          </div>
          <button 
            className="send-button"
            onClick={handleSendLine}
          >
            Send (20 💕)
          </button>
        </div>
      )}
    </div>
  );
};

export default RomanticLines;
