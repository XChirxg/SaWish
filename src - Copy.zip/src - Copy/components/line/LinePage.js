


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import BackButton from '../common/BackButton';
import { useUser } from '../../contexts/UserContext';
import { usePartner } from '../../contexts/PartnerContext';
import CurrencyDisplay from '../common/CurrencyDisplay';
import useSound from '../../hooks/useSound';
import CasualLines from './CasualLines';
import RomanticLines from './RomanticLines';

const LinePage = () => {
  const navigate = useNavigate();
  const { user, updateUserCurrency } = useUser();
  const { partner, sendLine, conversations } = usePartner();
  const { playSound } = useSound();
  
  const [lineType, setLineType] = useState('casual');
  const [selectedLine, setSelectedLine] = useState(null);
  const [sending, setSending] = useState(false);
  const [lineStatus, setLineStatus] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState(null);
  
  // Sample conversations for the skeleton
  const sampleConversations = conversations || [
    {
      id: 'msg1',
      senderId: 'partner123',
      lineType: 'casual',
      lineText: 'Did you know that honey never spoils? Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still perfectly good to eat!',
      sentAt: new Date(Date.now() - 86400000).toISOString(),
      reaction: null
    },
    {
      id: 'msg2',
      senderId: user?.id,
      lineType: 'romantic',
      lineText: 'Every time I see your name pop up on my phone, my heart skips a beat.',
      sentAt: new Date(Date.now() - 43200000).toISOString(),
      reaction: '❤️'
    },
    {
      id: 'msg3',
      senderId: 'partner123',
      lineType: 'casual',
      lineText: 'If you\'re feeling down today, react with a ☀️ and I\'ll send you something to cheer you up!',
      sentAt: new Date(Date.now() - 21600000).toISOString(),
      reaction: '☀️'
    }
  ];
  
  const emojis = ['❤️', '😊', '😂', '👍', '🎉', '😍', '🥰', '☀️', '🌸', '🔥'];
  
  const handleLineTypeChange = (type) => {
    setLineType(type);
    setSelectedLine(null);
    playSound('select');
  };
  
  const handleLineSelect = (line) => {
    setSelectedLine(line);
    playSound('select');
  };
  
  const handleSendLine = async () => {
    if (!selectedLine || !partner) return;
    
    // Check if user has enough hearts
    const heartCost = lineType === 'casual' ? 10 : 20;
    if (user.currency.hearts < heartCost) {
      setLineStatus('Not enough hearts to send this line!');
      playSound('error');
      return;
    }
    
    setSending(true);
    
    try {
      // Deduct hearts from user
      updateUserCurrency(0, -heartCost);
      
      // Send line to partner
      await sendLine({
        lineId: selectedLine.id,
        lineType: lineType,
        lineText: selectedLine.text
      });
      
      playSound('lineSent');
      setLineStatus('Line sent successfully!');
      
      // Reset selection after a delay
      setTimeout(() => {
        setSelectedLine(null);
        setLineStatus('');
      }, 3000);
    } catch (error) {
      setLineStatus('Failed to send line. Please try again.');
      playSound('error');
    } finally {
      setSending(false);
    }
  };
  
  const handleEmojiSelect = async (messageId, emoji) => {
    // In a real app, this would update the reaction in the database
    playSound('reaction');
    setShowEmojiPicker(false);
    setSelectedMessage(null);
  };
  
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  return (
    <div className="line-page">
      <div className="top-bar">
        <BackButton onClick={() => navigate('/dashboard')} />
        <h2>Line Exchange</h2>
        <CurrencyDisplay coins={user.currency.coins} hearts={user.currency.hearts} />
      </div>
      
      <div className="conversation-container">
        <div className="messages">
          {sampleConversations.map(message => (
            <div 
              key={message.id}
              className={`message ${message.senderId === user?.id ? 'sent' : 'received'}`}
            >
              <div className={`message-bubble ${message.lineType}`}>
                <p>{message.lineText}</p>
                <span className="message-time">{formatTime(message.sentAt)}</span>
                {message.reaction && (
                  <div className="message-reaction">{message.reaction}</div>
                )}
              </div>
              
              {message.senderId !== user?.id && !message.reaction && (
                <button 
                  className="react-button"
                  onClick={() => {
                    setSelectedMessage(message.id);
                    setShowEmojiPicker(true);
                  }}
                >
                  React
                </button>
              )}
            </div>
          ))}
        </div>
        
        {showEmojiPicker && (
          <div className="emoji-picker">
            <div className="emoji-list">
              {emojis.map(emoji => (
                <button 
                  key={emoji}
                  className="emoji-button"
                  onClick={() => handleEmojiSelect(selectedMessage, emoji)}
                >
                  {emoji}
                </button>
              ))}
            </div>
            <button 
              className="close-emoji-picker"
              onClick={() => setShowEmojiPicker(false)}
            >
              Cancel
            </button>
          </div>
        )}
        
        <div className="line-input">
          <div className="line-type-selector">
            <button 
              className={`line-type-button ${lineType === 'casual' ? 'active' : ''}`}
              onClick={() => handleLineTypeChange('casual')}
            >
              Casual Lines
            </button>
            <button 
              className={`line-type-button ${lineType === 'romantic' ? 'active' : ''}`}
              onClick={() => handleLineTypeChange('romantic')}
            >
              Romantic Lines
            </button>
            <button 
              className="emoji-picker-button"
              onClick={() => setShowEmojiPicker(true)}
            >
              Choose Emoji
            </button>
          </div>
          
          {lineType === 'casual' ? (
            <CasualLines onSelectLine={handleLineSelect} />
          ) : (
            <RomanticLines onSelectLine={handleLineSelect} />
          )}
          
          {selectedLine && (
            <div className="line-preview">
              <p>{selectedLine.text}</p>
              <div className="line-actions">
                <p className="heart-cost">
                  Cost: {lineType === 'casual' ? '10' : '20'} hearts
                </p>
                <button 
                  className="send-line-button"
                  onClick={handleSendLine}
                  disabled={sending || user.currency.hearts < (lineType === 'casual' ? 10 : 20)}
                >
                  {sending ? 'Sending...' : 'Send Line'}
                </button>
              </div>
              {lineStatus && <p className="line-status">{lineStatus}</p>}
            </div>
          )}
        </div>
      </div>
      
      {!partner && (
        <div className="no-partner-message">
          <p>You need to add a partner before you can exchange lines!</p>
          <button onClick={() => navigate('/partner/request')} className="add-partner-button">
            Add Partner
          </button>
        </div>
      )}
    </div>
  );
};

export default LinePage;
