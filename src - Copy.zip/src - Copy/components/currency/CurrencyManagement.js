
import React, { useContext, useState } from 'react';
import { UserContext } from '../../contexts/UserContext';
import BackButton from '../common/BackButton';
import CurrencyDisplay from '../common/CurrencyDisplay';
import '../../../src/styles/components/currency/CurrencyManagement.css';

const CurrencyManagement = () => {
  const { user, updateUserCurrency } = useContext(UserContext);
  const [shareButtonDisabled, setShareButtonDisabled] = useState(false);
  const [shareTimer, setShareTimer] = useState(0);

  const purchaseCoins = (amount, price) => {
    // In a real implementation, this would integrate with a payment gateway
    alert(`Purchase ${amount} coins for ₹${price}`);
    // After successful payment:
    // updateUserCurrency({ coins: user.currency.coins + amount });
  };

  const shareAndEarnHearts = () => {
    // Generate share link
    const shareLink = `https://sawish.web.app/invite/${user.id}`;
    
    // Share link implementation
    if (navigator.share) {
      navigator.share({
        title: 'Join me on SaWish!',
        text: 'Build a relationship through games and gifts!',
        url: shareLink,
      });
    } else {
      // Fallback for browsers that don't support navigator.share
      navigator.clipboard.writeText(shareLink);
      alert('Link copied to clipboard! Share it with your friends.');
    }
    
    // Add hearts and disable button temporarily
    updateUserCurrency({ hearts: user.currency.hearts + 10 });
    setShareButtonDisabled(true);
    
    // Set timer for 2 minutes
    setShareTimer(120);
    const interval = setInterval(() => {
      setShareTimer(prevTime => {
        if (prevTime <= 1) {
          clearInterval(interval);
          setShareButtonDisabled(false);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);
  };

  const generateDiscountCode = (heartCost, discountPercentage) => {
    if (user.currency.hearts >= heartCost) {
      // In a real implementation, this would generate a unique code
      const code = Math.random().toString(36).substring(2, 10).toUpperCase();
      
      // Deduct hearts
      updateUserCurrency({ hearts: user.currency.hearts - heartCost });
      
      alert(`Your ${discountPercentage}% discount code is: ${code}`);
    } else {
      alert(`Not enough hearts! You need ${heartCost} hearts.`);
    }
  };

  const formatTimer = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="currency-management-container">
      <BackButton />
      <h1>Currency Management</h1>
      
      <div className="currency-cards">
        <div className="currency-card coins-card">
          <div className="card-header">
            <h2>Coins</h2>
            <div className="coin-icon"></div>
            <span className="amount">{user?.currency?.coins || 0}</span>
          </div>
          <div className="card-body">
            <p>Purchase coins to buy gifts for your partner</p>
            <div className="purchase-options">
              <button 
                className="purchase-btn" 
                onClick={() => purchaseCoins(1000, 100)}
              >
                1,000 coins for ₹100
              </button>
              <button 
                className="purchase-btn" 
                onClick={() => purchaseCoins(10000, 1000)}
              >
                10,000 coins for ₹1,000
              </button>
              <button 
                className="purchase-btn" 
                onClick={() => purchaseCoins(100000, 10000)}
              >
                100,000 coins for ₹10,000
              </button>
            </div>
          </div>
        </div>
        
        <div className="currency-card hearts-card">
          <div className="card-header">
            <h2>Hearts</h2>
            <div className="heart-icon"></div>
            <span className="amount">{user?.currency?.hearts || 0}</span>
          </div>
          <div className="card-body">
            <p>Hearts are earned when you receive gifts from your partner</p>
            <button 
              className="share-earn-btn"
              onClick={shareAndEarnHearts}
              disabled={shareButtonDisabled}
            >
              {shareButtonDisabled 
                ? `Share again in ${formatTimer(shareTimer)}` 
                : 'Share and earn 10 hearts'}
            </button>
            
            <div className="discount-options">
              <h3>Generate Discount Codes</h3>
              <button 
                className="discount-btn"
                onClick={() => generateDiscountCode(5000, 5)}
              >
                5% discount on items under ₹1,000 (5,000 hearts)
              </button>
              <button 
                className="discount-btn"
                onClick={() => generateDiscountCode(7000, 10)}
              >
                10% discount on items between ₹1,000-₹5,000 (7,000 hearts)
              </button>
              <button 
                className="discount-btn"
                onClick={() => generateDiscountCode(10000, 5)}
              >
                5% discount on items over ₹10,000 (10,000 hearts)
              </button>
            </div>
          </div>
        </div>
        
        <div className="currency-card streak-card">
          <div className="card-header">
            <h2>Streak</h2>
            <div className="star-icon"></div>
            <span className="amount">{user?.partner?.streakCount || 0}</span>
          </div>
          <div className="card-body">
            <p>Maintain your streak by exchanging gifts daily</p>
            <div className="streak-milestones">
              <h3>Streak Milestones</h3>
              <ul>
                <li className={user?.partner?.streakCount >= 10 ? 'achieved' : ''}>
                  10 days: Partner's personality insights
                </li>
                <li className={user?.partner?.streakCount >= 20 ? 'achieved' : ''}>
                  20 days: Relationship description
                </li>
                <li className={user?.partner?.streakCount >= 30 ? 'achieved' : ''}>
                  30 days: Partner's contact information
                </li>
                <li className={user?.partner?.streakCount >= 365 ? 'achieved' : ''}>
                  365 days: 25% discount on store items
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="currency-card achievements-card">
          <div className="card-header">
            <h2>Achievements</h2>
            <div className="trophy-icon"></div>
          </div>
          <div className="card-body">
            <div className="achievement-types">
              <div className="achievement-type">
                <h3>Luck</h3>
                <span className="rating">{user?.achievements?.luck || 0}</span>
              </div>
              <div className="achievement-type">
                <h3>Skill</h3>
                <span className="rating">{user?.achievements?.skill || 0}</span>
              </div>
              <div className="achievement-type">
                <h3>Knowledge</h3>
                <span className="rating">{user?.achievements?.knowledge || 0}</span>
              </div>
            </div>
            <p>Improve your ratings by playing games</p>
          </div>
        </div>
      </div>
      
      <div className="about-section">
        <h2>About SaWish</h2>
        <p className="about-text">
          SaWish - See a Wish coming true. Build meaningful relationships through interactive gameplay, thoughtful gifts, and daily engagement. 
        </p>
        <p className="about-text">
          In today's digital age, maintaining a connection with your loved one can be challenging. SaWish helps bridge the gap by creating opportunities for daily interaction and understanding through playful activities.
        </p>
        <p className="about-text">
          Learn about your partner's personality, interests, and communication style as you progress through relationship milestones together.
        </p>
        <div className="developer-info">
          <p>Developed by <a href="https://chinurag.com" target="_blank" rel="noopener noreferrer">Chinurag</a></p>
        </div>
      </div>
    </div>
  );
};

export default CurrencyManagement;
