
import React, { useContext, useState } from 'react';
import { UserContext } from '../../contexts/UserContext';
import { PartnerContext } from '../../contexts/PartnerContext';
import BackButton from '../common/BackButton';
import '../../../src/styles/components/partner/PartnerInfo.css';

const PartnerInfo = () => {
  const { user } = useContext(UserContext);
  const { partner, endPartnership, reconnectPartner } = useContext(PartnerContext);
  const [showEndConfirmation, setShowEndConfirmation] = useState(false);
  const [countdown, setCountdown] = useState(200);
  const [endingPartnership, setEndingPartnership] = useState(false);
  const [reconnectTimer, setReconnectTimer] = useState(null);

  const handleEndPartnership = () => {
    setShowEndConfirmation(true);
    // Start countdown
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const confirmEndPartnership = () => {
    if (countdown === 0) {
      setEndingPartnership(true);
      setShowEndConfirmation(false);
      // Set 7 day reconnect timer
      const reconnectDeadline = Date.now() + 7 * 24 * 60 * 60 * 1000;
      setReconnectTimer(reconnectDeadline);
      // Call context function to end partnership
      endPartnership();
    }
  };

  const handleReconnect = () => {
    reconnectPartner();
    setEndingPartnership(false);
    setReconnectTimer(null);
  };

  return (
    <div className="partner-info-container">
      <BackButton />
      <h1>Partner Profile</h1>
      
      {partner ? (
        <div className="partner-profile">
          <div className="partner-avatar">
            {/* Partner character avatar will go here */}
            <div className="character-circle"></div>
          </div>
          
          <div className="partner-details">
            <h2>{partner.username}</h2>
            <p className="bio">{partner.bio}</p>
            <p className="zodiac-sign">Zodiac: {partner.zodiacSign}</p>
            <p className="gifted-hearts">Gifted Hearts: {partner.heartsReceived}</p>
            
            <div className="achievements">
              <h3>Achievements</h3>
              <div className="achievement-categories">
                <div className="achievement">
                  <p className="category">Luck</p>
                  <p className="rating">{partner.achievements?.luck || 0}</p>
                </div>
                <div className="achievement">
                  <p className="category">Skill</p>
                  <p className="rating">{partner.achievements?.skill || 0}</p>
                </div>
                <div className="achievement">
                  <p className="category">Knowledge</p>
                  <p className="rating">{partner.achievements?.knowledge || 0}</p>
                </div>
              </div>
            </div>
            
            <div className="streak-info">
              <h3>Streak Level: {partner.streakLevel}</h3>
              <p className="streak-count">Current Streak: {partner.streakCount} days</p>
              
              {partner.streakLevel >= 10 && (
                <div className="streak-unlock personality">
                  <h4>Personality Insights</h4>
                  <p>{partner.personalityDescription}</p>
                </div>
              )}
              
              {partner.streakLevel >= 20 && (
                <div className="streak-unlock relationship">
                  <h4>Relationship Description</h4>
                  <p>{partner.relationshipDescription}</p>
                </div>
              )}
              
              {partner.streakLevel >= 30 && (
                <div className="streak-unlock contact">
                  <h4>Contact Information</h4>
                  {partner.instagramId && <p>Instagram: {partner.instagramId}</p>}
                  {partner.phoneNumber && <p>Phone: {partner.phoneNumber}</p>}
                </div>
              )}
              
              {partner.streakLevel >= 365 && (
                <div className="streak-unlock anniversary">
                  <h4>Anniversary Discount</h4>
                  <p>25% discount on items under ₹500 from the store!</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="partnership-actions">
            {!endingPartnership ? (
              <button 
                className="end-partnership-btn" 
                onClick={handleEndPartnership}
              >
                End Partnership
              </button>
            ) : (
              <button 
                className="reconnect-btn" 
                onClick={handleReconnect}
              >
                Reconnect Again
                {reconnectTimer && (
                  <span className="timer">
                    {Math.ceil((reconnectTimer - Date.now()) / (1000 * 60 * 60 * 24))} days left
                  </span>
                )}
              </button>
            )}
            
            {showEndConfirmation && (
              <div className="end-confirmation">
                <p className="warning">Warning: This will delete all your progress!</p>
                <p className="countdown">Time remaining: {countdown} seconds</p>
                <button 
                  className="proceed-btn" 
                  disabled={countdown > 0}
                  onClick={confirmEndPartnership}
                >
                  Proceed
                </button>
                <button 
                  className="cancel-btn"
                  onClick={() => setShowEndConfirmation(false)}
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="no-partner">
          <p>You don't have a partner yet</p>
          <button className="find-partner-btn">Find a Partner</button>
        </div>
      )}
    </div>
  );
};

export default PartnerInfo;
