
import React, { useState, useContext } from 'react';
import { UserContext } from '../../contexts/UserContext';
import BackButton from '../common/BackButton';
import '../../../src/styles/components/partner/PartnerRequest.css';

const PartnerRequest = () => {
  const { user } = useContext(UserContext);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [incomingRequests, setIncomingRequests] = useState([]);
  const [inviteLink, setInviteLink] = useState('');
  const [linkCopied, setLinkCopied] = useState(false);

  // Placeholder for API calls
  const handleSearch = (e) => {
    e.preventDefault();
    // In a real implementation, this would search the database
    console.log('Searching for:', searchQuery);
    
    // Placeholder search results
    setSearchResults([
      { id: 1, username: 'user1', age: 25, gender: 'Female' },
      { id: 2, username: 'user2', age: 28, gender: 'Male' },
      { id: 3, username: 'user3', age: 24, gender: 'Female' }
    ]);
  };

  const generateInviteLink = () => {
    // In a real implementation, this would generate a unique link
    const link = `https://sawish.web.app/invite/${user.id}`;
    setInviteLink(link);
    return link;
  };

  const copyInviteLink = () => {
    const link = inviteLink || generateInviteLink();
    navigator.clipboard.writeText(link);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 3000);
  };

  const sendPartnerRequest = (userId) => {
    // In a real implementation, this would send a request to the database
    console.log('Sending partner request to:', userId);
    alert('Partner request sent!');
  };

  const acceptRequest = (requestId) => {
    // In a real implementation, this would update the database
    console.log('Accepting request:', requestId);
    alert('Partner request accepted!');
  };

  const rejectRequest = (requestId) => {
    // In a real implementation, this would update the database
    console.log('Rejecting request:', requestId);
    
    // Remove from local state
    setIncomingRequests(incomingRequests.filter(req => req.id !== requestId));
  };

  return (
    <div className="partner-request-container">
      <BackButton />
      <h1>Find a Partner</h1>
      
      <div className="invite-section">
        <h2>Invite a Friend</h2>
        <p>Share this link with someone you want to play with:</p>
        <div className="invite-link-container">
          <input 
            type="text" 
            value={inviteLink || 'Click Generate to create a link'} 
            readOnly 
            className="invite-link"
          />
          <button 
            className="generate-link-btn" 
            onClick={generateInviteLink}
          >
            Generate
          </button>
          <button 
            className="copy-link-btn" 
            onClick={copyInviteLink}
            disabled={!inviteLink}
          >
            {linkCopied ? 'Copied!' : 'Copy'}
          </button>
        </div>
      </div>
      
      <div className="search-section">
        <h2>Search Users</h2>
        <form onSubmit={handleSearch}>
          <input 
            type="text" 
            placeholder="Search by username" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
          <button type="submit" className="search-btn">Search</button>
        </form>
        
        {searchResults.length > 0 && (
          <div className="search-results">
            <h3>Results</h3>
            <ul className="results-list">
              {searchResults.map(user => (
                <li key={user.id} className="result-item">
                  <div className="user-info">
                    <p className="username">{user.username}</p>
                    <p className="user-details">{user.age} • {user.gender}</p>
                  </div>
                  <button 
                    className="send-request-btn"
                    onClick={() => sendPartnerRequest(user.id)}
                  >
                    Send Request
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
      
      <div className="incoming-requests-section">
        <h2>Incoming Requests</h2>
        {incomingRequests.length === 0 ? (
          <p className="no-requests">No pending requests</p>
        ) : (
          <ul className="requests-list">
            {incomingRequests.map(request => (
              <li key={request.id} className="request-item">
                <div className="requester-info">
                  <p className="username">{request.senderUsername}</p>
                  <p className="request-time">
                    {new Date(request.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="request-actions">
                  <button 
                    className="accept-btn"
                    onClick={() => acceptRequest(request.id)}
                  >
                    Accept
                  </button>
                  <button 
                    className="reject-btn"
                    onClick={() => rejectRequest(request.id)}
                  >
                    Reject
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
      
      <div className="suggestions-section">
        <h2>Suggested Partners</h2>
        <p className="suggestions-info">
          Finding users based on similar age and interests
        </p>
        {/* This would be populated with algorithmically suggested partners */}
        <p className="no-suggestions">No suggestions available right now</p>
      </div>
    </div>
  );
};

export default PartnerRequest;
