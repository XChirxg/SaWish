// Items.js - Items Display Component
import React from 'react';

const Items = ({ items = [] }) => {
  // Map item IDs to images and positions
  const itemInfo = {
    flower1: {
      image: '/assets/images/gifts/flower1.png',
      position: 'bottom-left',
      size: 'small'
    },
    flower10: {
      image: '/assets/images/gifts/flower_bouquet.png',
      position: 'bottom-left',
      size: 'medium'
    },
    flower50: {
      image: '/assets/images/gifts/flower_pot.png',
      position: 'bottom-left',
      size: 'large'
    },
    book1: {
      image: '/assets/images/gifts/book1.png',
      position: 'bottom-right',
      size: 'small'
    },
    book10: {
      image: '/assets/images/gifts/book_stack.png',
      position: 'bottom-right',
      size: 'medium'
    },
    book50: {
      image: '/assets/images/gifts/bookshelf.png',
      position: 'bottom-right',
      size: 'large'
    },
    car1: {
      image: '/assets/images/gifts/car1.png',
      position: 'center-bottom',
      size: 'large'
    },
    // Add more items as needed
  };
  
  return (
    <div className="items-container">
      {items.map((itemId, index) => {
        const item = itemInfo[itemId];
        if (!item) return null;
        
        return (
          <div
            key={`${itemId}-${index}`}
            className={`item ${item.position} ${item.size}`}
            style={{ backgroundImage: `url(${item.image})` }}
          ></div>
        );
      })}
    </div>
  );
};

export default Items;