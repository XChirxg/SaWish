// Characters.js - Characters Display Component
import React from 'react';

const Characters = ({ 
  userCharacter, 
  partnerCharacter, 
  hasPartner, 
  onUserClick, 
  onPartnerClick, 
  onAddPartner 
}) => {
  // Function to render a single character
  const renderCharacter = (character, onClick, label) => {
    if (!character) return null;
    
    const { skinColor, hairStyle, hairColor, outfit } = character;
    
    return (
      <div className="character" onClick={onClick}>
        <div 
          className="character-avatar"
          style={{
            backgroundColor: skinColor,
            // In actual implementation, this would use proper layered images
            backgroundImage: `url('/assets/images/characters/base/${hairStyle}_${hairColor}.png')`
          }}
        >
          {/* Outfit and accessories would be additional layers */}
          {outfit && <div className="character-outfit" style={{ backgroundImage: `url('/assets/images/characters/clothing/${outfit}.png')` }}></div>}
        </div>
        <div className="character-label">{label}</div>
      </div>
    );
  };
  
  return (
    <div className="characters-container">
      {/* User Character */}
      {renderCharacter(userCharacter, onUserClick, 'You')}
      
      {/* Partner Character or Add Partner Button */}
      {hasPartner ? (
        renderCharacter(partnerCharacter, onPartnerClick, 'Partner')
      ) : (
        <div className="add-partner" onClick={onAddPartner}>
          <div className="add-icon">+</div>
          <div className="add-label">Add Friend</div>
        </div>
      )}
    </div>
  );
};

export default Characters;