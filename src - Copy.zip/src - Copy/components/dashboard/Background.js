// Background.js - Background Display Component
import React from 'react';

const Background = ({ background }) => {
  // Map background ID to actual image path
  const backgroundMap = {
    park: '/assets/images/backgrounds/park.jpg',
    beach: '/assets/images/backgrounds/beach.jpg',
    mountain: '/assets/images/backgrounds/mountain.jpg',
    city: '/assets/images/backgrounds/city.jpg',
    cafe: '/assets/images/backgrounds/cafe.jpg',
    shimla: '/assets/images/backgrounds/shimla.jpg',
    // Add more backgrounds as needed
  };
  
  const backgroundStyle = {
    backgroundImage: `url(${backgroundMap[background] || backgroundMap.park})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
  };
  
  return (
    <div className="background-container" style={backgroundStyle}></div>
  );
};

export default Background;