// TopBar.js - Dashboard Top Bar Component
import React from 'react';

const TopBar = ({ username, coins, hearts, streak, onSettingsClick, onCurrencyClick, onDesignClick }) => {
  return (
    <div className="top-bar">
      <div className="app-branding">
        <h1>SaWish</h1>
      </div>
      
      <div className="currency-display">
        <div className="currency-item" onClick={onCurrencyClick}>
          <span className="currency-icon heart-icon">❤️</span>
          <span className="currency-amount">{hearts}</span>
        </div>
        
        <div className="currency-item" onClick={onCurrencyClick}>
          <span className="currency-icon coin-icon">🪙</span>
          <span className="currency-amount">{coins}</span>
        </div>
      </div>
      
      <div className="stats-controls">
        <div className="streak-display">
          <span className="streak-icon">⭐</span>
          <span className="streak-label">Streak</span>
          <span className="streak-count">{streak}</span>
        </div>
        
        <button className="design-button" onClick={onDesignClick}>
          <span className="design-icon">🎨</span>
        </button>
        
        <button className="settings-button" onClick={onSettingsClick}>
          <span className="settings-icon">⚙️</span>
        </button>
      </div>
    </div>
  );
};

export default TopBar;