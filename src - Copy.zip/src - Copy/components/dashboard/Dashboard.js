

import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../../contexts/UserContext';
import { PartnerContext } from '../../contexts/PartnerContext';
import TopBar from './TopBar';
import Background from './Background';
import Items from './Items';
import Characters from './Characters';
import useSound from '../../hooks/useSound';

const Dashboard = () => {
  const navigate = useNavigate();
  const { user } = useContext(UserContext);
  const { partner } = useContext(PartnerContext);
  const { playSound } = useSound();
  
  // Navigation handlers
  const handleGameClick = () => {
    playSound('buttonClick');
    navigate('/games');
  };
  
  const handleGiftClick = () => {
    playSound('buttonClick');
    navigate('/gifts');
  };
  
  const handleLineClick = () => {
    playSound('buttonClick');
    navigate('/lines');
  };

  return (
    <div className="dashboard-container">
      {/* Top bar with app icon, currency display, streak, settings */}
      <TopBar />
      
      {/* Main content area */}
      <div className="dashboard-content">
        {/* Background area */}
        <Background />
        
        {/* Items area */}
        <Items />
        
        {/* Characters area */}
        <Characters />
      </div>
      
      {/* Bottom navigation */}
      <div className="bottom-nav">
        <button 
          className="nav-button game-button"
          onClick={handleGameClick}
        >
          <span className="icon">🎮</span>
          <span className="label">Games</span>
        </button>
        
        <button 
          className="nav-button gift-button"
          onClick={handleGiftClick}
        >
          <span className="icon">🎁</span>
          <span className="label">Gifts</span>
        </button>
        
        <button 
          className="nav-button line-button"
          onClick={handleLineClick}
        >
          <span className="icon">💬</span>
          <span className="label">Lines</span>
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
