// BackButton.js - Common Back Button Component
import React from 'react';

const BackButton = ({ onClick }) => {
  return (
    <button className="back-button" onClick={onClick}>
      <span className="back-icon">←</span>
    </button>
  );
};

export default BackButton;