import React, { useState, useEffect, useContext } from 'react';
import { UserContext } from '../../contexts/UserContext';
import useSound from '../../hooks/useSound';

// Notification component that displays app notifications
const Notification = () => {
  const [notifications, setNotifications] = useState([]);
  const [visible, setVisible] = useState(false);
  const { user } = useContext(UserContext);
  const { playSound } = useSound();

  useEffect(() => {
    // Function to fetch notifications from the database or local storage
    const fetchNotifications = async () => {
      // For demo purposes, we're creating mock notifications
      // In a real app, you would fetch these from your database
      const mockNotifications = [
        {
          id: '1',
          type: 'gift',
          message: 'You received a new gift!',
          read: false,
          timestamp: new Date().getTime() - 3600000 // 1 hour ago
        },
        {
          id: '2',
          type: 'streak',
          message: 'Keep going! Your streak is now 5 days',
          read: true,
          timestamp: new Date().getTime() - 86400000 // 1 day ago
        }
      ];
      
      setNotifications(mockNotifications);
      
      // Check if there are unread notifications
      const hasUnread = mockNotifications.some(notif => !notif.read);
      if (hasUnread) {
        setVisible(true);
        playSound('notification');
      }
    };
    
    // Only fetch notifications if user is logged in
    if (user?.uid) {
      fetchNotifications();
    }
    
    // Set up interval to check for new notifications
    const intervalId = setInterval(() => {
      if (user?.uid) {
        fetchNotifications();
      }
    }, 60000); // Check every minute
    
    return () => clearInterval(intervalId);
  }, [user, playSound]);
  
  // Handle closing the notification panel
  const handleClose = () => {
    setVisible(false);
  };
  
  // Mark a notification as read
  const markAsRead = (id) => {
    setNotifications(prevNotifications => 
      prevNotifications.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
    
    // If all notifications are read, hide the notification panel
    if (notifications.every(notif => notif.read)) {
      setVisible(false);
    }
  };
  
  // Format timestamp to relative time (e.g., "2 hours ago")
  const formatRelativeTime = (timestamp) => {
    const now = new Date().getTime();
    const diff = now - timestamp;
    
    // Convert to appropriate time unit
    if (diff < 60000) { // Less than a minute
      return 'Just now';
    } else if (diff < 3600000) { // Less than an hour
      const minutes = Math.floor(diff / 60000);
      return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
    } else if (diff < 86400000) { // Less than a day
      const hours = Math.floor(diff / 3600000);
      return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    } else if (diff < 2592000000) { // Less than a month
      const days = Math.floor(diff / 86400000);
      return `${days} day${days !== 1 ? 's' : ''} ago`;
    } else {
      // Format as date
      const date = new Date(timestamp);
      return date.toLocaleDateString();
    }
  };
  
  // If no notifications or not visible, render nothing or just the notification icon
  if (!visible || notifications.length === 0) {
    return (
      <div className="notification-bell" onClick={() => setVisible(true)}>
        {notifications.some(notif => !notif.read) && <div className="notification-badge"></div>}
      </div>
    );
  }
  
  return (
    <div className="notification-panel">
      <div className="notification-header">
        <h3>Notifications</h3>
        <button className="close-button" onClick={handleClose}>×</button>
      </div>
      
      <div className="notification-list">
        {notifications.length === 0 ? (
          <div className="no-notifications">No notifications</div>
        ) : (
          notifications.map(notification => (
            <div 
              key={notification.id} 
              className={`notification-item ${notification.read ? 'read' : 'unread'}`}
              onClick={() => markAsRead(notification.id)}
            >
              <div className={`notification-icon ${notification.type}-icon`}></div>
              <div className="notification-content">
                <div className="notification-message">{notification.message}</div>
                <div className="notification-time">{formatRelativeTime(notification.timestamp)}</div>
              </div>
              {!notification.read && <div className="unread-marker"></div>}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Notification;