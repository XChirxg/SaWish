

import React, { useContext } from 'react';
import { UserContext } from '../../contexts/UserContext';
import useSound from '../../hooks/useSound';

// Currency Display component - shows coins and hearts
const CurrencyDisplay = ({ onClick, showLabels = true, size = 'medium' }) => {
  const { user } = useContext(UserContext);
  const { playSound } = useSound();

  // Format currency numbers for display (e.g., 1000 -> 1K)
  const formatCurrency = (value) => {
    if (!value && value !== 0) return '0';
    
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    } else if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}K`;
    }
    return value.toString();
  };

  // Handle click on currency
  const handleCurrencyClick = () => {
    playSound('buttonClick');
    if (onClick) {
      onClick();
    }
  };

  // Size classes for different sizes
  const sizeClass = {
    small: 'currency-sm',
    medium: 'currency-md',
    large: 'currency-lg'
  };

  return (
    <div className={`currency-display ${sizeClass[size]}`} onClick={handleCurrencyClick}>
      <div className="currency-item coins">
        <div className="currency-icon coin-icon"></div>
        <div className="currency-value">{formatCurrency(user?.currency?.coins || 0)}</div>
        {showLabels && <div className="currency-label">Coins</div>}
      </div>
      
      <div className="currency-item hearts">
        <div className="currency-icon heart-icon"></div>
        <div className="currency-value">{formatCurrency(user?.currency?.hearts || 0)}</div>
        {showLabels && <div className="currency-label">Hearts</div>}
      </div>
    </div>
  );
};

export default CurrencyDisplay;
