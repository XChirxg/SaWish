import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import BackButton from '../../common/BackButton';
import CurrencyDisplay from '../../common/CurrencyDisplay';
import { useUser } from '../../../contexts/UserContext';
import useSound from '../../../hooks/useSound';

const Quiz = () => {
  const navigate = useNavigate();
  const { user, updateUserCurrency } = useUser();
  const { playSound } = useSound();
  
  const [quizType, setQuizType] = useState('');
  const [quizStarted, setQuizStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [quizComplete, setQuizComplete] = useState(false);
  
  // Sample quiz questions for the skeleton
  // In a real implementation, these would be fetched from a database
  const quizTypes = [
    { id: 'history', name: 'World History', icon: '🏛️' },
    { id: 'geography', name: 'World Geography', icon: '🌍' },
    { id: 'science', name: 'Science', icon: '🔬' },
    { id: 'physics', name: 'Physics', icon: '⚛️' },
    { id: 'commerce', name: 'Commerce', icon: '💼' },
    { id: 'math', name: 'Mathematics', icon: '🧮' }
  ];
  
  const sampleQuestions = [
    {
      question: "What is the capital of France?",
      options: ["London", "Berlin", "Paris", "Madrid"],
      answer: 2
    },
    {
      question: "Who wrote 'Romeo and Juliet'?",
      options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
      answer: 1
    },
    {
      question: "What is the chemical symbol for gold?",
      options: ["Gd", "Au", "Ag", "Fe"],
      answer: 1
    },
    {
      question: "Which planet is known as the Red Planet?",
      options: ["Venus", "Jupiter", "Mars", "Saturn"],
      answer: 2
    },
    {
      question: "What is 9 × 8?",
      options: ["72", "63", "81", "54"],
      answer: 0
    },
    {
      question: "Who invented the telephone?",
      options: ["Thomas Edison", "Alexander Graham Bell", "Nikola Tesla", "Guglielmo Marconi"],
      answer: 1
    },
    {
      question: "What is the largest ocean on Earth?",
      options: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
      answer: 3
    },
    {
      question: "Which element has the chemical symbol 'O'?",
      options: ["Gold", "Oxygen", "Osmium", "Oganesson"],
      answer: 1
    },
    {
      question: "What is the square root of 144?",
      options: ["12", "14", "10", "16"],
      answer: 0
    },
    {
      question: "Which of these is not a primary color?",
      options: ["Red", "Blue", "Green", "Yellow"],
      answer: 3
    }
  ];
  
  const startQuiz = (type) => {
    setQuizType(type);
    setQuizStarted(true);
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
    setQuizComplete(false);
    playSound('gameStart');
  };
  
  const handleAnswerSelection = (answerIndex) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(answerIndex);
    
    if (answerIndex === sampleQuestions[currentQuestion].answer) {
      setScore(prev => prev + 15); // Correct answer earns 15 coins
      playSound('correctAnswer');
    } else {
      setScore(prev => prev - 3); // Wrong answer costs 3 coins
      playSound('wrongAnswer');
    }
    
    setTimeout(() => {
      if (currentQuestion < sampleQuestions.length - 1) {
        setCurrentQuestion(prev => prev + 1);
        setSelectedAnswer(null);
      } else {
        finishQuiz();
      }
    }, 1500);
  };
  
  const finishQuiz = () => {
    let finalScore = score;
    
    // Calculate bonus based on score percentage
    const percentage = (score / 150) * 100; // 10 questions * 15 coins = 150 max
    
    if (percentage >= 90) {
      finalScore += 100;
    } else if (percentage >= 70) {
      finalScore += 50;
    } else if (percentage >= 50) {
      finalScore += 30;
    }
    
    // Update user currency
    if (finalScore > 0) {
      updateUserCurrency(finalScore);
    }
    
    setScore(finalScore);
    setQuizComplete(true);
    setShowResult(true);
    playSound('gameComplete');
  };
  
  return (
    <div className="quiz-game">
      <div className="top-bar">
        <BackButton onClick={() => navigate('/games')} />
        <h2>Knowledge Quiz</h2>
        <CurrencyDisplay coins={user.currency.coins} hearts={user.currency.hearts} />
      </div>
      
      {!quizStarted ? (
        <div className="quiz-selection">
          <h3>Select a Quiz Topic</h3>
          <p>Test your knowledge and earn coins!</p>
          
          <div className="quiz-types">
            {quizTypes.map(type => (
              <div 
                key={type.id}
                className="quiz-type-card"
                onClick={() => startQuiz(type.id)}
              >
                <div className="quiz-icon">{type.icon}</div>
                <div className="quiz-name">{type.name}</div>
              </div>
            ))}
          </div>
          
          <div className="quiz-rules">
            <h4>Quiz Rules:</h4>
            <ul>
              <li>Each correct answer earns 15 coins</li>
              <li>Each wrong answer costs 3 coins</li>
              <li>Score 50% or higher to increase your knowledge rating</li>
              <li>Bonus coins: 30 for 50%+, 50 for 70%+, 100 for 90%+</li>
            </ul>
          </div>
        </div>
      ) : (
        <div className="quiz-container">
          {!quizComplete ? (
            <div className="question-container">
              <div className="question-progress">
                Question {currentQuestion + 1} of {sampleQuestions.length}
              </div>
              
              <div className="question">
                <h3>{sampleQuestions[currentQuestion].question}</h3>
              </div>
              
              <div className="options">
                {sampleQuestions[currentQuestion].options.map((option, index) => (
                  <button 
                    key={index}
                    className={`option-button ${
                      selectedAnswer === index 
                        ? index === sampleQuestions[currentQuestion].answer 
                          ? 'correct' 
                          : 'incorrect' 
                        : ''
                    } ${selectedAnswer !== null ? 'disabled' : ''}`}
                    onClick={() => handleAnswerSelection(index)}
                    disabled={selectedAnswer !== null}
                  >
                    {option}
                  </button>
                ))}
              </div>
              
              <div className="current-score">
                Current Score: {score} coins
              </div>
            </div>
          ) : (
            <div className="result-container">
              <h3>Quiz Complete!</h3>
              <div className="final-score">
                <p>Your Final Score: {score} coins</p>
              </div>
              
              <div className="performance">
                <p>Performance Analysis:</p>
                <div className="performance-meter">
                  <div 
                    className="performance-fill" 
                    style={{ width: `${(score / 150) * 100}%` }}
                  ></div>
                </div>
                <p>{(score / 150) * 100}% Correct</p>
              </div>
              
              <div className="quiz-actions">
                <button 
                  className="play-again-button"
                  onClick={() => setQuizStarted(false)}
                >
                  Choose Another Quiz
                </button>
                <button 
                  className="back-to-games-button"
                  onClick={() => navigate('/games')}
                >
                  Back to Games
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Quiz;