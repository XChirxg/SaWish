import React, { useState, useContext } from 'react';
import { UserContext } from '../../../contexts/UserContext';
import BackButton from '../../common/BackButton';
import '../../../../src/styles/components/games/luck/DiceRoll.css';

const DiceRoll = () => {
  const { user, updateUserCurrency, updateUserAchievement } = useContext(UserContext);
  const [selectedNumber, setSelectedNumber] = useState(null);
  const [betAmount, setBetAmount] = useState(50);
  const [rollResults, setRollResults] = useState([]);
  const [isRolling, setIsRolling] = useState(false);
  const [gameResult, setGameResult] = useState(null); // 'win' or 'lose'
  const [message, setMessage] = useState('');
  
  // Maximum and minimum bet amounts
  const MIN_BET = 50;
  const MAX_BET = 1000;
  
  // Numbers that can be chosen
  const DICE_NUMBERS = [1, 2, 3, 4, 5, 6];
  
  const handleNumberSelect = (number) => {
    setSelectedNumber(number);
    setMessage('');
  };
  
  const handleBetChange = (e) => {
    const value = parseInt(e.target.value);
    if (value >= MIN_BET && value <= MAX_BET) {
      setBetAmount(value);
    }
  };
  
  const rollDice = () => {
    // Check if user has selected a number
    if (selectedNumber === null) {
      setMessage('Please select a number first!');
      return;
    }
    
    // Check if user has enough coins
    if (user.currency.coins < betAmount) {
      setMessage("You don't have enough coins!");
      return;
    }
    
    // Deduct coins first
    updateUserCurrency({ coins: user.currency.coins - betAmount });
    
    // Start rolling animation
    setIsRolling(true);
    setRollResults([]);
    setGameResult(null);
    
    // Roll dice three times
    const rolls = [];
    
    // Simulate the dice rolling with delays
    setTimeout(() => {
      const roll1 = Math.floor(Math.random() * 6) + 1;
      rolls.push(roll1);
      setRollResults([roll1]);
      
      setTimeout(() => {
        const roll2 = Math.floor(Math.random() * 6) + 1;
        rolls.push(roll2);
        setRollResults([roll1, roll2]);
        
        setTimeout(() => {
          const roll3 = Math.floor(Math.random() * 6) + 1;
          rolls.push(roll3);
          setRollResults([roll1, roll2, roll3]);
          
          // Calculate result
          const total = roll1 + roll2 + roll3;
          const won = total === selectedNumber;
          
          setIsRolling(false);
          
          if (won) {
            const winAmount = betAmount * 2;
            updateUserCurrency({ coins: user.currency.coins + winAmount });
            setGameResult('win');
            setMessage(`You won ${winAmount} coins!`);
            
            // Update luck achievement
            updateUserAchievement({ luck: user.achievements.luck + 5 });
          } else {
            setGameResult('lose');
            setMessage(`Better luck next time!`);
            
            // Update luck achievement (smaller decrease for losing)
            if (user.achievements.luck > 0) {
              updateUserAchievement({ luck: Math.max(0, user.achievements.luck - 2) });
            }
          }
        }, 1000); // Third roll delay
      }, 1000); // Second roll delay
    }, 1000); // First roll delay
  };
  
  // Calculate possible winning amount
  const possibleWin = betAmount * 2;
  
  return (
    <div className="dice-roll-container">
      <BackButton />
      <h1>Dice Roll</h1>
      
      <div className="game-info">
        <p>Choose a number between 3 and 18, then roll the dice three times.</p>
        <p>If the sum of all three dice equals your chosen number, you win double your bet!</p>
      </div>
      
      <div className="bet-controls">
        <div className="bet-amount">
          <label htmlFor="bet-input">Bet Amount:</label>
          <input 
            id="bet-input"
            type="number" 
            min={MIN_BET} 
            max={MAX_BET} 
            value={betAmount} 
            onChange={handleBetChange}
            disabled={isRolling}
          />
          <span className="coin-icon"></span>
        </div>
        
        <div className="possible-win">
          <p>Possible Win: {possibleWin} <span className="coin-icon"></span></p>
        </div>
      </div>
      
      <div className="number-selection">
        <h3>Choose a Number</h3>
        <div className="numbers-grid">
          {Array.from({ length: 16 }, (_, i) => i + 3).map(num => (
            <button 
              key={num} 
              className={`number-btn ${selectedNumber === num ? 'selected' : ''}`}
              onClick={() => handleNumberSelect(num)}
              disabled={isRolling}
            >
              {num}
            </button>
          ))}
        </div>
      </div>
      
      <div className="dice-container">
        {rollResults.map((result, index) => (
          <div key={index} className={`dice dice-${result} ${isRolling ? 'rolling' : ''}`}></div>
        ))}
        
        {rollResults.length === 3 && (
          <div className="dice-total">
            Total: {rollResults.reduce((sum, val) => sum + val, 0)}
          </div>
        )}
      </div>
      
      <button 
        className="roll-button"
        onClick={rollDice}
        disabled={isRolling}
      >
        {isRolling ? 'Rolling...' : 'Roll Dice'}
      </button>
      
      {message && (
        <div className={`result-message ${gameResult}`}>
          {message}
        </div>
      )}
      
      <div className="user-stats">
        <p>Your Coins: {user.currency?.coins || 0}</p>
        <p>Luck Rating: {user.achievements?.luck || 0}</p>
      </div>
    </div>
  );
};

export default DiceRoll;