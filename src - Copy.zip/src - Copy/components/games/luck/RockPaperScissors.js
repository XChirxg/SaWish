


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import BackButton from '../../common/BackButton';
import CurrencyDisplay from '../../common/CurrencyDisplay';
import { useUser } from '../../../contexts/UserContext';
import useSound from '../../../hooks/useSound';

const choices = ['rock', 'paper', 'scissors'];
const winConditions = {
  rock: 'scissors',
  paper: 'rock',
  scissors: 'paper'
};

const RockPaperScissors = () => {
  const navigate = useNavigate();
  const { user, updateUserCurrency } = useUser();
  const [userChoice, setUserChoice] = useState(null);
  const [computerChoice, setComputerChoice] = useState(null);
  const [result, setResult] = useState('');
  const [rounds, setRounds] = useState(0);
  const [wins, setWins] = useState(0);
  const [betAmount, setBetAmount] = useState(50);
  const [gameActive, setGameActive] = useState(false);
  const [showResult, setShowResult] = useState(false);
  
  const { playSound } = useSound();

  const handleStartGame = () => {
    if (user.currency.coins < betAmount) {
      setResult('Not enough coins!');
      return;
    }
    
    // Deduct initial bet amount (50% of reward)
    updateUserCurrency(-Math.floor(betAmount / 2));
    setGameActive(true);
    setRounds(0);
    setWins(0);
    setResult('');
    setShowResult(false);
  };

  const handleChoice = (choice) => {
    if (!gameActive) return;
    
    const cpuChoice = choices[Math.floor(Math.random() * 3)];
    setUserChoice(choice);
    setComputerChoice(cpuChoice);
    
    let roundResult = '';
    if (choice === cpuChoice) {
      roundResult = 'Draw!';
      playSound('draw');
    } else if (winConditions[choice] === cpuChoice) {
      roundResult = 'You win this round!';
      setWins(prev => prev + 1);
      playSound('win');
    } else {
      roundResult = 'Computer wins this round!';
      playSound('lose');
    }
    
    setResult(roundResult);
    setShowResult(true);
    setRounds(prev => prev + 1);
    
    // Check if the game is over after 3 rounds
    if (rounds === 2) {
      setTimeout(() => {
        finishGame();
      }, 1500);
    }
  };

  const finishGame = () => {
    setGameActive(false);
    
    let finalResult = '';
    if (wins > 1) {
      finalResult = 'You won the game!';
      updateUserCurrency(betAmount);
      playSound('gameWin');
    } else {
      finalResult = 'You lost the game!';
      playSound('gameLose');
    }
    
    setResult(finalResult);
  };

  const handleSliderChange = (e) => {
    setBetAmount(parseInt(e.target.value));
  };

  useEffect(() => {
    if (showResult) {
      const timer = setTimeout(() => {
        setShowResult(false);
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [showResult]);

  return (
    <div className="rock-paper-scissors-game">
      <div className="top-bar">
        <BackButton onClick={() => navigate('/games')} />
        <h2>Rock Paper Scissors</h2>
        <CurrencyDisplay coins={user.currency.coins} hearts={user.currency.hearts} />
      </div>
      
      <div className="game-container">
        {!gameActive ? (
          <div className="game-setup">
            <h3>Rock Paper Scissors</h3>
            <p>Play 3 rounds against the computer. Win 2 or more to win the game!</p>
            <div className="bet-container">
              <p>Bet Amount: {betAmount} coins</p>
              <input 
                type="range"
                min="50"
                max="500"
                step="10"
                value={betAmount}
                onChange={handleSliderChange}
              />
              <p>Required to play: {Math.floor(betAmount / 2)} coins</p>
              <p>Win reward: {betAmount} coins</p>
            </div>
            <button 
              className="start-button"
              onClick={handleStartGame}
              disabled={user.currency.coins < Math.floor(betAmount / 2)}
            >
              Start Game
            </button>
            {result === 'Not enough coins!' && (
              <p className="error-message">{result}</p>
            )}
          </div>
        ) : (
          <div className="game-play">
            <div className="game-status">
              <p>Round: {rounds + 1}/3</p>
              <p>Wins: {wins}</p>
            </div>
            
            {showResult && (
              <div className="result-display">
                <div className="choices-display">
                  <div className="choice-box">
                    <p>You</p>
                    <div className={`choice ${userChoice}`}>{userChoice}</div>
                  </div>
                  <div className="vs">VS</div>
                  <div className="choice-box">
                    <p>Computer</p>
                    <div className={`choice ${computerChoice}`}>{computerChoice}</div>
                  </div>
                </div>
                <p className="round-result">{result}</p>
              </div>
            )}
            
            {!showResult && rounds < 3 && (
              <div className="choices">
                <p>Make your choice:</p>
                <div className="choice-buttons">
                  {choices.map(choice => (
                    <button 
                      key={choice} 
                      className={`choice-button ${choice}`}
                      onClick={() => handleChoice(choice)}
                    >
                      {choice}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {rounds === 3 && (
              <div className="game-over">
                <h3>Game Over</h3>
                <p>{result}</p>
                <button 
                  className="play-again-button"
                  onClick={() => {
                    setGameActive(false);
                    setUserChoice(null);
                    setComputerChoice(null);
                  }}
                >
                  Play Again
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default RockPaperScissors;
