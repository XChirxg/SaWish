

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import BackButton from '../../common/BackButton';
import CurrencyDisplay from '../../common/CurrencyDisplay';
import { useUser } from '../../../contexts/UserContext';
import useSound from '../../../hooks/useSound';

const Sudoku = () => {
  const navigate = useNavigate();
  const { user, updateUserCurrency } = useUser();
  const { playSound } = useSound();
  
  const [difficulty, setDifficulty] = useState('easy');
  const [gameStarted, setGameStarted] = useState(false);
  const [board, setBoard] = useState([]);
  const [solution, setSolution] = useState([]);
  const [selectedCell, setSelectedCell] = useState(null);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes in seconds
  const [reward, setReward] = useState(100);
  const [gameOver, setGameOver] = useState(false);
  const [result, setResult] = useState('');
  
  // Generate a new Sudoku board (in a real app, you would use an algorithm or API)
  const generateSudoku = (difficulty) => {
    let rewardAmount = 100;
    let timeLimit = 600;
    
    switch(difficulty) {
      case 'medium':
        rewardAmount = 150;
        timeLimit = 600;
        break;
      case 'hard':
        rewardAmount = 200;
        timeLimit = 600;
        break;
      default:
        rewardAmount = 100;
        timeLimit = 600;
    }
    
    setReward(rewardAmount);
    setTimeLeft(timeLimit);
    
    // For the skeleton, we'll use a minimal representation
    // In a real implementation, you would generate a valid Sudoku puzzle
    const emptyBoard = Array(9).fill().map(() => Array(9).fill(0));
    const fakeSolution = Array(9).fill().map(() => Array(9).fill(0));
    
    // Add some initial numbers
    for (let i = 0; i < 20; i++) {
      const row = Math.floor(Math.random() * 9);
      const col = Math.floor(Math.random() * 9);
      const num = Math.floor(Math.random() * 9) + 1;
      emptyBoard[row][col] = num;
      fakeSolution[row][col] = num;
    }
    
    setBoard(emptyBoard);
    setSolution(fakeSolution);
  };
  
  const startGame = () => {
    // Check if user has enough coins (25% of reward)
    const entryCost = Math.floor(reward * 0.25);
    if (user.currency.coins < entryCost) {
      setResult('Not enough coins to play!');
      return;
    }
    
    // Deduct entry cost
    updateUserCurrency(-entryCost);
    
    generateSudoku(difficulty);
    setGameStarted(true);
    setGameOver(false);
    setResult('');
    playSound('gameStart');
  };
  
  const handleCellClick = (row, col) => {
    if (gameOver) return;
    
    // Skip if it's an initial cell
    if (board[row][col] !== 0 && board[row][col] === solution[row][col]) return;
    
    setSelectedCell([row, col]);
    playSound('select');
  };
  
  const handleNumberInput = (num) => {
    if (!selectedCell || gameOver) return;
    
    const [row, col] = selectedCell;
    const newBoard = [...board];
    newBoard[row][col] = num;
    setBoard(newBoard);
    
    playSound('input');
    
    // Check if the board is complete and correct
    if (isBoardComplete(newBoard) && isBoardCorrect(newBoard)) {
      endGame(true);
    }
  };
  
  const isBoardComplete = (board) => {
    // Check if all cells are filled
    for (let row = 0; row < 9; row++) {
      for (let col = 0; col < 9; col++) {
        if (board[row][col] === 0) return false;
      }
    }
    return true;
  };
  
  const isBoardCorrect = (board) => {
    // In a real implementation, you would check if the board matches the solution
    // For this skeleton, we'll assume it's correct if complete
    return true;
  };
  
  const endGame = (isWin) => {
    setGameOver(true);
    setGameStarted(false);
    
    if (isWin) {
      setResult('Congratulations! You solved the puzzle!');
      updateUserCurrency(reward);
      playSound('gameWin');
    } else {
      setResult('Time\'s up! Better luck next time.');
      playSound('gameLose');
    }
  };
  
  useEffect(() => {
    let timer;
    
    if (gameStarted && !gameOver) {
      timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            endGame(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => clearInterval(timer);
  }, [gameStarted, gameOver]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };
  
  return (
    <div className="sudoku-game">
      <div className="top-bar">
        <BackButton onClick={() => navigate('/games')} />
        <h2>Sudoku</h2>
        <CurrencyDisplay coins={user.currency.coins} hearts={user.currency.hearts} />
      </div>
      
      {!gameStarted ? (
        <div className="game-setup">
          <h3>Sudoku Challenge</h3>
          <p>Test your skills and earn coins by solving Sudoku puzzles!</p>
          
          <div className="difficulty-selector">
            <p>Select Difficulty:</p>
            <div className="difficulty-buttons">
              <button 
                className={`difficulty-button ${difficulty === 'easy' ? 'selected' : ''}`}
                onClick={() => setDifficulty('easy')}
              >
                Easy (100 coins)
              </button>
              <button 
                className={`difficulty-button ${difficulty === 'medium' ? 'selected' : ''}`}
                onClick={() => setDifficulty('medium')}
              >
                Medium (150 coins)
              </button>
              <button 
                className={`difficulty-button ${difficulty === 'hard' ? 'selected' : ''}`}
                onClick={() => setDifficulty('hard')}
              >
                Hard (200 coins)
              </button>
            </div>
          </div>
          
          <div className="game-info">
            <p>Entry Cost: {Math.floor(reward * 0.25)} coins</p>
            <p>Time Limit: 10 minutes</p>
            <p>Reward: {reward} coins</p>
          </div>
          
          <button 
            className="start-button"
            onClick={startGame}
            disabled={user.currency.coins < Math.floor(reward * 0.25)}
          >
            Start Game
          </button>
          
          {result && <p className="result-message">{result}</p>}
        </div>
      ) : (
        <div className="game-play">
          <div className="game-status">
            <div className="time-left">Time Left: {formatTime(timeLeft)}</div>
            <div className="reward">Reward: {reward} coins</div>
          </div>
          
          <div className="sudoku-board">
            {board.map((row, rowIndex) => (
              <div key={rowIndex} className="sudoku-row">
                {row.map((cell, colIndex) => (
                  <div 
                    key={`${rowIndex}-${colIndex}`}
                    className={`sudoku-cell ${
                      selectedCell && selectedCell[0] === rowIndex && selectedCell[1] === colIndex ? 'selected' : ''
                    } ${cell !== 0 && cell === solution[rowIndex][colIndex] ? 'initial' : ''}`}
                    onClick={() => handleCellClick(rowIndex, colIndex)}
                  >
                    {cell !== 0 ? cell : ''}
                  </div>
                ))}
              </div>
            ))}
          </div>
          
          <div className="number-input">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
              <button 
                key={num}
                className="number-button"
                onClick={() => handleNumberInput(num)}
              >
                {num}
              </button>
            ))}
            <button className="number-button clear" onClick={() => handleNumberInput(0)}>
              Clear
            </button>
          </div>
        </div>
      )}
      
      {gameOver && (
        <div className="game-over-overlay">
          <div className="game-over-modal">
            <h3>Game Over</h3>
            <p>{result}</p>
            <button onClick={() => navigate('/games')} className="back-button">
              Back to Games
            </button>
            <button onClick={() => {
              setGameOver(false);
              setGameStarted(false);
            }} className="play-again-button">
              Play Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sudoku;
