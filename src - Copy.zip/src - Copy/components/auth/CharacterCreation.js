// CharacterCreation.js - Character Customization Component
import React, { useState } from 'react';

const CharacterCreation = ({ gender, onComplete, onAddPartner }) => {
  const [characterData, setCharacterData] = useState({
    skinColor: gender === 'male' ? '#f5d0a9' : '#fcdfef',
    hairStyle: 'style1',
    hairColor: 'brown',
  });
  
  const [partnerUsername, setPartnerUsername] = useState('');
  const [partnerOption, setPartnerOption] = useState('later'); // 'later', 'username', 'link'
  const [inviteLink, setInviteLink] = useState('');
  
  const skinColorOptions = [
    { id: 'skin1', value: '#f5d0a9', label: 'Light' },
    { id: 'skin2', value: '#e0c3a0', label: 'Medium' },
    { id: 'skin3', value: '#b08a6e', label: 'Olive' },
    { id: 'skin4', value: '#7a5c43', label: 'Brown' },
    { id: 'skin5', value: '#4e342e', label: 'Dark' },
  ];
  
  const hairStyleOptions = [
    { id: 'style1', value: 'style1', label: 'Short' },
    { id: 'style2', value: 'style2', label: 'Medium' },
    { id: 'style3', value: 'style3', label: 'Long' },
  ];

  const hairColorOptions = [
    { id: 'color1', value: 'black', label: 'Black' },
    { id: 'color2', value: 'brown', label: 'Brown' },
    { id: 'color3', value: 'blonde', label: 'Blonde' },
    { id: 'color4', value: 'red', label: 'Red' },
  ];

  const handleChange = (type, value) => {
    setCharacterData(prev => ({
      ...prev,
      [type]: value
    }));
  };

  const generateInviteLink = () => {
    // In production, this would generate a unique link with a token
    const uniqueToken = 'uniqueToken' + Math.random().toString(36).substr(2, 9);
    const link = `${window.location.origin}?invite=${uniqueToken}`;
    setInviteLink(link);
    return link;
  };

  const handlePartnerOptionChange = (option) => {
    setPartnerOption(option);
    if (option === 'link') {
      generateInviteLink();
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Complete character creation
    onComplete(characterData);
    
    // Handle partner option
    if (partnerOption === 'username' && partnerUsername) {
      onAddPartner(partnerUsername);
    }
  };

  const copyInviteLink = () => {
    navigator.clipboard.writeText(inviteLink);
    alert('Invite link copied to clipboard!');
  };

  return (
    <div className="character-creation">
      <h2>Create Your Character</h2>
      
      <div className="character-preview">
        {/* This would be replaced with an actual character preview */}
        <div 
          className="character-avatar"
          style={{ 
            backgroundColor: characterData.skinColor,
            backgroundImage: `url('/assets/images/characters/base/${gender}/${characterData.hairStyle}_${characterData.hairColor}.png')`
          }}
        ></div>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="customization-section">
          <h3>Customize Appearance</h3>
          
          <div className="option-group">
            <label>Skin Color</label>
            <div className="color-options">
              {skinColorOptions.map(option => (
                <button
                  key={option.id}
                  type="button"
                  className={characterData.skinColor === option.value ? 'selected' : ''}
                  style={{ backgroundColor: option.value }}
                  onClick={() => handleChange('skinColor', option.value)}
                  title={option.label}
                ></button>
              ))}
            </div>
          </div>
          
          <div className="option-group">
            <label>Hair Style</label>
            <div className="style-options">
              {hairStyleOptions.map(option => (
                <button
                  key={option.id}
                  type="button"
                  className={characterData.hairStyle === option.value ? 'selected' : ''}
                  onClick={() => handleChange('hairStyle', option.value)}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          <div className="option-group">
            <label>Hair Color</label>
            <div className="color-options">
              {hairColorOptions.map(option => (
                <button
                  key={option.id}
                  type="button"
                  className={characterData.hairColor === option.value ? 'selected' : ''}
                  style={{ backgroundColor: option.value }}
                  onClick={() => handleChange('hairColor', option.value)}
                  title={option.label}
                ></button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="partner-section">
          <h3>Find Your Partner</h3>
          
          <div className="partner-options">
            <div className="option">
              <input 
                type="radio" 
                id="later" 
                name="partnerOption" 
                value="later"
                checked={partnerOption === 'later'}
                onChange={() => handlePartnerOptionChange('later')}
              />
              <label htmlFor="later">Play solo for now</label>
            </div>
            
            <div className="option">
              <input 
                type="radio" 
                id="username" 
                name="partnerOption" 
                value="username"
                checked={partnerOption === 'username'}
                onChange={() => handlePartnerOptionChange('username')}
              />
              <label htmlFor="username">Add partner by username</label>
              {partnerOption === 'username' && (
                <input
                  type="text"
                  placeholder="Enter partner's username"
                  value={partnerUsername}
                  onChange={(e) => setPartnerUsername(e.target.value)}
                />
              )}
            </div>
            
            <div className="option">
              <input 
                type="radio" 
                id="link" 
                name="partnerOption" 
                value="link"
                checked={partnerOption === 'link'}
                onChange={() => handlePartnerOptionChange('link')}
              />
              <label htmlFor="link">Invite via link</label>
              {partnerOption === 'link' && (
                <div className="invite-link">
                  <input
                    type="text"
                    value={inviteLink}
                    readOnly
                  />
                  <button type="button" onClick={copyInviteLink}>Copy</button>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <button type="submit" className="complete-button">
          Start SaWishing!
        </button>
      </form>
    </div>
  );
};

export default CharacterCreation;