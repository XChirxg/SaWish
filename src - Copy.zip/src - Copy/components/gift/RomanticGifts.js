
import React from 'react';
import { useUser } from '../../contexts/UserContext';

const RomanticGifts = ({ onSelectGift }) => {
  const { user } = useUser();
  
  const romanticGifts = [
    { id: 'rose_bouquet', name: 'Rose Bouquet', price: 150, image: 'rose_bouquet.png' },
    { id: 'dress1', name: 'Elegant Dress', price: 250, image: 'dress1.png' },
    { id: 'puppy', name: 'Puppy', price: 200, image: 'puppy.png' },
    { id: 'necklace1', name: 'Silver Necklace', price: 220, image: 'necklace1.png' },
    { id: 'car1', name: 'Sports Car', price: 500, image: 'car1.png' },
    { id: 'beach', name: 'Beach Vacation', price: 450, image: 'beach.png' }
  ];
  
  return (
    <div className="romantic-gifts">
      <h3>Romantic Gifts</h3>
      <div className="gifts-grid">
        {romanticGifts.map(gift => (
          <div 
            key={gift.id}
            className="gift-item"
            onClick={() => onSelectGift(gift)}
          >
            <div className="gift-image">
              <div className="placeholder-image">{gift.name.charAt(0)}</div>
            </div>
            <div className="gift-name">{gift.name}</div>
            <div className="gift-price">{gift.price} coins</div>
            <button 
              className="gift-select-button"
              disabled={user.currency.coins < gift.price}
            >
              Select
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RomanticGifts;
