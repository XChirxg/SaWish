

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import BackButton from '../common/BackButton';
import { useUser } from '../../contexts/UserContext';
import { usePartner } from '../../contexts/PartnerContext';
import CurrencyDisplay from '../common/CurrencyDisplay';
import useSound from '../../hooks/useSound';

const CasualGifts = ({ onSelectGift }) => {
  const { user } = useUser();
  
  const casualGifts = [
    { id: 'watch1', name: 'Digital Watch', price: 100, image: 'watch1.png' },
    { id: 'tshirt1', name: 'Casual T-Shirt', price: 70, image: 'tshirt1.png' },
    { id: 'sunglasses1', name: 'Sunglasses', price: 90, image: 'sunglasses1.png' },
    { id: 'book1', name: 'Mystery Novel', price: 60, image: 'book1.png' },
    { id: 'chocolate', name: 'Chocolate Box', price: 35, image: 'chocolate.png' },
    { id: 'game1', name: 'Board Game', price: 85, image: 'game1.png' }
  ];
  
  return (
    <div className="casual-gifts">
      <h3>Casual Gifts</h3>
      <div className="gifts-grid">
        {casualGifts.map(gift => (
          <div 
            key={gift.id}
            className="gift-item"
            onClick={() => onSelectGift(gift)}
          >
            <div className="gift-image">
              <div className="placeholder-image">{gift.name.charAt(0)}</div>
            </div>
            <div className="gift-name">{gift.name}</div>
            <div className="gift-price">{gift.price} coins</div>
            <button 
              className="gift-select-button"
              disabled={user.currency.coins < gift.price}
            >
              Select
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CasualGifts;
