

import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../../contexts/UserContext';
import useSound from '../../hooks/useSound';
import BackButton from '../common/BackButton';

const Settings = () => {
  const navigate = useNavigate();
  const { user, updateUserProfile, logout } = useContext(UserContext);
  const { playSound } = useSound();
  
  const [username, setUsername] = useState(user?.profile?.username || '');
  const [bio, setBio] = useState(user?.profile?.bio || '');
  const [instagramId, setInstagramId] = useState(user?.profile?.instagramId || '');
  const [phoneNumber, setPhoneNumber] = useState(user?.profile?.phoneNumber || '');
  const [soundVolume, setSoundVolume] = useState(50);
  const [musicVolume, setMusicVolume] = useState(50);
  
  const handleSave = async () => {
    playSound('saveSuccess');
    await updateUserProfile({
      username,
      bio,
      instagramId,
      phoneNumber
    });
    // Show success notification
  };
  
  const handleLogout = async () => {
    playSound('logout');
    await logout();
    navigate('/login');
  };
  
  const handleInstallApp = () => {
    // PWA install logic here
    playSound('install');
  };
  
  const handleSoundVolumeChange = (e) => {
    setSoundVolume(e.target.value);
    // Update sound volume in the app
  };
  
  const handleMusicVolumeChange = (e) => {
    setMusicVolume(e.target.value);
    // Update music volume in the app
  };

  return (
    <div className="settings-container">
      <BackButton />
      
      <h1>Settings</h1>
      
      <div className="settings-section">
        <h2>Profile Settings</h2>
        
        <div className="setting-item">
          <label>Username</label>
          <input 
            type="text" 
            value={username} 
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        
        <div className="setting-item">
          <label>Bio</label>
          <textarea 
            value={bio} 
            onChange={(e) => setBio(e.target.value)}
          />
        </div>
        
        <div className="setting-item">
          <label>Instagram ID</label>
          <input 
            type="text" 
            value={instagramId} 
            onChange={(e) => setInstagramId(e.target.value)}
            placeholder="Only visible to partner after 30-day streak"
          />
        </div>
        
        <div className="setting-item">
          <label>Phone Number</label>
          <input 
            type="tel" 
            value={phoneNumber} 
            onChange={(e) => setPhoneNumber(e.target.value)}
            placeholder="Only visible to partner after 30-day streak"
          />
        </div>
        
        <button className="save-button" onClick={handleSave}>
          Save Profile
        </button>
      </div>
      
      <div className="settings-section">
        <h2>Sound Settings</h2>
        
        <div className="setting-item">
          <label>Sound Effects Volume</label>
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={soundVolume} 
            onChange={handleSoundVolumeChange}
          />
        </div>
        
        <div className="setting-item">
          <label>Music Volume</label>
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={musicVolume} 
            onChange={handleMusicVolumeChange}
          />
        </div>
      </div>
      
      <div className="settings-section">
        <h2>App Options</h2>
        
        <button className="install-button" onClick={handleInstallApp}>
          Install App on Device
        </button>
        
        <div className="about-section">
          <h3>About SaWish</h3>
          <p>A relationship-building game platform...</p>
          <p>Developed by <a href="https://instagram.com/chinurag" target="_blank" rel="noopener noreferrer">Chinurag</a></p>
        </div>
        
        <button className="feedback-button" onClick={() => window.open('https://instagram.com/chinurag', '_blank')}>
          Send Feedback
        </button>
      </div>
      
      <button className="logout-button" onClick={handleLogout}>
        Logout
      </button>
    </div>
  );
};

export default Settings;
