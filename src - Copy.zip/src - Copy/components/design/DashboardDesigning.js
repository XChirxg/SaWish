

import React, { useContext, useState } from 'react';
import { UserContext } from '../../contexts/UserContext';
import BackButton from '../common/BackButton';
import '../../../src/styles/components/design/DashboardDesigning.css';

const DashboardDesigning = () => {
  const { user, updateUserDashboard, updateUserCharacter } = useContext(UserContext);
  const [selectedCategory, setSelectedCategory] = useState('character');
  const [selectedSubcategory, setSelectedSubcategory] = useState('skinColor');

  // Placeholder data - in real implementation, these would come from the database
  const characterOptions = {
    skinColor: ['#F5D0A9', '#F5CBA7', '#E59866', '#BA4A00', '#6E2C00'],
    hairColor: ['#000000', '#4A235A', '#7B241C', '#B9770E', '#F1C40F'],
    hairStyle: ['style1', 'style2', 'style3', 'style4', 'style5'],
    headWearables: ['hat1', 'hat2', 'hat3', 'hat4', 'hat5'],
    eyeGlasses: ['glasses1', 'glasses2', 'glasses3', 'glasses4'],
    shirts: ['shirt1', 'shirt2', 'shirt3', 'shirt4', 'shirt5'],
    coats: ['coat1', 'coat2', 'coat3', 'coat4'],
    bottoms: ['bottom1', 'bottom2', 'bottom3', 'bottom4', 'bottom5'],
    shoes: ['shoes1', 'shoes2', 'shoes3', 'shoes4'],
    neckAccessories: ['neck1', 'neck2', 'neck3', 'neck4'],
    watches: ['watch1', 'watch2', 'watch3', 'watch4'],
    armWearables: ['arm1', 'arm2', 'arm3', 'arm4']
  };

  const itemOptions = {
    cheapGifts: ['flower', 'chocolate', 'card', 'stuffedAnimal'],
    middleGifts: ['book', 'jewelry', 'perfume', 'watch'],
    vehicles: ['car', 'bike', 'scooter', 'helicopter']
  };

  const backgroundOptions = [
    'park', 'beach', 'mountain', 'city', 'restaurant', 'cinema',
    'shimla', 'paris', 'tokyo', 'newyork', 'rome'
  ];

  // Calculate unlocked items based on gift counts (placeholder implementation)
  const getUnlockedItems = (category, subcategory) => {
    const unlockedItems = {
      character: characterOptions,
      items: {},
      background: [...backgroundOptions.slice(0, 5)] // Just first 5 backgrounds unlocked
    };
    
    // Simulate unlocked items based on gifts received
    if (user.unlockedGifts) {
      if (user.unlockedGifts.casual.flowers > 10) {
        unlockedItems.items.cheapGifts = [...itemOptions.cheapGifts];
      }
      
      if (user.unlockedGifts.romantic.books > 50) {
        unlockedItems.items.middleGifts = [...itemOptions.middleGifts];
      }
      
      if (user.unlockedGifts.romantic.vehicles > 0) {
        unlockedItems.items.vehicles = [...itemOptions.vehicles];
      }
    }
    
    if (category === 'background') {
      return unlockedItems.background;
    } else if (category === 'items') {
      return unlockedItems.items[subcategory] || [];
    } else {
      return characterOptions[subcategory] || [];
    }
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    
    // Set default subcategory based on selected category
    if (category === 'character') {
      setSelectedSubcategory('skinColor');
    } else if (category === 'items') {
      setSelectedSubcategory('cheapGifts');
    } else {
      setSelectedSubcategory(null);
    }
  };

  const handleSubcategoryChange = (subcategory) => {
    setSelectedSubcategory(subcategory);
  };

  const handleItemSelect = (item) => {
    if (selectedCategory === 'character') {
      // Update character feature
      updateUserCharacter({
        [selectedSubcategory]: item
      });
    } else if (selectedCategory === 'items') {
      // Update dashboard items
      updateUserDashboard({
        items: {
          type: selectedSubcategory,
          item: item
        }
      });
    } else if (selectedCategory === 'background') {
      // Update dashboard background
      updateUserDashboard({
        background: item
      });
    }
  };

  return (
    <div className="dashboard-designing-container">
      <BackButton />
      <h1>Dashboard Design</h1>
      
      <div className="design-categories">
        <button 
          className={`category-btn ${selectedCategory === 'character' ? 'active' : ''}`}
          onClick={() => handleCategoryChange('character')}
        >
          Character
        </button>
        <button 
          className={`category-btn ${selectedCategory === 'items' ? 'active' : ''}`}
          onClick={() => handleCategoryChange('items')}
        >
          Items
        </button>
        <button 
          className={`category-btn ${selectedCategory === 'background' ? 'active' : ''}`}
          onClick={() => handleCategoryChange('background')}
        >
          Background
        </button>
      </div>
      
      {selectedCategory === 'character' && (
        <div className="subcategories">
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'skinColor' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('skinColor')}
          >
            Skin Color
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'hairColor' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('hairColor')}
          >
            Hair Color
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'hairStyle' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('hairStyle')}
          >
            Hair Style
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'headWearables' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('headWearables')}
          >
            Head Wearables
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'eyeGlasses' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('eyeGlasses')}
          >
            Glasses
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'shirts' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('shirts')}
          >
            Shirts
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'coats' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('coats')}
          >
            Coats
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'bottoms' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('bottoms')}
          >
            Bottoms
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'shoes' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('shoes')}
          >
            Shoes
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'neckAccessories' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('neckAccessories')}
          >
            Neck Accessories
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'watches' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('watches')}
          >
            Watches
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'armWearables' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('armWearables')}
          >
            Arm Wearables
          </button>
        </div>
      )}
      
      {selectedCategory === 'items' && (
        <div className="subcategories">
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'cheapGifts' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('cheapGifts')}
          >
            Small Gifts
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'middleGifts' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('middleGifts')}
          >
            Special Gifts
          </button>
          <button 
            className={`subcategory-btn ${selectedSubcategory === 'vehicles' ? 'active' : ''}`}
            onClick={() => handleSubcategoryChange('vehicles')}
          >
            Vehicles
          </button>
        </div>
      )}
      
      <div className="items-preview">
        {selectedCategory === 'background' ? (
          <div className="background-items">
            {getUnlockedItems('background').map((item, index) => (
              <div 
                key={index} 
                className={`background-item ${user.dashboard?.background === item ? 'active' : ''}`}
                onClick={() => handleItemSelect(item)}
              >
                <div className="background-preview" style={{ backgroundImage: `url(/assets/images/backgrounds/${item}.jpg)` }}>
                </div>
                <span className="item-name">{item}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="customization-items">
            {getUnlockedItems(selectedCategory, selectedSubcategory).map((item, index) => (
              <div 
                key={index} 
                className={`customization-item ${selectedCategory === 'character' && user.character?.[selectedSubcategory] === item ? 'active' : ''}`}
                onClick={() => handleItemSelect(item)}
              >
                {selectedCategory === 'character' && selectedSubcategory === 'skinColor' || selectedSubcategory === 'hairColor' ? (
                  <div className="color-swatch" style={{ backgroundColor: item }}></div>
                ) : (
                  <div className="item-preview" style={{ backgroundImage: `url(/assets/images/${selectedCategory}s/${selectedSubcategory}/${item}.png)` }}>
                  </div>
                )}
                <span className="item-name">{item}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      
      <div className="character-preview">
        <h3>Preview</h3>
        <div className="preview-container">
          {/* This would be a fully rendered character with all selected options */}
          <div className="character-avatar"></div>
        </div>
      </div>
      
      <div className="save-buttons">
        <button className="save-btn">Save Changes</button>
        <button className="reset-btn">Reset</button>
      </div>
    </div>
  );
};

export default DashboardDesigning;
